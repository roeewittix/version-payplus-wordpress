
    jQuery(document).ready(function ($){
        setFieldReadOnly();
        addFieldRefund();

        if(!$("#woocommerce_payplus-payment-gateway_block_ip_transactions").prop('checked')){
            $("#woocommerce_payplus-payment-gateway_block_ip_transactions_hour").attr("readonly",true);
        }

        if(payplus_script_admin.payplus_invoice){
            let tabPayPlus="tab-invoice-payplus"
            $("#payplus-title-section").text(payplus_script_admin.payplus_title_tab[tabPayPlus]);
            $("#payplus-lead").css("display","none");
          //  jQuery(".woocommerce-save-button").removeAttr("disabled");
            $("#sub-option-paylus").addClass('payplus-none');
            $(".tab-section-payplus").addClass('payplus-none');
            $("." +tabPayPlus).addClass('nav-tab-active');
            $("#" +tabPayPlus).css("display",'block');


        }
        /*
        if(payplus_script_admin.payplus_enabled_payment){

            jQuery(".woocommerce-save-button").attr("disabled", "disabled");
        }
        */

        $( '#woocommerce-order-items' ).on( 'change keyup', '.wc-order-refund-items #refund_amount',function (){
            let button = $(".do-api-refund .woocommerce-Price-amount");
            button.text( payPlusSumRefund());
        });


        $("#payplus-lead button").click(function (){
            let flag=true;
            const payplusFullName=$("#payplus-fullname").val();
            const payplusPhone=$("#payplus-phone").val();
            const payplusEmail=$("#payplus-email").val();
            const payplusCompany=$("#payplus-company").val();
            const payplusWebsite=$("#payplus-website").val();
            const payplusMessage =$("#payplus-message").val();

           if(payplusFullName==""){
               flag=false;
               $(".payplus-fullname").addClass("payplus-error-valid");
           }
            if(payplusPhone==""){
                $(".payplus-phone").addClass("payplus-error-valid");
                flag=false;
            }
            if(payplusEmail==""){
                $(".payplus-email").addClass("payplus-error-valid");
                flag=false;
            }
            if(payplusCompany==""){
                $(".payplus-company").addClass("payplus-error-valid");
                flag=false;
            }
            if(payplusMessage==""){
                flag=false;
                $(".payplus-message").addClass("payplus-error-valid");
            }
            if(flag){
                $.ajax({
                    type : "post",
                    url : payplus_script_admin.ajax_url,
                    data : {
                        "action": "payplus-api-lead",
                        "fname" :payplusFullName,
                        "phone" :payplusPhone,
                        "company" :payplusCompany,
                        "website" :payplusWebsite,
                        "comment":payplusMessage,
                        "email" :payplusEmail

                    },
                    success: function(response) {
                        $("#payplus-body-lead").html(response);
                    }
                });
            }
        });

        $( '#woocommerce-order-items' ).on( 'click', 'button.do-api-refund, button.do-manual-refund',function (event){
            event.preventDefault();

            let refund_amount_multipass =$(".refund_amount_multipass"),
             valueAmount ={};
            if(refund_amount_multipass!=undefined){
                refund_amount_multipass.each(function(){
                    if(parseFloat($(this).val())>0){
                        let index =$(this).attr("id");
                        index =index.split("__");
                        valueAmount[index[1]] =$(this).val();
                    }
                });
                if(Object.keys(valueAmount).length>0){
                    setCookie("payplus_amount_multipass",JSON.stringify(valueAmount),1)
                }

            }
        });
        $(".refund_amount_multipass").change(function (){
            const  max=parseFloat($(this).attr('max'));
            if($(this).val()>max){
                $(this).val(max);
            }
            let button = $(".do-api-refund .woocommerce-Price-amount");
            button.text( payPlusSumRefund());

        });
        $("#select-languages-payplus").change(function (event){
            event.preventDefault();
            let  language =$(this).val();
            let html="";
            let  languageOther =language.split("-");
             html += '<tr> ' +
                 '<th>' +languageOther[1] +'</th>' +
                '<td><textarea rows="3" cols="45" className="input-text wide-input" ' +
                 ' name="settings_payplus_page_error_option[' + language+']"></textarea>'+
                '</td></tr>';
             $("#payplus-add-language").append(html);

        });
        $(".tab-option-payplus  a").click(function (event){
            event.preventDefault();
            const tabPayPlus =$(this).attr("data-tab");
            if(tabPayPlus=="payplus-blank"){
                location.href =$(this).attr("href");
            }else{
                $(".tab-option-payplus  a").removeClass('nav-tab-active');
                if(tabPayPlus=="tab-payplus-error-page" ||
                    tabPayPlus=="tab-invoice-payplus"){
                    $("#payplus-title-section").text(payplus_script_admin.payplus_title_tab[tabPayPlus]);
                    $("#payplus-lead").css("display","none");
                    jQuery(".woocommerce-save-button").removeAttr("disabled");
                    $("#sub-option-paylus").addClass('payplus-none');
                    $(this).addClass('nav-tab-active');
                }else{
                    $("#sub-option-paylus").removeClass('payplus-none');
                }
                $(".tab-section-payplus").css("display",'none');
                $("#" +tabPayPlus).css("display",'block');
            }
        });

        $(".copytoken").click(function (event){
            event.preventDefault();
            var copyText =$(".copytoken");
            navigator.clipboard.writeText(copyText.text());

        });
        $("#order-payment-payplus-refund").click(function (){
            event.preventDefault();
            let orderId =$(this).attr("data-id");
            $(".payplus_loader_refund").fadeIn();
            $.ajax({
                type : "post",
                dataType: 'json',
                url : payplus_script_admin.ajax_url,
                data : {
                    "action": "payplus-api-payment-refund",
                    "order_id" :orderId,

                },
                success: function(response) {

                    $(".payplus_loader_refund").fadeOut();
                    if(response.status){
                        location.href=response.urlredirect;
                    }
                }
            });

        });

        $(document).on("click","#payment-payplus-dashboard",function (event){
            event.preventDefault();
            let orderId =$(this).attr("data-id");
            $(".payplus_loader").fadeIn();
            $.ajax({
                type : "post",
                dataType: 'json',
                url : payplus_script_admin.ajax_url,
                data : {
                    "action": "generate-link-payment",
                    "order_id" :orderId,
                },
                success: function(response) {
                    $("#box-payplus-payment").fadeIn();
                    $("#payment-payplus-dashboard,.payplus_loader").fadeOut();
                    if(response.status){
                       $("#box-payplus-payment iframe").attr("src",response.payment_response)
                    }else{
                        $("#box-payplus-payment").text(response.payment_response);
                    }
                }
            });
        });
        $("#order-payment-payplus").click(function (event){
            event.preventDefault();
            let orderId =$(this).attr("data-id");
            $(".payplus_loader").fadeIn();
            $.ajax({
                type : "post",
                dataType: 'json',
                url : payplus_script_admin.ajax_url,
                data : {
                    "action": "payplus-api-payment",
                    "order_id" :orderId,

                },
                success: function(response) {
                    $(".payplus_loader").fadeOut();
                    //if(response.status){
                        location.href=response.urlredirect;
                   // }
                }
            });



        });
        $("#payplus-token-payment").click(function (event){
            event.preventDefault()
            let payplusChargeAmount =$(this)
                    .closest('.delayed-payment')
                    .find('#payplus_charge_amount').val(),
                payplusOrderId =$(this)
                    .closest('.delayed-payment')
                    .find('#payplus_order_id').val();

            $(".payplus_loader").fadeIn();
            $("#payplus-token-payment").prop("disabled",true);
            $.ajax({
                type : "post",
                dataType: 'json',
                url : payplus_script_admin.ajax_url,
                data : {
                    "action": "payplus-token-payment",
                    "payplus_charge_amount" :payplusChargeAmount,
                    'payplus_order_id' :payplusOrderId,
                    'payplus_token_payment':true
                },
                success: function(response) {

                    $(".payplus_loader").fadeOut();
                    if(!response.status){
                        $(".payplus_error").html(payplus_script_admin.error_payment)
                            .fadeIn( function()
                            {
                                setTimeout( function()
                                {
                                    $("#payplus-token-payment").prop("disabled",false);
                                    $(".payplus_error").fadeOut("fast");
                                    $("#payplus_charge_amount").val($("#payplus_charge_amount").attr('data-amount'));
                                }, 1000);
                            });
                    }else{
                        location.href=response.urlredirect;
                    }
                }
            });

        });

    });
    function  setFieldReadOnly(){
        const arrNameFieldReadOnly =jQuery("#postcustom input[type='text']");


        for (let i = 0; i < arrNameFieldReadOnly.length; i++) {
            const metaName = jQuery(arrNameFieldReadOnly[i]).attr("id");
            const  metaValue = metaName.replace("key", "value");
            if(  jQuery("#"+metaName).val().indexOf("payplus")!=-1){
                const  father =metaName.replace('-key',"");
                jQuery("#"+metaName).prop('disabled', true);
                jQuery("#"+metaValue).prop('disabled', true);
                jQuery("#" +father).find(".button").prop('disabled', true);
            }
        }

        const metaName = jQuery("#postcustom input[value='order_validated']").attr("id");

        if(typeof metaName!="undefined"){
            const  metaValue = metaName.replace("key", "value");
            const  father =metaName.replace('-key',"");
            jQuery("#"+metaName).prop('disabled', true);
            jQuery("#"+metaValue).prop('disabled', true);
            jQuery("#" +father).find(".button").prop('disabled', true);
        }


    }
    function  addFieldRefund(){

        if(jQuery(".wc-order-refund-items .wc-order-totals").length){
            const orderStatus =jQuery("#order_status").val();
            let position =4;
            const metaName = jQuery("#postcustom input[value='payplus_related_transactions']").attr("id");
            let refunded =jQuery("#postcustom input[value='payplus_refunded']").attr("id");
            let multipass=false;

            if(refunded !=undefined){
                refunded =refunded.replace("key", "value");
                refunded=jQuery("#" + refunded).val();
            }else{
                refunded =0;
            }

            if(typeof metaName!="undefined") {

                const metaValue = metaName.replace("key", "value");
                const payplusRelatedTransactions = jQuery("#" + metaValue).val();

                if (payplusRelatedTransactions) {
                    multipass=true;
                    const metaName = jQuery("#postcustom input[value='payplus_multipass']").attr("id");
                    const metaValue = metaName.replace("key", "value");
                    const payplusMmultipass = jQuery("#" + metaValue).val().split("|");

                    if (payplusMmultipass.length) {
                        for (let i = 0; i < payplusMmultipass.length; i++) {

                            if (parseFloat(payplusMmultipass[i])) {
                                jQuery(".wc-order-refund-items .wc-order-totals tr:nth-child(" + position + ")").after(
                                    "<tr><<td class='label'>" +
                                    "<label for='refund_amount'>" +
                                    payplus_script_admin.refund_amount + parseFloat(payplusMmultipass[i]).toFixed(2) + ")" +
                                    "</label>\n" +
                                    "</td>" +
                                    "<td class='total'>" +
                                    "<input  type='number' value='0' min='0'  max='" + payplusMmultipass[i] + "' id='refund_amount_multipass__" + i + "' name='refund_amount_multipas__" + i + "' class='wc_input_price refund_amount_multipass' " +
                                    "<div class='clear'></div>" +
                                    "</td></tr>")
                                position++;
                            }
                        }
                    }
                }
            }


        }
    }
    function payPlusSumRefund(){
        const arrRefundAmount =['refund_amount'];
        const multipasss =jQuery(".refund_amount_multipass");
        let sum=0;
        const isEmpty = (str) => (!str?.length);
        for(let i=0;i<arrRefundAmount.length;i++){
            if(!isEmpty(jQuery("#"+arrRefundAmount[i]).val())){
                sum+=parseFloat(jQuery("#"+arrRefundAmount[i]).val());
            }
        }
        for(let i=0;i<multipasss.length;i++){
            sum+=parseFloat(jQuery(multipasss[i]).val());
        }
        return sum.toFixed(2);

    }
    function capitalizeFirstLetter(str) {

        // converting first letter to uppercase
        const capitalized = str.charAt(0).toUpperCase() + str.slice(1);
        return capitalized;
    }
    function setCookie(cname, cvalue, exdays) {
        const d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        let expires = "expires="+ d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }