<?php
    defined('ABSPATH') || exit; // Exit if accessed directly


        class WC_PayPlus_Admin_Payments extends WC_PayPlus_Gateway
        {
            protected static $instance = null;
            public $error_msg = 0;
            public $arrPayment =array(
                    'payplus-payment-gateway',
                    'payplus-payment-gateway-bit',
                    'payplus-payment-gateway-googlepay',
                    'payplus-payment-gateway-applepay',
                    'payplus-payment-gateway-multipass',
                    'payplus-payment-gateway-paypal'
            );

            public static function get_instance()
            {
                if (!isset(static::$instance)) {
                    static::$instance = new static;
                }
                return static::$instance;
            }

            private function __construct()
            {
                global $pagenow;
                $isPageOrder =('post.php' === $pagenow && isset($_GET['post']) && 'shop_order' === get_post_type($_GET['post'])) ;
                if ($isPageOrder
                    || (('admin.php' === $pagenow ) && isset($_GET['section']) && in_array($_GET['section'],$this->arrPayment))){

                    add_action('admin_enqueue_scripts', [$this, 'load_admin_assets']);
                    if($isPageOrder){
                        if(isset($_GET['post'])){
                            $orderId =$_GET['post'];
                            $payplusStatus =get_post_meta($orderId,'payplus_status',true);
                            if($payplusStatus==="approved"){
                                $payplusRefunded =get_post_meta($orderId,'payplus_refunded',true);
                                if($payplusRefunded==""){
                                    $orderTotal =get_post_meta($orderId,'_order_total' ,true );
                                    $payplusRefunded =add_post_meta($orderId,'payplus_refunded',$orderTotal);
                                }
                            }
                        }

                    }
                }

                // make payment button for j2\j5
                add_action('woocommerce_order_actions_end', [$this, 'make_payment_button'], 10, 1);
                // process make payment
                add_action('save_post_shop_order', [$this, 'process_make_payment'], 10, 1);
                // admin notices
                add_action('admin_notices', [$this, 'admin_notices'], 15);

                add_action( 'wp_ajax_payplus-token-payment',  [$this,'ajax_payplus_token_payment' ]);
                add_action( 'wp_ajax_payplus-api-lead',  [$this,'ajax_payplus_api_lead' ]);

                add_action( 'wp_ajax_payplus-api-payment',  [$this,'ajax_payplus_payment_api' ]);

                add_action( 'wp_ajax_generate-link-payment',  [$this,'ajax_payplus_generate_link_payment' ]);

                add_action( 'woocommerce_admin_order_totals_after_total',[$this, 'payplus_woocommerce_admin_order_totals_after_total'], 10, 1 );

                // remove query args after error shown
                add_filter('removable_query_args', [$this, 'add_removable_arg']);
                add_filter( 'gettext', [$this,'payplus_change_translate_text'], 20 );

            }

            public  function  ajax_payplus_api_lead(){
                if(!empty($_POST) && !empty($_POST['action']) &&$_POST['action'] =="payplus-api-lead") {
                    $post = $_POST;
                    $fname = $post['fname'];
                    $phone = $post['phone'];
                    $email = $post['email'];
                    $company = $post['company'];
                    $website = $post['website'];
                    $comment = $post['comment'];
                    $headers = array('Content-Type: text/html; charset=UTF-8');
                    $date = new DateTime();
                    $date = $date->format('d-m-Y h:i:s');
                    $body = "<html><body>";
                    $body .= "<p>" . __("sent on", 'payplus-payment-gateway') . ":" . $date . "</p>";
                    $body .= "<p>" . __("Fullname", 'payplus-payment-gateway') . ":" . $fname . "</p>";
                    $body .= "<p>" . __("Phone", 'payplus-payment-gateway') . ":" . $phone . "</p>";
                    $body .= "<p>" . __("Email", 'payplus-payment-gateway') . ":" . $email . "</p>";
                    $body .= "<p>" . __("Company Name", 'payplus-payment-gateway') . ":" . $company . "</p>";
                    $body .= "<p>" . __("Website", 'payplus-payment-gateway') . ":" . $website . "</p>";
                    $body .= "<p>" . __("Department", 'payplus-payment-gateway') . ":" . __('Sales department', 'payplus-payment-gateway') . "</p>";
                    $body .= "<p>" . __("Message", 'payplus-payment-gateway') . ":" . $comment . "</p>";
                    $body .= "</body></html>";
                    wp_mail(PAYPLUS_SEND_EMAIL, __("PayPlus Lead", 'payplus-payment-gateway'), $body, $headers);
                    echo "<div class='lead-msg'>
                        <h2>".__("Thanks for writing",'payplus-payment-gateway')."</h2>"
                        ."<p>".__("We are happy about your interest in our services",'payplus-payment-gateway')."</p>".
                        "</div>";
                    wp_die();
                }
                echo  "false";
                wp_die();
            }

            public  function ajax_payplus_generate_link_payment(){

                if(!empty($_POST)){
                    $WC_PayPlus_Gateway = NEW WC_PayPlus_Gateway();
                    $order_id=$_POST['order_id'];
                    $response =$WC_PayPlus_Gateway->payplus_generate_payment_link($order_id,true);
                    if(!empty($response)){
                        echo json_encode($response);
                        wp_die();
                    }
                }
                echo json_encode(array("payment_response"=>"","status"=>false));
                wp_die();
            }

            public  function payplus_change_translate_text( $translated_text ) {
                $locale= get_locale();
                if ($locale==="he_IL" && 'Check Transaction'  === $translated_text ) {
                    $translated_text = 'בדוק עסקה';
                }
                return $translated_text;
            }

            public  function  ajax_payplus_payment_api(){


                if(!empty($_POST)){
                    $WC_PayPlus_Gateway = new WC_PayPlus_Gateway();
                    $order_id=$_POST['order_id'];
                    $order =wc_get_order($order_id);

                    $transaction_uid = $order->get_meta('payplus_transaction_uid');
                    $transaction_uid="";
                    $payload=array();
                    $createToken = false;
                    if ($order->get_user() != false) {
                        $userID = $order->get_user_id();
                    }
                    $type = $order->get_meta('payplus_type');

                    if($transaction_uid){
                        $payload['transaction_uid'] =$transaction_uid;
                    }else{

                        $payload['more_info'] =$order_id;
                    }

                    $payload['related_transaction'] =true;
                    $WC_PayPlus_Gateway->logging->add('payplus_process_payment', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'IPN Request: ' . print_r($payload, true));
                    $payload =json_encode($payload);
                    $response = $this->post_payplus_ws($WC_PayPlus_Gateway->ipn_url, $payload);

                    $res = json_decode(wp_remote_retrieve_body($response));
                    if ($res->results->status == "error" ||$res->data->status_code !=="000" ) {

                        $transaction_uid= ($transaction_uid)?$transaction_uid :$res->data->transaction_uid;
                        $WC_PayPlus_Gateway->logging->add('payplus_process_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Error IPN Error: ' . print_r($res, true));
                        $order->update_status($WC_PayPlus_Gateway->failure_order_status);
                        $order->add_order_note(sprintf(__('PayPlus IPN Failed<br/>Transaction UID: %s', 'payplus-payment-gateway'), $transaction_uid));
                        $order->add_meta_data('order_validated', 1);
                        $urlEdit= get_admin_url()."post.php?post=".$order_id."&action=edit";
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                        wp_die();

                    } else if ($res->data->status_code === '000') {

                        $inData = (array)$res->data;

                        $WC_PayPlus_Gateway->updateMetaData($order_id, $inData);

                        if (isset($res->data->recurring_type)) {
                            if ($WC_PayPlus_Gateway->recurring_order_set_to_paid == 'yes') {
                                $order->payment_complete();
                            }
                            $order->update_status('wc-recsubc');
                        } else {
                            if ($type == "Charge") {
                                if ($WC_PayPlus_Gateway->fire_completed) $order->payment_complete();
                                $order->update_status($WC_PayPlus_Gateway->successful_order_status);
                            } else {
                                $order->update_status('wc-on-hold');
                            }

                            $html = '<div style="font-weight:600;">PayPlus Related Transaction';
                            if (property_exists($res->data, 'related_transactions')) {
                                $relatedTransactions = $res->data->related_transactions;
                                for ($i = 0; $i < count($relatedTransactions); $i++) {
                                    $relatedTransaction = $relatedTransactions[$i];
                                    if ($relatedTransaction->method == "credit-card") {
                                        $html .= sprintf(__('
                            <div style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus ' . (($type == "Approval" || $type == "Check") ? 'Pre-Authorization' : 'Payment') . ' Successful
                                <table style="border-collapse:collapse">
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Last digits</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Expiry date</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Voucher ID</td><td  style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="vertical-align:top;">Token</td><td style="vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                </table></div>
                            ',
                                            'payplus-payment-gateway'),
                                            $relatedTransaction->number,
                                            $relatedTransaction->four_digits,
                                            $relatedTransaction->expiry_month . $relatedTransaction->expiry_year,
                                            $relatedTransaction->voucher_id,
                                            $relatedTransaction->token_uid,
                                            $relatedTransaction->amount

                                        );

                                    } else {
                                        $html .= sprintf(__('
                              <div class="row" style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus  Successful ' . $relatedTransaction->method . '
                                <table style="border-collapse:collapse">
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                </table></div>
                            ',
                                            'payplus-payment-gateway'),
                                            $relatedTransaction->number,
                                            $relatedTransaction->amount);
                                    }

                                }
                                $html .= "</div>";
                                $order->add_order_note($html);

                            } else {
                                if ($res->data->method !== "credit-card") {
                                    $order->add_order_note(sprintf(__('
                              <div class="row" style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus  Successful ' . $res->data->method . '
                                <table style="border-collapse:collapse">
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                </table></div>
                            ',
                                        'payplus-payment-gateway'),
                                        $res->data->number,
                                        $res->data->amount));

                                } else {


                                    $order->add_order_note(sprintf(__('
                            <div style="font-weight:600;">PayPlus ' . (($type == "Approval" || $type == "Check") ? 'Pre-Authorization' : 'Payment') . ' Successful</div>
                                <table style="border-collapse:collapse">
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Last digits</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Expiry date</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="border-bottom:1px solid #000;vertical-align:top;">Voucher ID</td><td  style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
                                    <tr><td style="vertical-align:top;">Token</td><td style="vertical-align:top;">%s</td></tr>
                                    <tr><td style="vertical-align:top;">Total</td><td style="vertical-align:top;">%s</td></tr>
                                </table>
                            ',
                                        'payplus-payment-gateway'),
                                        $res->data->number,
                                        $res->data->four_digits,
                                        $res->data->expiry_month . $res->data->expiry_year,
                                        $res->data->voucher_id,
                                        $res->data->token_uid,
                                        $res->data->amount  ,
                                    $order->get_total()

                                    ));
                                }
                            }


                        }
                        $urlEdit= get_admin_url()."post.php?post=".$order_id."&action=edit";
                            echo json_encode(array("urlredirect"=>$urlEdit,"status"=>true));
                            wp_die();


                    }

                }
                wp_die();

            }

            public  function  payplus_woocommerce_admin_order_totals_after_total($orderId){

                $order = wc_get_order($orderId);
               $transaction_uid = $order->get_meta('payplus_transaction_uid');
               $order_validated = $order->get_meta('order_validated');
                if ( !floatval($order->get_total())
                    || !empty($transaction_uid)||$order_validated==="1"    ||$this->enabled==="no" || $order->get_status()!=="pending") {
                    return;
                }
                ob_start();
                ?>
                    <div class="payment-order-ajax">
                        <button  id="payment-payplus-dashboard" data-id="<?php echo  $orderId ?>" class="button  button-primary"><?php echo __("Payment","payplus-payment-gateway") ?></button>
                        <div class='payplus_loader'></div>
                    </div>
                  <div id="box-payplus-payment" style="display: none">
                      <iframe   scrolling="no" src="" style="width: 100%;height: 900px"></iframe>
                  </div>

                <?php
                $output = ob_get_clean();
                echo  $output;
            }

            public  function ajax_payplus_token_payment(){
                global  $wp_version;
                $totalCartAmount =0;
                $urlEdit=site_url();
                if(!empty($_POST)) {
                    $postPayPlus =$_POST;
                    $WC_PayPlus_Gateway = new WC_PayPlus_Gateway();
                    $order_id=$postPayPlus['payplus_order_id'];
                    $payplusTokenPayment=$postPayPlus['payplus_token_payment'];
                    $payplusChargeAmount =$postPayPlus['payplus_charge_amount'];
                    $urlEdit= get_admin_url()."post.php?post=".$order_id."&action=edit";
                    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                        wp_die();
                    }

                    if (!($payplusTokenPayment) || !$payplusChargeAmount) {
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                        wp_die();
                    }
                    $order = wc_get_order($order_id);
                    $order_user_id = $order->get_user_id();

                    // get this order's user's discount %


                    $totallCart =floatval($order->get_total()) ;
                    $charged_amount = 0;
                    $charged_amount = (float)$order->get_meta('payplus_charged_j5_amount');

                    if ($charged_amount) return;
                    $OrderType = $order->get_meta('payplus_type');

                    $chargeByItems = false;
                    $amount = round((float)$payplusChargeAmount, 2);
                    $transaction_uid = $order->get_meta('payplus_transaction_uid');
                    if ($OrderType == "Charge") { echo $urlEdit;
                        wp_die();
                    }

                    if ($amount > $order->get_total()) {
                        $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Cannot Charge then original order');
                        $order->add_order_note(sprintf(__('Cannot Charge then original order sum', 'payplus-payment-gateway'), $charged_amount, $order->get_currency()));
                        echo $urlEdit;
                        wp_die();
                    }

                    if ($OrderType != "Approval" and $OrderType != "Check") {
                        $order->add_order_note(sprintf(__('The charge in PayPlus already made. Please check your PayPlus account<br />Amount: %s %s', 'payplus-payment-gateway'), $charged_amount, $order->get_currency()));
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                        wp_die();
                    }

                    if ($OrderType != "Approval" and $OrderType != "Check") {
                        $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Transaction Not J5 Or Changed to J4 After Charge');
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                        wp_die();
                    }
                    $items="";

                    if ($amount == $order->get_total() and $charged_amount == 0) {

                        $chargeByItems = true;
                        $objectProducts =$WC_PayPlus_Gateway->payplus_get_products_by_order_id($order_id,false);
                        $items= $objectProducts->productsItems ;


                    }

                    $payplusRefunded =get_post_meta($order_id,'payplus_refunded',true);
                    if(!$payplusRefunded) {
                        $payplusRefunded =add_post_meta($order_id,'payplus_refunded',$order->get_total());
                    }

                    $totalCartAmount =$objectProducts->amount;
                   /* $payload = '{
                        "transaction_uid": "' . $transaction_uid . '",
                        ' . ($WC_PayPlus_Gateway->send_add_data ? '"add_data": "' . $order_id . '",' : '') . '
                        "amount": "' . ($chargeByItems ? $totalCartAmount : $amount) . '",
                                   '. ($chargeByItems ? '
                                    "items": [
                                                ' . implode(",", $objectProducts->productsItems) . '
                                            ],' : '') . ' 
                        "more_info": "' . __('Charge for Order Number: ', 'payplus-payment-gateway') . $order_id . '"
                        }';
*/
                    $payload['transaction_uid']=   $transaction_uid ;
                    $payload['amount']=   $chargeByItems ? $totalCartAmount : $amount ;
                    if($WC_PayPlus_Gateway->send_add_data){
                        $payload['add_data']=   $order_id ;
                    }
                    if($chargeByItems){
                        $payload['items']=   $items ;
                    }
                    $payload =json_encode($payload);


                    $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Invoice PayPlus  Fired: (' .$order_id.")");
                    $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Sending Request: ' . print_r($payload, true));
                    $response = $WC_PayPlus_Gateway->post_payplus_ws($WC_PayPlus_Gateway->api_url . 'Transactions/ChargeByTransactionUID', $payload );

                    if (is_wp_error($response)) {
                        $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Charge Remote Post Error: ' . print_r($response, true));
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                        wp_die();
                    }else {

                        $res = json_decode(wp_remote_retrieve_body($response));
                        if ($res->results->status == "success" && $res->data->transaction->status_code == "000") {

                            if($WC_PayPlus_Gateway->payplus_check_all_product($order,"1")){
                                update_post_meta($order_id, 'payplus_transaction_type', "1");
                            }
                            if($WC_PayPlus_Gateway->payplus_check_all_product($order,"2")){
                                update_post_meta($order_id, 'payplus_transaction_type', "2");
                            }
                            update_post_meta($order_id, 'payplus_charged_j5_amount', $amount);
                            $keyMethod=get_post_meta($order_id,'payplus_alternative_method_name',true);
                            if(empty($keyMethod)){
                                $keyMethod=get_post_meta($order_id,'payplus_method',true);
                            }

                            update_post_meta($order_id, 'payplus_'.$keyMethod, $amount);
                            update_post_meta($order_id, 'payplus_type', 'Charge');
                            update_post_meta($order_id, 'payplus_number', $res->data->transaction->number);
                            update_post_meta($order_id, 'payplus_transaction_uid', $res->data->transaction->uid);
                            update_post_meta($order_id, 'payplus_status_code', $res->data->transaction->status_code);
                            update_post_meta($order_id, 'payplus_number_of_payments', $res->data->transaction->payments->number_of_payments);
                            update_post_meta($order_id, 'payplus_first_payment_amount', $res->data->transaction->payments->first_payment_amount);
                            update_post_meta($order_id, 'payplus_payments_rest_payments_amount', $res->data->transaction->payments->rest_payments_amount);
                            update_post_meta($order_id, 'payplus_auth_num', trim($res->data->transaction->approval_number));
                            if(property_exists($res->data->transaction,'voucher_number')){
                                update_post_meta($order_id, 'payplus_voucher_num', trim($res->data->transaction->voucher_number));
                            }
                            if(property_exists($res->data->transaction,'alternative_method_name')){
                                update_post_meta($order_id, 'payplus_alternative_method_name', trim($res->data->transaction->alternative_method_name));
                            }


                            $order->add_order_note(sprintf(__('PayPlus Charge is Successful<br />Charge Transaction Number: %s<br />Amount: %s %s', 'payplus-payment-gateway'), $res->data->transaction->number, $res->data->transaction->amount, $order->get_currency()));
                            $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Charge Remote Post Completed: ' . print_r($res, true)."\n".$this->payplus_get_space());
                            $_POST['order_status'] = $order->needs_processing() ? 'wc-processing' : 'wc-completed';
                            $order->payment_complete();
                            echo json_encode(array("urlredirect"=>$urlEdit,"status"=>true));
                            wp_die();
                        } else {
                            $order->add_order_note(sprintf(__('PayPlus Charge is Failed<br />Status: %s<br />Description: %s', 'payplus-payment-gateway'), $res->results->status, $res->results->description));
                            $WC_PayPlus_Gateway->logging->add('payplus_process_j5_payment', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Charge Remote Post Error: ' . print_r($res, true)."\n".$this->payplus_get_space()."\n".$this->payplus_get_space());
                            $WC_PayPlus_Gateway->error_msg = 2;
                            echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                            wp_die();
                        }
                    }
                    add_filter('redirect_post_location', [$this, 'add_notice_query_var'], 99);

                }
                echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                echo $urlEdit;
                wp_die();

            }

            public function load_admin_assets(){
                $enabled =false;
                $isInvoice =false;
                if(!empty($_GET) &&!empty($_GET['section'])){
                    $currentSection =$_GET['section'];
                    $currentPayment = get_option('woocommerce_'.$currentSection.'_settings');
                    $enabled =($currentPayment['enabled']==="yes")?false:true;
                    $isInvoice = (!empty($_GET['invoicepayplus'])&& $_GET['invoicepayplus']==="1")?true:false;
                }


                wp_enqueue_style('payplus', PAYPLUS_PLUGIN_URL . 'assets/css/admin.min.css', [], PAYPLUS_VERSION);
                    wp_register_script('payplus-admin-payment', PAYPLUS_PLUGIN_URL . '/assets/js/admin-payments.js', ['jquery'], PAYPLUS_VERSION, true);
                    wp_localize_script( 'payplus-admin-payment', 'payplus_script_admin',
                        array( 'ajax_url' => admin_url( 'admin-ajax.php' ),'error_payment'=>__('Cannot Charge then original order sum', 'payplus-payment-gateway'),
                            "refund_amount"=>__("Refund amount (multipass):(max amount :",'payplus-payment-gateway'),
                             "payplus_title_tab" =>array(
                                     "tab-payplus-error-page"=>__('PayPlus Page Error - Settings', 'payplus-payment-gateway'),
                                 "tab-invoice-payplus" =>__('Invoice+ (PayPlus)', 'payplus-payment-gateway')),
                            "payplus_enabled_payment" =>$enabled,
                            "payplus_invoice" =>$isInvoice

                            ) );
                    wp_enqueue_script('payplus-admin-payment');
            }

            public function make_payment_button($post_id)
            {



                if (!in_array(get_post_meta($post_id, 'payplus_type', true),["Approval","Check"])) {

                    return;
                }
                $order = wc_get_order($post_id);
                $total = $order->get_total();
                $WC_PayPlus_Gateway =new WC_PayPlus_Gateway();
            //    $style =($WC_PayPlus_Gateway->check_amount_authorization)?"style='visibility: hidden;width:0px;padding:0px;margin:0px;border:0px'":"";
                $class = ($WC_PayPlus_Gateway->check_amount_authorization)?'payplus-visibility':'';
                echo "<li class='wide delayed-payment'>
                    <h3>" . __('Charge Order Using PayPlus', 'payplus-payment-gateway') . "</h3>
                        <input class='".$class."'  data-amount='".$total."'  type='number' id='payplus_charge_amount' name='payplus_charge_amount' value='" . $total . "' min='0' max='" . $total . "' step='0.01' required />
                        <input type='hidden' id='payplus_order_id' name='payplus_order_id' value='".$post_id."'>
                        <button id='payplus-token-payment' type='button' name='payplus-token-payment' class='button button-primary'><span class='dashicons dashicons-cart'></span> " . __('Make Payment', 'payplus-payment-gateway') . "</button>
                <div class='payplus_error'></div>   
                </li>
            
                <div class='payplus_loader'></div>";
                /*echo '<script>
                jQuery("button[name=payplus-token-payment]").on(\'click\', function() {
                    jQuery("button[name=payplus-token-payment]").html("<span class=\'dashicons dashicons-cart\'></span> ' . __('Please wait', 'payplus-payment-gateway') . '...");
                    setTimeout(function(){
                        jQuery("button[name=payplus-token-payment]").prop("disabled",true);
                        },1
                        );
                    });
                </script>';*/
            }

            public function process_make_payment($order_id)
            {
                if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
                if (!isset($_POST['payplus-token-payment'])) return;
                $order = wc_get_order($order_id);
                $charged_amount = 0;
                $charged_amount = (float)$order->get_meta('payplus_charged_j5_amount');
                if ($charged_amount) return;
                $OrderType = $order->get_meta('payplus_type');
                $chargeByItems = false;
                $amount = round((float)$_POST['payplus_charge_amount'], 2);
                $transaction_uid = $order->get_meta('payplus_transaction_uid');
                if ($OrderType == "Charge") return;

                if ($amount > $order->get_total()) {
                    $this->logging->add('payplus_process_j5_payment', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Cannot Charge then original order');
                    $order->add_order_note(sprintf(__('Cannot Charge then original order sum', 'payplus-payment-gateway'), $charged_amount, $order->get_currency()));
                    return false;
                }

                if ($OrderType != "Approval" and $OrderType != "Check") {
                    $order->add_order_note(sprintf(__('The charge in PayPlus already made. Please check your PayPlus account<br />Amount: %s %s', 'payplus-payment-gateway'), $charged_amount, $order->get_currency()));
                    return false;
                }

                if ($OrderType != "Approval" and $OrderType != "Check") {
                    $this->logging->add('payplus_process_j5_payment', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Transaction Not J5 Or Changed to J4 After Charge');
                    return false;
                }

                if ($amount == $order->get_total() and $charged_amount == 0) {
                    $chargeByItems = true;
                    $objectProducts =$this->payplus_get_products_by_order_id($order_id);


                }
                $totalCartAmount =round($objectProducts->amount,$this->rounding_decimals);
                $payload = '{
                        "transaction_uid": "' . $transaction_uid . '",
                        ' . ($this->send_add_data ? '"add_data": "' . $order_id . '",' : '') . '
                        "amount": "' . ($chargeByItems ? $totalCartAmount : $amount) . '",
                        ' . ($chargeByItems ? '
                        "items": [
                            ' . implode(",", $objectProducts->productsItems) . '
                            ]' : '
                        "more_info": "' . __('Charge for Order Number: ', 'payplus-payment-gateway') . $order_id . '"
                        ') . '
                        }';
                if ($this->api_test_mode) $apiURL = 'https://restapidev.payplus.co.il/api/v1.0/';
                else $apiURL = 'https://restapi.payplus.co.il/api/v1.0/';

                $this->logging->add('payplus_process_j5_payment', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Sending Request: ' .  print_r($payload, true));

                $response = $this->post_payplus_ws($apiURL . 'Transactions/ChargeByTransactionUID', $payload);
                $res = json_decode(wp_remote_retrieve_body($response));
                if ($res->results->status == "success" && $res->data->transaction->status_code == "000") {
                    update_post_meta($order_id, 'payplus_charged_j5_amount', $amount);
                    update_post_meta($order_id, 'payplus_type', 'Charge');
                    update_post_meta($order_id, 'payplus_number', $res->data->transaction->number);
                    update_post_meta($order_id, 'payplus_transaction_uid', $res->data->transaction->uid);
                    update_post_meta($order_id, 'payplus_status_code', $res->data->transaction->status_code);
                    update_post_meta($order_id, 'payplus_number_of_payments', $res->data->transaction->payments->number_of_payments);
                    update_post_meta($order_id, 'payplus_first_payment_amount', $res->data->transaction->payments->first_payment_amount);
                    update_post_meta($order_id, 'payplus_payments_rest_payments_amount', $res->data->transaction->payments->rest_payments_amount);
                    update_post_meta($order_id, 'payplus_auth_num', trim($res->data->transaction->approval_number));
                    update_post_meta($order_id, 'payplus_voucher_num', trim($res->data->transaction->voucher_number));

                    $order->add_order_note(sprintf(__('PayPlus Charge is Successful<br />Charge Transaction Number: %s<br />Amount: %s %s', 'payplus-payment-gateway'), $res->data->transaction->number, $res->data->transaction->amount, $order->get_currency()));
                    $this->logging->add('payplus_process_j5_payment', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Charge Remote Post Completed: ' .  print_r($res, true));
                    $_POST['order_status'] = $order->needs_processing() ? 'wc-processing' : 'wc-completed';
                    $order->payment_complete();
                } else {
                    $order->add_order_note(sprintf(__('PayPlus Charge is Failed<br />Status: %s<br />Description: %s', 'payplus-payment-gateway'), $res->results->status, $res->results->description));
                    $this->logging->add('payplus_process_j5_payment', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Charge Remote Post Error: ' . print_r($res, true));
                    $this->error_msg = 2;
                }
                add_filter('redirect_post_location', [$this, 'add_notice_query_var'], 99);
            }

            public function post_payplus_ws($url, $payload=array() ,$method ="post")
            {

                $args = array(
                    'body' => $payload,
                    'timeout'     => '60',
                    'redirection' => '5',
                    'httpversion' => '1.0',
                    'blocking'    => true,
                    'headers'     => [],
                    'headers' => array(
                        'Content-Type' => 'application/json',
                        'User-Agent' => 'WordPress',
                        'Authorization' => '{"api_key":"' . $this->api_key . '","secret_key":"' . $this->secret_key . '"}'
                    )
                );
                $response = wp_remote_post($url, $args);
                return $response;
            }

            public function add_notice_query_var($location)
            {
                remove_filter('redirect_post_location', [$this, 'add_notice_query_var'], 99);

                return add_query_arg(['error_msg' => $this->error_msg], $location);
            }

            public function admin_notices()
            {
                if (!isset($_GET['error_msg'])) {
                    return;
                }

                $title = __('PayPlus Payment Gateway', 'payplus-payment-gateway');
                $class = 'notice-error';
                switch ($_GET['error_msg']) {
                    case 1:
                        $message = __('user or other, please contact payplus support', 'payplus-payment-gateway');
                        break;
                    case 2:
                        $message = __('Credit card company declined, check credit card details and credit line', 'payplus-payment-gateway');
                        break;
                    default:
                        $message = __('PayPlus Payment Successful', 'payplus-payment-gateway');
                        $class   = 'notice-success';
                }
                $output = "<div class='notice $class is-dismissible'><p><b>$title:</b> $message</p></div>";

                echo $output;
            }

            public function add_removable_arg($args)
            {
                $args[] = 'error_msg';

                return $args;
            }
        }
        WC_PayPlus_Admin_Payments::get_instance();