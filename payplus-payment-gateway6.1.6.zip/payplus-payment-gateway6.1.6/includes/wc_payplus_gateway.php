<?php

//use Automattic\Jetpack\Constants;
defined('ABSPATH') || exit; // Exit if accessed directly
define("COUNT_PAY_PLUS",3);
define('MULTIPASS',"multipass");
define('CREDIT_CARD','credit-card');
define('PAYPLUS_PAYMNET_URL_PRODUCTION','https://restapi.payplus.co.il/api/v1.0/');
define('PAYPLUS_PAYMNET_URL_DEV','https://restapidev.payplus.co.il/api/v1.0/');
class WC_PayPlus_Gateway extends WC_Payment_Gateway_CC
{
	public $id = 'payplus-payment-gateway';
    public $invocie_api;

	public function __construct()
	{
		// class setup
		$this->has_fields         = false;
		$this->method_title       = __('PayPlus', 'payplus-payment-gateway');
		$this->method_description = __('PayPlus Credit Card Secure Payment', 'payplus-payment-gateway');
		$this->supports           = [
			'products',
			'subscriptions',
			'subscription_cancellation',
			'subscription_suspension',
			'subscription_reactivation',
			'subscription_amount_changes',
			'subscription_date_changes',
			'subscription_payment_method_change',
			'subscription_payment_method_change_customer',
			'subscription_payment_method_change_admin',
			'multiple_subscriptions',
			'refunds',
			'pre-orders',
			'tokenization',
		];

		// load assets
		add_action('admin_enqueue_scripts', [$this, 'load_admin_assets']);
		add_action('wp_enqueue_scripts', [$this, 'load_checkout_assets']);

		// define user set variables


        $this->add_product_field_transaction_type      =
            $this->get_option('add_product_field_transaction_type')=="yes" ?true :false;


		$this->title             = $this->get_option('title');
		$this->description       = $this->get_option('description');
		$this->api_test_mode     = $this->get_option('api_test_mode') == 'yes' ? true : false;
		$this->api_key           = $this->get_option('api_key');
		$this->secret_key 		 = $this->get_option('secret_key');
		$this->payment_page_id 	 = $this->get_option('payment_page_id');
		$this->rounding_decimals = $this->get_option('rounding_decimals');
		$this->single_quantity_per_line = $this->get_option('single_quantity_per_line');
		// - PayPlus Payment Options
		$this->hide_icon 			 = $this->get_option('hide_icon');
		$this->transaction_type 	 = $this->get_option('transaction_type');
		$this->disable_woocommerce_scheduler 	 = $this->get_option('disable_woocommerce_scheduler');
		$this->initial_invoice 		 = $this->get_option('initial_invoice');

		$this->paying_vat 	 	 	 = $this->get_option('paying_vat');
		$this->paying_vat_iso_code	 = $this->get_option('paying_vat_iso_code');
		$this->foreign_invoices_lang = $this->get_option('foreign_invoices_lang');
		$this->send_products 		 = $this->get_option('send_products') == 'yes' ? true : false;
        $this->exist_company =  $this->get_option('exist_company') == 'yes' ? true : false;

		if ($this->hide_icon == "no") {
			$this->icon = PAYPLUS_PLUGIN_URL . 'assets/images/payplus.svg';
		}

		// - PayPlus Display Mode
		$this->display_mode  			= $this->get_option('display_mode');
		$this->iframe_height  			= $this->get_option('iframe_height');
		$this->import_applepay_script   = $this->get_option('import_applepay_script') == 'yes' ? true : false;
		if ($this->display_mode === 'samePageIframe' && !$this->description) {
			$this->description = $this->title;
		}
        $this->update_option('logging','yes');

		// - PayPlus Settings Options
		$this->use_ipn     	 		  	= true;
		$this->send_variations     	 	= $this->get_option('send_variations') == 'yes' ? true : false;
		$this->create_pp_token     	  	= $this->get_option('create_pp_token') == 'yes' ? true : false;
		$this->send_add_data 	  		= $this->get_option('send_add_data') == 'yes' ? true : false;
		$this->hide_identification_id 	= $this->get_option('hide_identification_id');
		$this->vat_number_field 	= $this->get_option('vat_number_field');
		$this->hide_payments_field 	  	= $this->get_option('hide_payments_field');
		$this->default_charge_method 	= $this->get_option('default_charge_method');
		$this->hide_other_charge_methods = $this->get_option('hide_other_charge_methods');
		$this->sendEmailApproval 	  	= $this->get_option('sendEmailApproval');
		$this->sendEmailFailure 	  	= $this->get_option('sendEmailFailure');
		$this->recurring_order_set_to_paid 	  	= $this->get_option('recurring_order_set_to_paid');
		$this->paying_vat 	  			= $this->get_option('paying_vat');
		$this->successful_order_status 	= $this->get_option('successful_order_status');
		$this->failure_order_status 	= $this->get_option('failure_order_status');
		$this->callback_addr 	= $this->get_option('callback_addr');
		$this->logging     	  			=   wc_get_logger();
		$this->fire_completed     	  	= $this->get_option('fire_completed') == 'yes' ? true : false;
		$this->invoice_lang 			= $this->get_option('invoice_lang') == 'en' ? 'en' : '';
		$this->response_url        = add_query_arg('wc-api', 'payplus_gateway', home_url('/'));

        $this->payplus_generate_page_error();
        $payplusLinkError =get_permalink( get_option('error_page_payplus'));

        $this->payplus_generate_key_dashboard=$this->payplus_generate_key_dashboard();
        $this->response_error_url =$payplusLinkError;
		$this->add_payment_res_url = add_query_arg('wc-api', 'payplus_add_payment', home_url('/'));

		// save admin options
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);

        // receipt page for iframe
		add_action('woocommerce_receipt_' . $this->id, [$this, 'receipt_page']);

        // handle ipn response
		add_action('woocommerce_api_payplus_gateway', [$this, 'ipn_response']);

        add_action('woocommerce_api_callback_response', [$this, 'callback_response']);

		// handle add cc ipn response
		add_action('woocommerce_api_payplus_add_payment', [$this, 'add_payment_ipn_response']);

		add_action('woocommerce_api_response_callback', [$this, 'response_callback']);

        add_action( 'admin_init',[$this, 'payplus_hide_editor'] );
		// Message for SandBox if Active

		add_action('woocommerce_before_checkout_form', [$this, 'msg_checkout_code']);
        add_filter ('user_has_cap',[$this, 'payplus_disbale_page_delete'], 10, 3);

        add_filter( 'page_row_actions', [$this,'payplus_remove_row_actions_post'], 10, 1 );

        // Subscription Handler
        if (class_exists('WC_Subscriptions_Order') && $this->disable_woocommerce_scheduler !== 'yes' ) {

            add_action('woocommerce_scheduled_subscription_payment_' . $this->id, array($this, 'scheduled_subscription_payment'), 10, 2);
        }
        // load settings
        $apiURL =($this->api_test_mode)?PAYPLUS_PAYMNET_URL_DEV :PAYPLUS_PAYMNET_URL_PRODUCTION;
        $this->payment_url 		   = $apiURL . 'PaymentPages/generateLink';
        $this->ipn_url             = $apiURL . 'PaymentPages/ipn';

        $this->refund_url          = $apiURL . 'Transactions/RefundByTransactionUID';


        if((!empty($_POST)) && !empty($_POST['settings_payplus_page_error_option'])){
            $settingsPayplusPageErrorOption =$_POST['settings_payplus_page_error_option'];
            unset($settingsPayplusPageErrorOption['select-languages-payplus']);
            $settingsPayplusPageErrorOption = array_filter($settingsPayplusPageErrorOption);
            update_option('settings_payplus_page_error_option',$settingsPayplusPageErrorOption);
        }
        if(empty( get_option('settings_payplus_page_error_option'))){
            $settingsPayplusPageErrorOption= array("he_IL-Hebrew"=> "העיסקה נכשלה, נא ליצור קשר עם בית העסק",
                "en_US_-English"=>"The transaction failed, please contact the seller" );
            update_option('settings_payplus_page_error_option',$settingsPayplusPageErrorOption);
        }

        if($this->add_product_field_transaction_type){
            add_action( 'add_meta_boxes', [$this,'payplus_add_product_meta_box_transaction_type' ]);
            add_action( 'save_post', [$this, 'payplus_save_transaction_type_meta_box_data'] );
            add_action( 'manage_product_posts_columns', [$this ,'payplus_add_order_column_order_product'],100 );
            add_filter( 'manage_edit-shop_order_columns', [$this,'payplus_add_order_column_orders'], 20);

        }

        $this ->invocie_api = new   PayplusInvoice();

        if(!empty($_POST['payplus_invoice_option'])){

            update_option('payplus_invoice_option',$_POST['payplus_invoice_option']);
        }

        $this->init_form_fields();
        $this->init_settings();


    }

    public function  payplus_add_order_column_orders($columns){

            $new_columns = array();
            foreach ( $columns as $column_name => $column_info ) {
                $new_columns[$column_name] = $column_info;
                if ('shipping_address' === $column_name  && $this->enabled==="yes") {
                    $new_columns['payplus_transaction_type'] = "<span class='text-center'>" . __('Transaction Type ', 'payplus-payment-gateway') . "</span>";
                }
            }
            return $new_columns;
    }

    public function payplus_add_order_column_order_product ($columns){
        $new_columns = array();
        foreach ( $columns as $column_name => $column_info ) {
            $new_columns[$column_name] = $column_info;
            if ('price' === $column_name  && $this->enabled ==="yes") {
                $new_columns['payplus_transaction_type'] = "<span class='text-center'>" . __('Transaction Type ', 'payplus-payment-gateway') . "</span>";
            }
        }
        return $new_columns;
    }

    public  function  payplus_save_transaction_type_meta_box_data( $post_id ){
        // Check if our nonce is set.
        if ( ! isset( $_POST['payplus_notice_proudct_nonce'] ) ) {
            return;
        }
        // Verify that the nonce is valid.
        if ( ! wp_verify_nonce( $_POST['payplus_notice_proudct_nonce'], 'payplus_notice_proudct_nonce' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( isset( $_POST['post_type'] ) && 'product' == $_POST['post_type'] ) {

            if (!current_user_can('edit_post', $post_id)) {

                return;
            }

        }
        if ( ! isset( $_POST['payplus_transaction_type'] ) ) {
            return;
        }
        $transaction_type = sanitize_text_field( $_POST['payplus_transaction_type'] );
        update_post_meta( $post_id, 'payplus_transaction_type', $transaction_type );
    }

    public  function  payplus_add_product_meta_box_transaction_type(){
        global  $post;
        if(!empty($post) && get_post_type()==="product") {
            $product= wc_get_product($post->ID);
            $typeProducts =array('variable-subscription','subscription');
            if(!in_array($product->get_type(),$typeProducts)) {
                add_meta_box(
                    'payplus_transaction_type',
                    __('Transaction Type', 'payplus-payment-gateway'),
                    [$this, 'payplus_meta_box_product_transaction_type'],
                    'product'
                );
            }
        }
    }

    public function  payplus_meta_box_product_transaction_type($post){

            ob_start();
            wp_nonce_field('payplus_notice_proudct_nonce', 'payplus_notice_proudct_nonce');
            $transactionTypeValue = get_post_meta($post->ID, 'payplus_transaction_type', true);

            $transactionTypes = array('1' => __('Charge', 'payplus-payment-gateway'),
                '2' => __('Authorization', 'payplus-payment-gateway'));
            echo "<select id='payplus_transaction_type' name='payplus_transaction_type'>";
            echo "<option value=''>" . __('Transactions Type', 'payplus-payment-gateway') . "</option>";
            foreach ($transactionTypes as $key => $transactionType) {
                $selected = ($transactionTypeValue == $key) ? "selected" : "";
                echo "<option " . $selected . " value='" . $key . "'>" . $transactionType . "</option>";
            }
            echo "</select>";

            echo ob_get_clean();

    }

    public function payplus_get_posts_id( $post_id="",$fields=array() ) {
        global $wpdb;
        $sql ="SELECT *  FROM " .$wpdb->posts;
        $where="";
        if($post_id || count($fields)){
            if($post_id){
                $where.=" ID=" .$post_id;
            }
            foreach ($fields as $key =>$value){
                $where.= ($where)? " And ".$key."='".$value."'":$key."='".$value."'";
            }

        }
        if($where){
            $sql.=" where ".$where;

        }
        $posts = $wpdb->get_results( $sql );
        return $posts;
    }

    public function payplus_from_error_page_setting(){
        ob_start();
        echo $this->payplus_select_error_langrage();
        $form_error_page = ob_get_clean();
        return $form_error_page;
    }

    public function  payplus_select_error_langrage(){

        require_once( ABSPATH . 'wp-admin/includes/translation-install.php' );
        $languages=wp_get_available_translations();

        $optionlanguages =get_option('settings_payplus_page_error_option');
        ?>
            <label>
                <b  style="font-weight: bold;font-size: 20px;"><?php echo  __('Language of the page','payplus-payment-gateway') ?>:</b>
            </label>
            <br>
        <br>
            <select name="settings_payplus_page_error_option[select-languages-payplus]" id="select-languages-payplus">
                <option value=""><?php echo  __('Language of the page','payplus-payment-gateway')  ?>:</option>
            <?php
        foreach ($languages as $key =>$language){

             $name= $language['native_name'];

             if($name!==$language['english_name']){
                 $name.=" - " .$language['english_name'];
             }
            ?>
            <option value="<?php echo $key."-".$language['english_name'] ?>"><?php echo $name?></option>

            <?php
        }
        ?></select>
        <br>

            <table id="payplus-add-language"  class="form-table">
                <tr>
                    <th> <?php  echo __( "Hebrew","payplus-payment-gateway")  ?>: </th>
                    <td> <textarea rows="3" cols="45" name="settings_payplus_page_error_option[he_IL-Hebrew]" ><?php echo ( !empty($optionlanguages['he_IL-Hebrew'])) ?$optionlanguages['he_IL-Hebrew']: "העיסקה נכשלה, נא ליצור קשר עם בית העסק" ?></textarea> </td>
                </tr>
                <tr>
                    <th> <?php  echo __( "English", "payplus-payment-gateway")  ?>: </th>
                    <td> <textarea rows="3" cols="45"  name="settings_payplus_page_error_option[en_US_-English]" ><?php echo ( !empty($optionlanguages['en-US-English'])) ?$optionlanguages['he_IL-Hebrew']: "The transaction failed, please contact the seller" ?></textarea> </td>
                </tr>
                <?php
                    if( $optionlanguages){
                        foreach ($optionlanguages as $key =>$optionlanguage){
                            if($key!='en_US_-English' && $key!="he_IL-Hebrew"):
                                $otherKey =explode("-",$key);
                            ?>
                            <tr>
                                <th> <?php  echo $otherKey[1] ?> : </th>
                                <td> <textarea rows="3" cols="45" class="" name="settings_payplus_page_error_option[<?php echo $key ?>]" ><?php echo $optionlanguage?></textarea> </td>
                            </tr>

                                <?php
                            endif;

                        }
                    }

                ?>
            </table>

      <?php


    }

    public  function payplus_error_page_header_option(){
        print "<h1>". __('PayPlus Settings Page Error', 'payplus-payment-gateway')."</h1>";

    }

    public function  payplus_remove_row_actions_post( $actions){
        global  $post;
        $post_error_page = get_option('error_page_payplus');

        if($post_error_page ==$post->ID){
            unset( $actions['clone'] );
            unset( $actions['trash'] );
        }
        return $actions;
    }

    public function  payplus_hide_editor(){

        $post_error_page = get_option('error_page_payplus');
        $post_id = (!empty($_GET['post'] ))? $_GET['post'] : "" ;
        if( !isset( $post_id ) ) return;

        if($post_id==$post_error_page){
            remove_post_type_support('page', 'editor');
            remove_post_type_support('page', 'thumbnail');
            remove_post_type_support('page', 'page-attributes');

        }

    }

    public function payplus_disbale_page_delete($allcaps, $caps, $args) {
        $post_id = get_option('error_page_payplus');
        if ( isset( $args[0] ) && isset( $args[2] ) && $args[2] == $post_id  && ( $args[0] == 'delete_post' || $args[0] == 'edit_pages')) {

            $allcaps[ $caps[0] ] = false;
        }
        return $allcaps;
    }

    public  function payplus_generate_page_error(){
        $error_page_payplus =get_option('error_page_payplus');
        $errorPagePayPlus= get_post($error_page_payplus);
        if(!$errorPagePayPlus){
            $errorPagePayPlus = wp_insert_post(array('post_status'    => 'publish','post_type'      => 'page',
                    'post_title'     => ucwords('error payment payplus'),"post_content"=>"[error-payplus-content]"));
            update_option('error_page_payplus',$errorPagePayPlus);
        }
    }

    public  function payplus_generate_key_dashboard(){
        $dashboardKey =get_option('payplus_generate_key_link_dashboard');

        if(empty($dashboardKey)){
            $dashboardKey =wp_generate_password(50,false);
           add_option('payplus_generate_key_link_dashboard',$dashboardKey);
        }
        return $dashboardKey;
    }

	public function load_checkout_assets()
	{
		wp_register_script('applePay','https://payments' . ($this->api_test_mode ? 'dev' : '') . '.payplus.co.il/statics/applePay/script.js');
		if (is_checkout()) {
			wp_scripts()->registered['wc-checkout']->src = PAYPLUS_PLUGIN_URL . 'assets/js/checkout.min.js';
			if ($this->import_applepay_script && in_array($this->display_mode,['samePageIframe','popupIframe'])) {
				wp_enqueue_script('applePay');
			}
		}

		wp_enqueue_style('alertifycss', '//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css', array(), false, 'all');

		wp_register_script('alertifyjs', '//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js', array('jquery'), false, true);
		wp_enqueue_script('alertifyjs');
	}

    // load admin assets
	public function load_admin_assets()
	{
		wp_enqueue_script('wc-payplus-gateway-admin', PAYPLUS_PLUGIN_URL . 'assets/js/admin.min.js', ['jquery'], PAYPLUS_VERSION, true);
	}

    // init form fields
	public function init_form_fields()
	{
        $listOrderStatus=['default-woo'=> __( 'Default Woo', 'payplus-payment-gateway' )] ;
        $listOrderStatus =array_merge($listOrderStatus, wc_get_order_statuses());
        $this->form_fields = [
			'enabled'           => [
				'title'   => __( 'Enable/Disable', 'payplus-payment-gateway' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable PayPlus+ Payment', 'payplus-payment-gateway' ),
				'default' => 'yes'
			],
			'title'             => [
				'title'       => __('Title', 'payplus-payment-gateway'),
				'type'        => 'text',
				'description' => __('This controls the title which the user sees during checkout', 'payplus-payment-gateway'),
				'default'     => __('Pay with Debit or Credit Card', 'payplus-payment-gateway'),
				'desc_tip'    => true,
			],
			'description'       => [
				'title'   => __('Description', 'payplus-payment-gateway'),
				'type'    => 'textarea',
				'default' => __('Pay securely by Debit or Credit Card through PayPlus', 'payplus-payment-gateway')
			],
			'settings_title'      => [
				'title' => __('PayPlus API Settings', 'payplus-payment-gateway'),
				'type'  => 'title',
			],
			'api_test_mode'     => [
				'title' => __('Test mode', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('Enable Sandbox Mode', 'payplus-payment-gateway'),
			],
			'api_key'         => [
				'title'       => __('API KEY', 'payplus-payment-gateway'),
				'type'        => 'text',
				'description' => __('PayPlus API Key you can find in your account under Settings', 'payplus-payment-gateway'),
				'default'     => '',
				'desc_tip'    => true,
			],
			'secret_key'         => [
				'title'       => __('SECRET KEY', 'payplus-payment-gateway'),
				'type'        => 'text',
				'description' => __('PayPlus Secret Key you can find in your account under Settings', 'payplus-payment-gateway'),
				'default'     => '',
				'desc_tip'    => true,
			],
			'payment_page_id'         => [
				'title'       => __('Payment Page UID', 'payplus-payment-gateway'),
				'type'        => 'text',
				'description' => __('Your payment page UID can be found under Payment Pages in your side menu in PayPlus account', 'payplus-payment-gateway'),
				'default'     => '',
				'desc_tip'    => true,
			],
			'params_title'      => [
				'title' => __('PayPlus Payment Options', 'payplus-payment-gateway'),
				'type'  => 'title',
			],
			'transaction_type'      => [
				'title'   => __('Transactions Type', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('Payment Page Default Setting', 'payplus-payment-gateway'),
					'1'   => __('Charge', 'payplus-payment-gateway'),
					'2'   => __('Authorization', 'payplus-payment-gateway')
				],
				'default' => '1',
			],
            'disable_woocommerce_scheduler' => [
                'title'       => __('Disable woocommerce scheduler', 'payplus-payment-gateway'),
                'type'        => 'checkbox',
                'default'     => 'no'
            ],

			'invoice_display_title'     => [
				'title' => __('Invoicing & Documents Settings', 'payplus-payment-gateway'),
				'type'  => 'title',
			],
			'send_products'     => [
				'title' => __('Hide Products To Invoices and Documents', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('Hide Products To Invoices and Documents', 'payplus-payment-gateway')
			],
			'send_variations'     => [
				'title' => __('Send product variations among with products (for invoices)', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('Send product variations among with products (for invoices)', 'payplus-payment-gateway')
			],
			'initial_invoice'      => [
				'title'   => __('Initial Invoice / Receipt', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('Payment Page Default Setting', 'payplus-payment-gateway'),
					'1'   => __('Yes', 'payplus-payment-gateway'),
					'2'   => __('No', 'payplus-payment-gateway')
				],
				'default' => '0',
			],
			'rounding_decimals'         => [
				'title'       => __('Rounding Product Decimals', 'payplus-payment-gateway'),
				'type'        => 'number',
				'default'     => 2
			],
			'single_quantity_per_line'         => [
				'title'       => __('Send every line as a single item', 'payplus-payment-gateway'),
				'type'        => 'checkbox',
				'default'     => 'no'
			],
			'paying_vat'      => [
				'title'   => __('Invoice For Foreign Customers', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('Paying VAT', 'payplus-payment-gateway'),
					'1'   => __('Exempt VAT', 'payplus-payment-gateway'),
					'2'   => __('Exempt VAT If Customer Billing ISO Country Is Different Than...', 'payplus-payment-gateway')
				],
				'default' => '0',
			],
			'paying_vat_iso_code'     => [
				'title'   => __('Your Business VAT Registration Country ISO Code', 'payplus-payment-gateway'),
				'type'    => 'text',
				'default' => 'IL'
			],
			'vat_number_field'     => [
				'title'   => __('Custom checkout field name for vat number', 'payplus-payment-gateway'),
				'type'    => 'text',
				'default' => ''
			],
			'foreign_invoices_lang'     => [
				'title'   => __('The language of the invoices or documents issued to foreign customers (assuming your invoicing company supports this language)', 'payplus-payment-gateway'),
				'type'    => 'text',
				'default' => 'HE'
			],
			'display_title'     => [
				'title' => __('Display Options', 'payplus-payment-gateway'),
				'type'  => 'title',
			],
			'display_mode'      => [
				'title'   => __('Display Mode', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'redirect' => __('Redirect', 'payplus-payment-gateway'),
					'iframe'   => __('iFrame', 'payplus-payment-gateway'),
					'samePageIframe'   => __('iFrame on the same page', 'payplus-payment-gateway'),
					'popupIframe'   => __('iFrame in a Popup', 'payplus-payment-gateway'),
				],
				'default' => 'redirect',
			],
			'iframe_height'     => [
				'title'   => __('iFrame Height', 'payplus-payment-gateway'),
				'type'    => 'number',
				'default' => 700,
			],
			'import_applepay_script'     => [
				'title' => __('Apple Pay', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('Include Apple Pay Script in Iframe Mode (You have to join the service first)', 'payplus-payment-gateway'),
			],
			'api_title'         => [
				'title'       => __('Payment Page Options', 'payplus-payment-gateway'),
				'type'        => 'title',
				'description' => __('You can set your payment pages as you like to', 'payplus-payment-gateway'),
			],
			'hide_icon'           => [
				'title'   => __('Hide PayPlus Icon In The Checkout Page', 'payplus-payment-gateway'),
				'type'    => 'checkbox',
				'label'   => __('Hide PayPlus Icon In The Checkout Page', 'payplus-payment-gateway'),
				'default' => 'no'
			],
			'create_pp_token'           => [
				'title'   => __('Saved Credit Cards', 'payplus-payment-gateway'),
				'type'    => 'checkbox',
				'label'   => __('Enable Payment via Saved Cards', 'payplus-payment-gateway'),
				'default' => 'no'
			],
			'send_add_data'           => [
				'title'   => __('Add Data Parameter', 'payplus-payment-gateway'),
				'type'    => 'checkbox',
				'label'   => __('Send Add Data Parameter When Payment Created', 'payplus-payment-gateway'),
				'default' => 'no'
			],
			'hide_identification_id'           => [
				'title'   => __('Hide Identification Field In Payment Form', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('Payment Page Default Setting', 'payplus-payment-gateway'),
					'1'   => __('Yes', 'payplus-payment-gateway'),
					'2'   => __('No', 'payplus-payment-gateway')
				],
				'default' => '0',
			],
			'hide_payments_field'           => [
				'title'   => __('Hide Payments Number In Payment Form', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('Payment Page Default Setting', 'payplus-payment-gateway'),
					'1'   => __('Yes', 'payplus-payment-gateway'),
					'2'   => __('No', 'payplus-payment-gateway')
				],
				'default' => '0',
			],
			'hide_other_charge_methods'           => [
				'title'   => __('Hide other payment types on payment page', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('No', 'payplus-payment-gateway'),
					'1'   => __('Yes', 'payplus-payment-gateway'),
				],
				'default' => '1',
			],
			'order_status_title'   => [
				'title' => __('Order Settings', 'payplus-payment-gateway'),
				'type'  => 'title',
			],
			'successful_order_status'      => [
				'title'   => __('Successful Order Status', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => $listOrderStatus,
				'default' => 'default-woo'
			],
			'fire_completed'      => [
				'title' => __('Payment Completed', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('Fire Payment Completed On Successful Charge', 'payplus-payment-gateway'),
				'default' => 'yes'
			],
			'failure_order_status'      => [
				'title'   => __('Failure Order Status', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => $listOrderStatus,
                'default' => 'default-woo'
			],
			'sendEmailApproval' => [
				'title'   => __('Successful Transaction E-mail Through PayPlus Servers', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('No', 'payplus-payment-gateway'),
					'1'   => __('Yes', 'payplus-payment-gateway')
				],
				'default' => '0',
			],
			'sendEmailFailure' => [
				'title'   => __('Failure Transaction E-mail Through PayPlus Servers', 'payplus-payment-gateway'),
				'type'    => 'select',
				'options' => [
					'0'   => __('No', 'payplus-payment-gateway'),
					'1'   => __('Yes', 'payplus-payment-gateway')
				],
				'default' => '0',
			],
			'logging'      => [
				'title' => __('Logging', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('Log debug messages', 'payplus-payment-gateway'),
				'default' => 'yes',
                'custom_attributes' =>array('disabled'=>'disabled')
			],

			'callback_addr'         => [
				'title'       => __('Test callback url', 'payplus-payment-gateway'),
				'type'        => 'text',
				'default'     => '',
			],
			'recurring_order_set_to_paid'      => [
				'title' => __('Mark as "paid" successfully created subscription orders', 'payplus-payment-gateway'),
				'type'  => 'checkbox',
				'label' => __('', 'payplus-payment-gateway'),
				'default' => 'no'
			],
            'add_product_field_transaction_type'      => [
                'title' => __('Add Product Field  Transaction Type', 'payplus-payment-gateway'),
                'type'  => 'checkbox',
                'label' => __('', 'payplus-payment-gateway'),
                'default' => 'no'
            ],
            'exist_company'      => [
                'title' => __('Display  company name on the invoice', 'payplus-payment-gateway'),
                'type'  => 'checkbox',
                'label' => __('', 'payplus-payment-gateway'),
                'default' => 'no'
            ],
		];
	}

	public function process_refund($order_id, $amount = NULL, $reason = '')
	{
        global  $wpdb;
        $flag=false;
		$order = wc_get_order($order_id);


		$refunded_amount = round((float)$order->get_meta('payplus_total_refunded_amount'), 2);
		if (!$refunded_amount or $refunded_amount <= 0) $refunded_amount = 0;
		$transaction_uid = $order->get_meta('payplus_transaction_uid');
		if ($order->get_meta('payplus_type') != "Charge") {
	    	 $this->logging->add('payplus_process_refund', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Already Charged or Original Transaction Are Not J5');
			$order->add_order_note(sprintf(__('PayPlus Refund is Failed<br />You cannot refund transaction that not charged. Current Transaction Type Status: %s'), $order->get_meta('payplus_type')));
			return false;
		}
		if (round((float)$refunded_amount, 2) >= round((float)$order->get_total(), 2)) {
            $this->logging->add('payplus_process_refund', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'You Cannot charge more then the original transaction amount');
			$order->add_order_note(sprintf(__('PayPlus Refund is Failed<br />You cannot refund more then the refunded total amount. Refunded Amount: %s %s'), $refunded_amount, $order->get_currency()));
			return false;
		}

		// Sending Products
		$refundByItems = false;

		if (!$this->send_products) {
			if ($amount == $order->get_total() and $refunded_amount == 0) {
				$refundByItems = true;
                $this->logging->add('payplus_process_refund', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Sending Items...');

				$totalCartAmount = 0;
				foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data) {
                    $dataArr =$item_data->get_data();
					$item_meta_name = '';
					$couponPrice = 0;
					$quantity = ($item_data['quantity'] ? $item_data['quantity'] : '1');

					// Only for product variation
					$item_meta = @new WC_Order_Item_Meta($item_data);
					if ($meta = $item_meta->display(true, true)) $item_meta_name = $meta;

					if ($item_data['type'] == "coupon") {
						if ($item_data['discount']) $couponPrice = $item_data['discount'] + $item_data['discount_tax'];
						else $couponPrice = $item_data['line_total'] + $item_data['line_total_tax'];
						$productPrice = '-' . round($couponPrice, $this->rounding_decimals);
						$totalCartAmount += ($productPrice);
					} else if ($item_data['type'] == "fee") {
						$productPrice = round(($item_data['line_total'] + $item_data['line_total_tax']), $this->rounding_decimals);
						$totalCartAmount += ($productPrice);
					} else {
						if ($this->single_quantity_per_line == 'yes') {
							$productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']), $this->rounding_decimals);
							$totalCartAmount += ($productPrice);
							$item_data['name'] .= ' ×  '.$quantity;
							$quantity = 1;
						} else {
							$productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']) / $item_data['quantity'], $this->rounding_decimals);
							$totalCartAmount += ($productPrice * $quantity);
						}
					}

					$product = new WC_Product($item_data['product_id']);
                    $productSKU = ($product->get_sku()) ? $product->get_sku():$item_data['product_id'];
                    if(!empty($dataArr['variation_id'])) {
                        $product = new WC_Product_Variable($dataArr['product_id']);
                        $variationsProduct =$product->get_available_variations();
                        if(count($variationsProduct)){
                            $productSKU = ($variationsProduct[0]['sku']) ? $variationsProduct[0]['sku'] :
                                $variationsProduct[0]['variation_id'];
                        }

                    }

					$productsItems[] = '{
							"name" : "' . str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_data['name'])) . '",
							' . ($item_meta_name && $this->send_variations ? '"product_invoice_extra_details" : "' . str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_meta_name)) . '",' : '') . '
							"barcode": "' . $productSKU. '",
							"quantity" : ' . ($quantity ? $quantity : '1') . ',
							"price" : ' . $productPrice . '
							}';
				}

				// order shipping
				if ($order->get_shipping_total()) {
					foreach ($order->get_shipping_methods() as $shipping_method) {
						$shipping_method_data = $shipping_method->get_data();
						$totalLine = round($shipping_method_data['total'], $this->rounding_decimals);
						$productsItems[] = '{	
							"name" : "' . __('Shipping', 'payplus-payment-gateway') . ' - ' . str_replace(["'", '"', "\\"], '', $shipping_method_data['name']) . '",
							"quantity" : 1,
							"price" : ' . $totalLine . ',
							"barcode" :"Shipping"
							}';
						$totalCartAmount += $totalLine;
					}
				}
			}
		}

        $payplusRrelatedTransactions =get_post_meta($order_id,'payplus_related_transactions',true);

        if($payplusRrelatedTransactions){

            if(!empty($_COOKIE['payplus_amount_multipass'])){
                $flag=  $this->payplus_refund_multipass($order_id,$reason);
            }else{
                $transaction_uid =get_post_meta($order_id,'payplus_transaction_uid_credit-card',true);
            }
        }

        if(floatval($amount)) {

            $payload = '{
				"transaction_uid": "' . $transaction_uid . '",
				"amount": "' . $amount . '",
				' . ($refundByItems && !$this->send_products ? '
				"items": [
					' . implode(",", $productsItems) . '
					]' : '
				"more_info" : "' . __('Refund for Order Number: ', 'payplus-payment-gateway') . $order_id . '"
					') . '
				}';

            $response = $this->post_payplus_ws($this->refund_url, $payload);


            if (is_wp_error($response)) {
                $this->logging->add('payplus_process_refund', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($response, true));
            } else {
                $res = json_decode(wp_remote_retrieve_body($response));


                if ($res->results->status == "success" && $res->data->transaction->status_code == "000") {
                    if($this->invocie_api->payplus_get_invoice_enable()){

                        $resultApps = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}postmeta WHERE post_id = ".$order_id .
                            " AND  (meta_key LIKE   '%payplus_credit-card%'  OR meta_key LIKE '%payplus_multipass%' 
         OR meta_key LIKE '%payplus_bit%'  OR  meta_key LIKE '%payplus_max%' OR meta_key LIKE '%payplus_apple-pay%' 
         OR meta_key LIKE '%payplus_google-pay%' OR meta_key LIKE '%payplus_paypal%'
         )", OBJECT);

                        $this->invocie_api->payplus_create_dcoment_dasbord($order_id,
                            $this->invocie_api->payplus_get_invoice_type_document_refund(),$resultApps,$amount);
                    }
                    update_post_meta($order_id, 'payplus_total_refunded_amount', round($refunded_amount + $amount, 2));

                    $order->add_order_note(sprintf(__('PayPlus Refund is Successful<br />Refund Transaction Number: %s<br />Amount: %s %s<br />Reason: %s', 'payplus-payment-gateway'), $res->data->transaction->number, $res->data->transaction->amount, $order->get_currency(), $reason));
                    $this->logging->add('payplus_process_refund', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Completed: ' . print_r($res, true));
                    return true;
                } else {
                    $order->add_order_note(sprintf(__('PayPlus Refund is Failed<br />Status: %s<br />Description: %s', 'payplus-payment-gateway'), $res->results->status, $res->results->description));
                    $this->logging->add('payplus_process_refund', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                    return false;
                }
            }
        }
        return  $flag;

	}

    public  function  payplus_refund_multipass($order_id,$reason){
        $logger = wc_get_logger();
        $amounts= stripslashes($_COOKIE['payplus_amount_multipass']);
        $amounts =json_decode($amounts,ARRAY_A);

        $transaction_uids= explode("|",get_post_meta($order_id, 'payplus_transaction_uid_multipass', true));

        $order = wc_get_order($order_id);
        $refunded_amount = round((float)$order->get_meta('payplus_total_refunded_amount'), 2);
        $flag=true;
        foreach ($amounts as $key =>$value){

            $payload ['transaction_uid'] = $transaction_uids[$key];
            $payload ['amount'] =$value;
            $payload['more_info'] =  __('Refund for Order Number: ', 'payplus-payment-gateway') . $order_id ;
            $this->logging->add('payplus_process_refund_payload', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($payload, true));
            $payload =json_encode($payload);

            $response = $this->post_payplus_ws($this->refund_url, $payload);

            if (is_wp_error($response)) {
                $this->logging->add('payplus_process_refund', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($response, true));
                $flag=false;
            }else {
                $res = json_decode(wp_remote_retrieve_body($response));
                if ($res->results->status == "success" && $res->data->transaction->status_code == "000") {
                    update_post_meta($order_id, 'payplus_total_refunded_amount', round($refunded_amount + $value, 2));

                        $multipassAmount =explode("|",get_post_meta($order_id,"payplus_multipass",true));
                        $multipassAmount[$key] =$multipassAmount[$key] -$value;
                    $multipassAmount =implode("|",$multipassAmount);
                        update_post_meta($order_id, 'payplus_multipass', $multipassAmount);

                        $refund = new WC_Order_Refund();
                        $refund->set_parent_id($order_id);
                        $refund->set_amount($value);
                        $refund->set_reason($reason);
                        $refund->set_total($value);
                        $refund->save();

                    $order->add_order_note(sprintf(__('PayPlus Refund is Successful<br />Refund Transaction Number: %s<br />Amount: %s %s<br />Reason: %s', 'payplus-payment-gateway'), $res->data->transaction->number, $res->data->transaction->amount, $order->get_currency(), $reason));
                    $this->logging->add('payplus_process_refund', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Completed: ' .  print_r($res, true));
                     $flag=true;
                } else {
                    $order->add_order_note(sprintf(__('PayPlus Refund is Failed<br />Status: %s<br />Description: %s', 'payplus-payment-gateway'), $res->results->status, $res->results->description));
                    $this->logging->add('payplus_process_refund', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($res, true));
                    $flag=false;
                }
            }
        }
        unset($_COOKIE['payplus_amount_multipass']);
        setcookie('payplus_amount_multipass', '', time() - 3600, '/');
        return $flag;
    }

	// custom option page html
    public function admin_options()
    {
        $title  = __('PayPlus', 'payplus-payment-gateway');
        $desc   = __('For more information about PayPlus and Plugin versions <a href="https://www.payplus.co.il/wordpress" target="_blank">www.payplus.co.il/wordpress</a>', 'payplus-payment-gateway');
        $credit = __('This plugin was developed by <a href="https://www.payplus.co.il">PayPlus LTD</a>', 'payplus-payment-gateway');
        ob_start();

        $currentSection =$_GET['section'];
        $currentPayment = get_option('woocommerce_'.$currentSection.'_settings');

        $enabled =$currentPayment['enabled'];
        $defaultChargeMethod =(isset($currentPayment['default_charge_method']))?$currentPayment['default_charge_method'] :"";
        if($enabled ==="yes"){
            $this->generate_settings_html();
        }else{
            ?>
            <div id='payplus-lead'>
                <div class="payplus-lead-header">
                    <h1><?php echo __('Want to talk to us?', 'payplus-payment-gateway');  ?></h1>
                    <p><?php echo __('Leave details and our representative will be happy to get back to you as soon as possible','payplus-payment-gateway') ?></p>
                </div>
                <div id="payplus-body-lead">
                    <div class="payplus-box payplus-fullname" >
                        <label for="payplus-fullname"> <?php echo __('Fullname', 'payplus-payment-gateway');?>  </label>
                        <input novalidate class="input-text regular-input"   name='payplus-fullname'  id='payplus-fullname'
                               placeholder='<?php echo __('Fullname', 'payplus-payment-gateway');?>' type='text'>
                        <span  class="payplus-error"><?php echo __("Please enter full name", 'payplus-payment-gateway') ?></span>
                    </div>
                    <div class="payplus-box payplus-phone">
                        <label for="payplus-phone"> <?php echo __('Phone', 'payplus-payment-gateway');?>  </label>
                        <input class="input-text regular-input"   name='payplus-phone'  id='payplus-phone'
                               placeholder='<?php echo __("Phone", 'payplus-payment-gateway');?>' type='text'>
                        <span  class="payplus-error"><?php echo __("Please enter a valid phone number", 'payplus-payment-gateway') ?></span>
                    </div>
                    <div class="payplus-box payplus-email">
                        <label for="payplus-email"> <?php echo __('Email', 'payplus-payment-gateway');?>  </label>
                        <input class="input-text regular-input"    name='payplus-email'  id='payplus-email'
                               placeholder='<?php echo __("Email", 'payplus-payment-gateway');?>' type='email'>
                        <span class="payplus-error"><?php echo __('Please enter a valid email address','payplus-payment-gateway')?></span>
                    </div>
                    <div class="payplus-box payplus-company">
                        <label for="payplus-company"> <?php echo __('Company Name', 'payplus-payment-gateway');?>  </label>
                        <input class="input-text regular-input"    name='payplus-company'  id='payplus-company'
                               placeholder='<?php echo __("Company Name", 'payplus-payment-gateway');?>' type='text'>
                        <span class="payplus-error"><?php echo __('Please enter the company name','payplus-payment-gateway')?></span>

                    </div>
                    <div class="payplus-box">
                        <label for="payplus-website"> <?php echo __('Website', 'payplus-payment-gateway');?>  </label>
                        <input class="input-text regular-input" required='required'   name='payplus-website'  id='payplus-website'
                               placeholder='<?php echo __("Website", 'payplus-payment-gateway');?>' type='text' readonly
                               value="<?php echo  site_url()?>"
                        >
                    </div>
                    <div class="payplus-box payplus-message">
                        <label for="payplus-message"> <?php echo __('Message', 'payplus-payment-gateway');?>  </label>
                        <input class="input-text regular-input"    name='payplus-message'  id='payplus-message'
                               placeholder='<?php echo __("Message", 'payplus-payment-gateway');?>' type='text' value="<?php echo __("Add payment ",'payplus-payment-gateway') ." ".$defaultChargeMethod?> ">
                        <span class="payplus-error"><?php echo __('Please enter the message content','payplus-payment-gateway')?></span>
                    </div>
                    <div class="payplus-box">
                        <button type='button'>  <?php echo __('We will get back to you soon', 'payplus-payment-gateway');?></button>
                    </div>
                </div>

            </div>

            <?php
        }
        $settings = ob_get_clean();


        $arrOtherPayment =array(
            "bit" =>
                array(
                    "icon" =>PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."bit.svg",

                    "link"=>"?page=wc-settings&tab=checkout&section=payplus-payment-gateway-bit",
                    "section" =>"payplus-payment-gateway-bit"),
            "Google Pay" =>
                array(
                    "icon" =>PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."google-pay.svg",
                    "link"=>"?page=wc-settings&tab=checkout&section=payplus-payment-gateway-googlepay",
                           "section" =>"payplus-payment-gateway-googlepay"),
            "Apple Pay" =>
                array(
                    "icon" =>PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."apple-pay.svg",
                    "link"=>"?page=wc-settings&tab=checkout&section=payplus-payment-gateway-applepay",
                    "section" =>"payplus-payment-gateway-applepay"),
            "MULTIPASS" =>
                array(
                    "icon" =>PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."multipass.svg",
                    "link"=>"?page=wc-settings&tab=checkout&section=payplus-payment-gateway-multipass",
                     "section" =>"payplus-payment-gateway-multipass"),
             "PayPal" =>
                array(
                    "icon" =>PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."paypal.svg",
                    "link"=>"?page=wc-settings&tab=checkout&section=payplus-payment-gateway-paypal",
                     "section" =>"payplus-payment-gateway-paypal"),

        );


        echo "<div id='payplus-options'>";


            $seleted =($currentSection=='payplus-payment-gateway')?"nav-tab-active":"";

            echo "<nav  class='nav-tab-wrapper tab-option-payplus'>
                     <a href='?page=wc-settings&tab=checkout&section=payplus-payment-gateway' data-tab='payplus-blank' class='nav-tab ".$seleted."' >
                     <img src='".PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."/payplus.svg'>
                     "  . __('PayPlus  Gateway', 'payplus-payment-gateway')."</a>";

                echo   "<a href='#' data-tab='tab-invoice-payplus'   class='nav-tab tab-invoice-payplus' >
                    <img src='".PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."invocie+.svg'>
                  ". __('Invoice+ (PayPlus)', 'payplus-payment-gateway')."</a>";
                    echo    "<a href='#' data-tab='tab-payplus-error-page'   class='nav-tab' >
 ". __('PayPlus Page Error - Settings', 'payplus-payment-gateway')."</a>
            </nav>";
            echo "<nav  id='sub-option-paylus' class='nav-tab-wrapper tab-option-payplus'>";
            foreach ($arrOtherPayment as $key =>$value){


                $seleted =($currentSection==$value['section'])?"nav-tab-active":"";

                if($currentSection==$value['section']){
                    $title = __( $key, 'payplus-payment-gateway');
                }
                    echo  "<a data-tab='payplus-blank' href='".$value['link']."'  class='nav-tab ".$seleted."'> 
                        <img  src ='".$value['icon']."' alt='".__($key, 'payplus-payment-gateway')."'>"
                        . __($key, 'payplus-payment-gateway')."</a>";


            }
            echo   "</nav>";

        echo "<h3 id='payplus-title-section'>$title</h3>
			<p>$desc</p>";

            echo "<div class='tab-section-payplus'  id='tab-payplus-error-page' >
		     <div class='wrap'>
            ".$this->payplus_from_error_page_setting()."
                </div>            
            </div>";
            echo "<div class='tab-section-payplus'  id='tab-invoice-payplus' >
		     <div class='wrap'>
		     
            ".$this->invocie_api->payplus_invoice_set_fields_option_page()."
                </div>            
            </div>";


        echo "<div class='tab-section-payplus' id='tab-payplus-gateway' >
		    	<table class='form-table'>$settings</table>           
            </div>
			<div class='payplus-credit' style='position: absolute; bottom: 33px;'>$credit</div>
		</div>
		
		";
    }

	// remove credit card form from checkout
	public function payment_fields()
	{
		if ($this->supports('tokenization') && is_checkout()) {
			$this->tokenization_script();
			if ($this->create_pp_token) {
				$this->saved_payment_methods();
			}
			$this->save_payment_method_checkbox();
		}
	}

    // method description and add cc to account text
	public function save_payment_method_checkbox()
	{
		$html = '<div class="payplus-option-description-area">';
		if ($this->description) {
			$html .= '<p class="form-row payment-method-description">' . $this->description . '</p>';
		}
		if ($this->create_pp_token && $this->id) {
			$html .= sprintf(
				'<p class="form-row woocommerce-SavedPaymentMethods-saveNew">
					<input id="wc-%1$s-new-payment-method" name="wc-%1$s-new-payment-method" type="checkbox" value="true" style="width:auto;" />
					<label for="wc-%1$s-new-payment-method" style="display:inline;">%2$s</label>
				</p>',
				esc_attr($this->id),
				esc_html__('Save credit card in my account', 'payplus-payment-gateway')
			);
		}
		$html .= '</div>';

		$html .= "<iframe allowpaymentrequest  id='pp_form' name='payplus-iframe' style='display:none; width: 100%; height: " . $this->iframe_height . "px; border: 0;'></iframe>";

		echo apply_filters('woocommerce_payment_gateway_save_new_payment_method_option_html', $html, $this);
	}

	// redirect to receipt page (payment page)
	public function process_payment($order_id)
	{

		$order    = wc_get_order($order_id);
		$is_token = (isset($_POST['wc-' . $this->id . '-payment-token']) && $_POST['wc-' . $this->id . '-payment-token'] !== 'new') ? true : false;
		$order->delete_meta_data("save_payment_method");
		$order->add_meta_data("save_payment_method", isset($_POST['wc-' . $this->id . '-new-payment-method']) ? '1' : '0');
		$order->save_meta_data();
		$redirect_to = add_query_arg('order-pay',$order_id, add_query_arg('key', $order->order_key, get_permalink(wc_get_page_id('pay'))));


		if ($is_token) {
			$token_id = wc_clean($_POST['wc-' . $this->id . '-payment-token']);
			$token    = WC_Payment_Tokens::get($token_id);
			if (!$this->checkValidateCard($token)) {
                $this->logging->add('payplus_payment_using_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Token Expired: ' . $token);
				wc_add_notice(__('Error: user or other, please contact PayPlus support', $this->id), 'error');
				return;
			}
            $response = $this->receipt_page($order_id, $token);
            $this->logging->add('payplus_payment_using_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'RestAPI Response: ' . print_r($response, true));

			if ($response->data->status == "approved" && $response->data->status_code == "000" && $response->data->transaction_uid) {
				$this->updateMetaData($order_id, $response);
				if ($response->data->type == "Charge") {
					if ($this->fire_completed) $order->payment_complete();
                    if($this->successful_order_status !=='default-woo' ){
                        $order->update_status($this->successful_order_status);
                    }

				} else {
					$order->update_status('wc-on-hold');
				}
				$order->add_order_note(sprintf(__('PayPlus Token Payment Successful<br/>Transaction Number: %s', 'payplus-payment-gateway'), $response->data->number));

                $this->logging('payplus_payment_using_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Completed');
                $this->logging('payplus_payment_using_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Response: ' . print_r($response, true));

			} else {
                $this->logging->add('payplus_payment_using_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($response, true));
				$order->add_order_note(sprintf(__('PayPlus Token Payment Failed<br/>Transaction Number: %s', 'payplus-payment-gateway'), $response->data->number));
                if($this->failure_order_status !=='default-woo' ){
                    $order->update_status($this->failure_order_status);
                }

				wc_add_notice(sprintf(__('Error: credit card declined: %s', 'payplus-payment-gateway'), print_r($response, true)), 'error');
				return;
			}
		}

		$result = [
			'result'   => 'success',
			'redirect' => $redirect_to,
			'viewMode' => $this->display_mode
		];
		if (in_array($this->display_mode, ['samePageIframe', 'popupIframe'])) {

			$result['payplus_iframe'] = $this->receipt_page($order_id, null, false, '', 0, true);
            ;
		}
		return $result;
	}

	public function checkValidateCard($token = NULL)
	{
		if (!$token->get_token()) return false;
		if ($token->get_expiry_year() > date("Y")) return true;
		if ($token->get_expiry_year() < date("Y")) return false;
		if ($token->get_expiry_month() >= date("m")) return true;
	}

    public  function payplus_generate_products_link($products,$order_id){
        $mainPluginOptions = get_option('woocommerce_payplus-payment-gateway_settings');
        $displayNode = ($mainPluginOptions['display_mode'] ?: 'redirect');
        $generate_products_link ="payplus#".$order_id."|";
        foreach ($products as $key =>$product){
            $product= json_decode($product);
            $barcode="";
            if(!empty($product->barcode)){
                $barcode =$product->barcode;
            }
            $generate_products_link.=$barcode."-" .$product->quantity."-".$product->price."|";
        }
        $generate_products_link.="-" .$this->default_charge_method."-".$displayNode;
        return  $generate_products_link;
    }

    public  function  payplus_generate_payment_link($order_id,$is_admin=false ,$token=null,$subscription=false,$inline=false){
        global $wp_version;
        $date  = new DateTime();
        $dateNow =$date->format('Y-m-d H:i');
        $order = wc_get_order($order_id);


        $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'New Payment Process Fired');

            if ($token)  $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Token has been used');
            if ($subscription && !$token)  $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'--- Token is empty or invalid - exit ---');

        if ($subscription && !$token) return false;
        // order items
        $totalCartAmount = 0;
        $totallCart =floatval($order->get_total()) ;



        if (!$this->send_products) {
            foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data) {
                $dataArr =$item_data->get_data();
                $item_name = $item_data['name'];
                $item_meta_name = '';
                $couponPrice = 0;
                $quantity = ($item_data['quantity'] ? $item_data['quantity'] : '1');
                // Only for product variation
                $item_meta = @new WC_Order_Item_Meta($item_data);
                if ($meta = $item_meta->display(true, true)) $item_meta_name = $meta;

                if ($item_data['type'] == "coupon") {
                    if ($item_data['discount']) $couponPrice = $item_data['discount'] + $item_data['discount_tax'];
                    else $couponPrice = $item_data['line_total'] + $item_data['line_total_tax'];
                    $productPrice = '-' . round($couponPrice, $this->rounding_decimals);
                    $totalCartAmount += ($productPrice);
                } else if ($item_data['type'] == "fee") {
                    $productPrice = round(($item_data['line_total'] + $item_data['line_total_tax']), $this->rounding_decimals);
                    $totalCartAmount += $productPrice;
                } else {
                    if ($this->single_quantity_per_line == 'yes') {
                        $productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']), $this->rounding_decimals);
                        $totalCartAmount += ($productPrice);
                        $item_name .= ' ×  '.$quantity;
                        $quantity = 1;
                    } else {
                        $productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']) / $item_data['quantity'], $this->rounding_decimals);
                        $totalCartAmount += ($productPrice * $quantity);
                    }
                }

                $product = new WC_Product($item_data['product_id']);
                $productSKU = ($product->get_sku()) ? $product->get_sku():$item_data['product_id'];
                if(!empty($dataArr['variation_id'])) {
                    $product = new WC_Product_Variable($dataArr['product_id']);
                    $variationsProduct =$product->get_available_variations();
                    if(count($variationsProduct)){
                        $productSKU = ($variationsProduct[0]['sku']) ? $variationsProduct[0]['sku'] :
                            $variationsProduct[0]['variation_id'];
                    }

                }

                $productImageData = wp_get_attachment_image_src( $product->get_image_id(), 'full' );
                $itemDetails = [
                    'name' => str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_name)),
                    'barcode' => (string)($productSKU ? $productSKU : $item_data['product_id']),
                    'quantity' => ($quantity ? $quantity : '1'),
                    'price' => $productPrice
                ];

                if ($productImageData && isset($productImageData[0])) {
                    $itemDetails['image_url'] = $productImageData[0];
                }
                if ($item_meta_name && $this->send_variations) {
                    $itemDetails['product_invoice_extra_details'] = str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_meta_name));
                }

                if ($item_data->get_tax_status() == 'none') {
                    $itemDetails['vat_type'] = 2;
                } else {
                    $itemDetails['vat_type'] = 0;
                }

                $productsItems[] = json_encode($itemDetails);
            }


            // order shipping
            if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())) {
                foreach ($order->get_shipping_methods() as $shipping_method) {
                    $shipping_method_data = $shipping_method->get_data();
                    $totalLine = round((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() + $order->get_shipping_tax() : $order->get_shipping_total() + $order->get_shipping_tax()), $this->rounding_decimals);
                    $productsItems[] = '{	
					"name" : "' . __('Shipping', 'payplus-payment-gateway') . ' - ' . str_replace(["'", '"', "\\"], '', $shipping_method_data['name']) . '",
					"quantity" : 1,
					"price" : ' . $totalLine . ',
					"barcode" :"order-shipping"
					}';
                    $totalCartAmount += $totalLine;
                }
            }
        }
        // discount payment
        if(floatval($totalCartAmount)!=$totallCart){
            $discount =-1 *round( ($totalCartAmount -$totallCart),2);
            $totalCartAmount =$totallCart;
            $productsItems[] = '{	
            	    "barcode" :"discount",
					"name" : "discount",
					"quantity" : 1,
					"price" : ' . $discount . '
					}';
        }



        $langCode = explode("_", get_locale());
        $setInvoice = '';
        $payingVat = '';
        $invoiceLanguage = '';
        $addChargeLine = '';
        $cell_phone = str_replace(["'", '"', "\\"], '', $order->get_billing_phone());
        $address = trim(str_replace(["'", '"', "\\"], '', $order->get_billing_address_1() . ' ' . $order->get_billing_address_2()));

        $city = str_replace(["'", '"', "\\"], '', $order->get_billing_city());
        $postal_code = str_replace(["'", '"', "\\"], '', $order->get_billing_postcode());
        $customer_country_iso = $order->get_billing_country();
        if ($subscription) {
            $addChargeLine = '"charge_method": 1,';
        } else if ($this->settings['transaction_type'] != "0") {
            $addChargeLine = '"charge_method": ' . $this->settings['transaction_type'] . ',';
        }
        if(!$subscription && $this->add_product_field_transaction_type){
            if($this->payplus_check_all_product($order, "2")){
                $addChargeLine = '"charge_method": 2,';
            } elseif($this->payplus_check_all_product($order, "1")){
                $addChargeLine = '"charge_method": 1,';
            }
        }

        if($this->invocie_api->payplus_get_invoice_enable()){
            $flagInvoice ='false';
            $setInvoice  = '"initial_invoice": '.$flagInvoice.',';
        } elseif($this->initial_invoice == "1"){
            $flagInvoice ='true';
            $setInvoice  = '"initial_invoice": '.$flagInvoice.',';
        }elseif ($this->initial_invoice == "2"){
            $flagInvoice ='false';
            $setInvoice  = '"initial_invoice": '.$flagInvoice.',';
        }else{
            $flagInvoice ='';
            // $setInvoice  = '"initial_invoice": '.$flagInvoice.',';
        }


        // Paying Vat & Invoices
        if ($this->paying_vat == "0") $payingVat = '"paying_vat": true,';
        else if ($this->paying_vat == "1") $payingVat = '"paying_vat": false,';
        else if ($this->paying_vat == "2") {
            if (trim(strtolower($customer_country_iso)) != trim(strtolower($this->paying_vat_iso_code))) {
                $payingVat = '"paying_vat": false,';
                $invoiceLanguage = '"invoice_language": "' . strtolower($this->foreign_invoices_lang) . '",';
            } else $payingVat = '"paying_vat": true,';
        }
        $this->default_charge_method = ($this->default_charge_method) ?: 'credit-card';
        $bSaveToken = (bool)($order->get_meta("save_payment_method") === '1');



        $hideOtherChargeMethods = (isset($this->hide_other_charge_methods) && $this->hide_other_charge_methods === '1') ? 'true' : 'false';

        if($this->default_charge_method==MULTIPASS ){
            $hideOtherChargeMethods='false';
        }

        $callback = get_site_url(null,'/?wc-api=callback_response');
        if ($this->api_test_mode === true && $this->callback_addr) {
            $callback = $this->callback_addr;
        }

        $customer = [
            'email'=>$order->get_billing_email()
        ];

        if( $this->exist_company && !empty($order->get_billing_company())){
            $customerName = $order->get_billing_company();
        }else{
            $customerName = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            if (!$customerName) {
                $customerName = $order->get_billing_company();
            } elseif($order->get_billing_company()) {
                $customerName .= " (".$order->get_billing_company().")";
            }
        }
        $customer['customer_name'] = $customerName;

        if ($cell_phone) {
            $customer['phone'] = $cell_phone;
        }
        if ($address) {
            $customer['address'] = $address;
        }
        if ($city) {
            $customer['city'] = $city;
        }
        if ($postal_code) {
            $customer['postal_code'] = $postal_code;
        }

        if ($customer_country_iso) {
            $customer['country_iso'] = $customer_country_iso;
        }
        if ($this->vat_number_field && $order->get_meta($this->vat_number_field)) {
            $customer['vat_number'] =  $order->get_meta($this->vat_number_field);
        }
        if(intval($order->get_customer_id())){
            $customer['customer_external_number']=$order->get_customer_id();
        }
        $payplus_payment_page_link =get_post_meta($order_id,'payplus_payment_page_link',true);
        $check_payplus_generate_products_link = $this->payplus_generate_products_link($productsItems ,$order_id);


        if($payplus_payment_page_link ) {
            $payplus_generate_products_link = get_post_meta($order_id, 'payplus_generate_products_link', true);
            $dateLink = new DateTime(get_post_meta($order_id, 'payplus_time_link', true));
            $interval = $dateLink->diff($date);

            if ($interval->i < 30 && $interval->h == 0) {
                if ($payplus_generate_products_link === $check_payplus_generate_products_link) {
                    return array("status"=>true,"payment_response"=>$payplus_payment_page_link);
                }
            }
        }
        $redriectSuccess =($is_admin) ?$this->response_url."&paymentPayPlusDashboard=".  $this->payplus_generate_key_dashboard:  $this->response_url;
        $payload = '{
    "payment_page_uid": "' . $this->settings['payment_page_id'] . '",
	' . $addChargeLine . '
    "expiry_datetime": "30",
    "hide_other_charge_methods": ' . $hideOtherChargeMethods . ',
    "language_code": "' . trim(strtolower($langCode[0])) . '",
    "refURL_success": "' .$redriectSuccess . '",
    "refURL_failure": "' . $this->response_error_url . '",
    "refURL_callback": "'. $callback .'",
	"charge_default":"' . $this->default_charge_method . '",
	' . $payingVat . '
    "customer": '.json_encode($customer) . (!$this->send_products ? ',
    "items": [
        ' . implode(",", $productsItems) . '
    ]' : '') . ',
	' . ($token ? '"token" : "' . (is_object($token) ? $token->get_token() : $token) . '",' : '') . '
    "amount": ' . ($this->send_products ? $totallCart: round($totalCartAmount, $this->rounding_decimals)) . ',
    "currency_code": "' . $order->get_currency() . '",
    "sendEmailApproval": ' . ($this->sendEmailApproval == 1 ? 'true' : 'false') . ',
    "sendEmailFailure": ' . ($this->sendEmailFailure == 1 ? 'true' : 'false') . ',
    "create_token": ' . ($bSaveToken ? 'true' : 'false') . ',
    ' . $setInvoice . '
	' . $invoiceLanguage . '
    ' . ($this->send_add_data ? '"add_data": "' . $order_id . '",' : '') . '
    ' . ($this->hide_payments_field > 0 ? '"hide_payments_field": ' . ($this->hide_payments_field == 1 ? 'true' : 'false') . ',' : '') . '
    ' . ($this->hide_identification_id > 0 ? '"hide_identification_id": ' . ($this->hide_identification_id == 1 ? 'true' : 'false') . ',' : '') . '
	"more_info": "' . $order_id . '"
}';



        $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Payload data before Sending to PayPlus');
        $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Request: ' . print_r($payload, true));


        $response = $this->post_payplus_ws($this->payment_url, $payload);


        if(is_wp_error($response)){
            $this->logging->add('payplus_process_payment_receipt_error' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WS PayPlus Response');
            $this->logging->add('payplus_process_payment_receipt_error' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Response: ' . print_r($response, true));
        }else {

            $res = json_decode(wp_remote_retrieve_body($response));
            $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WS PayPlus Response');
            $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Response: ' . print_r($res, true));

            if (isset($res->data->payment_page_link) && $this->validateUrl($res->data->payment_page_link)) {
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WS Redirecting to Page: ' . $res->data->payment_page_link);
                update_post_meta($order_id,'payplus_payment_page_link',$res->data->payment_page_link);
                update_post_meta($order_id,'payplus_generate_products_link',$check_payplus_generate_products_link);
                update_post_meta($order_id,'payplus_time_link',$dateNow);
                return array("status"=>true,"payment_response"=>$res->data->payment_page_link);

            } else {
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Message: ' . print_r($response, true));
                }
                $response=(is_array($response))? $response['body'] : $response->body;
                return array("status"=>false,"payment_response"=>$response);
            }

    }

    public  function  getRecurring($external_recurring_id,$order_id){

        $billing_interval =get_post_meta($external_recurring_id,'_billing_interval',true);
        $billing_period =get_post_meta($external_recurring_id,'_billing_period',true);
        $external_recurring_payment['external_recurring_id'] = $external_recurring_id;
        $external_recurring_payment['external_recurring_charge_id'] = $order_id;

        if($billing_period ==="day"){
            $external_recurring_payment['external_recurring_type'] =0;
            $external_recurring_payment['external_recurring_range'] =$billing_interval;
        }elseif($billing_period ==="week"){
            $external_recurring_payment['external_recurring_type'] =1;
            $external_recurring_payment['external_recurring_range'] =$billing_interval;
        }elseif($billing_period==="month"){
            $external_recurring_payment['external_recurring_type'] =2;
            $external_recurring_payment['external_recurring_range'] =$billing_interval;
        }elseif ($billing_period==="year"){
          $external_recurring_payment['external_recurring_type'] =2;
           $external_recurring_payment['external_recurring_range'] =$billing_interval *12;
        }

        return json_encode($external_recurring_payment);
    }

    public function  payplus_check_all_product($order ,$checkChargemMethod){

        foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data){
            $transactionTypeValue =get_post_meta($item_data['product_id'],'payplus_transaction_type',true);
            if($transactionTypeValue ==$checkChargemMethod){
                return true;
            }
        }
        return false;
    }

	// receipt page - iframe or redirect
	public function receipt_page($order_id, $token = null, $subscription = false, $custom_more_info = '', $subscription_amount = 0, $inline = false)
	{

		global $wp_version;
        $date  = new DateTime();
        $dateNow =$date->format('Y-m-d H:i');
		$order = wc_get_order($order_id);


        $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'New Payment Process Fired');
			if ($token)  $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Token has been used');
			if ($subscription && !$token)  $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'--- Token is empty or invalid - exit ---');

		if ($subscription && !$token) return false;
		// order items
		$totalCartAmount = 0;
        $totallCart =floatval($order->get_total()) ;


		if (!$this->send_products) {
			foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data) {
                $dataArr =$item_data->get_data();

				$item_name = $item_data['name'];
				$item_meta_name = '';
				$couponPrice = 0;
				$quantity = ($item_data['quantity'] ? $item_data['quantity'] : '1');
				// Only for product variation
				$item_meta = @new WC_Order_Item_Meta($item_data);

				if ($meta = $item_meta->display(true, true)) $item_meta_name = $meta;

				if ($item_data['type'] == "coupon") {
					if ($item_data['discount']) $couponPrice = $item_data['discount'] + $item_data['discount_tax'];
					else $couponPrice = $item_data['line_total'] + $item_data['line_total_tax'];
					$productPrice = '-' . round($couponPrice, $this->rounding_decimals);
					$totalCartAmount += ($productPrice);
				} else if ($item_data['type'] == "fee") {
					$productPrice = round(($item_data['line_total'] + $item_data['line_total_tax']), $this->rounding_decimals);
					$totalCartAmount += $productPrice;
				} else {
					if ($this->single_quantity_per_line == 'yes') {
						$productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']), $this->rounding_decimals);
						$totalCartAmount += ($productPrice);
						$item_name .= ' ×  '.$quantity;
						$quantity = 1;
					} else {
						$productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']) / $item_data['quantity'], $this->rounding_decimals);
						$totalCartAmount += ($productPrice * $quantity);
					}
				}
                $product = new WC_Product($dataArr['product_id']);
                $productSKU = ($product->get_sku()) ? $product->get_sku():$item_data['product_id'];
                if(!empty($dataArr['variation_id'])) {
                   $product = new WC_Product_Variable($dataArr['product_id']);
                   $variationsProduct =$product->get_available_variations();
                   if(count($variationsProduct)){
                       $productSKU = ($variationsProduct[0]['sku']) ? $variationsProduct[0]['sku'] :
                           $variationsProduct[0]['variation_id'];
                   }


                }

				$productImageData = wp_get_attachment_image_src( $product->get_image_id(), 'full' );
				$itemDetails = [
					'name' => str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_name)),
					'barcode' => (string)$productSKU,
					'quantity' => ($quantity ? $quantity : '1'),
					'price' => $productPrice
				];

				if ($productImageData && isset($productImageData[0])) {
					$itemDetails['image_url'] = $productImageData[0];
				}
				if ($item_meta_name && $this->send_variations) {
					$itemDetails['product_invoice_extra_details'] = str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_meta_name));
				}

				if ($item_data->get_tax_status() == 'none') {
					$itemDetails['vat_type'] = 2;
				} else {
                    $itemDetails['vat_type'] = 0;
                }

				$productsItems[] = json_encode($itemDetails);
			}


			// order shipping
			if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())) {
				foreach ($order->get_shipping_methods() as $shipping_method) {
					$shipping_method_data = $shipping_method->get_data();
					$totalLine = round((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() + $order->get_shipping_tax() : $order->get_shipping_total() + $order->get_shipping_tax()), $this->rounding_decimals);
					$productsItems[] = '{	
					"name" : "' . __('Shipping', 'payplus-payment-gateway') . ' - ' . str_replace(["'", '"', "\\"], '', $shipping_method_data['name']) . '",
					"quantity" : 1,
					"price" : ' . $totalLine . ',
					"barcode" :"order-shipping"
					}';
					$totalCartAmount += $totalLine;
				}
			}
		}
        // discount payment
        if(floatval($totalCartAmount)!=$totallCart){
            $discount =-1 *round( ($totalCartAmount -$totallCart),2);
            $totalCartAmount =$totallCart;
            $productsItems[] = '{	
            	    "barcode" :"discount",
					"name" : "discount",
					"quantity" : 1,
					"price" : ' . $discount . '
					}';
        }

		$langCode = explode("_", get_locale());
		$setInvoice = '';
		$payingVat = '';
		$invoiceLanguage = '';
		$addChargeLine = '';
		$cell_phone = str_replace(["'", '"', "\\"], '', $order->get_billing_phone());
		$address = trim(str_replace(["'", '"', "\\"], '', $order->get_billing_address_1() . ' ' . $order->get_billing_address_2()));

		$city = str_replace(["'", '"', "\\"], '', $order->get_billing_city());
		$postal_code = str_replace(["'", '"', "\\"], '', $order->get_billing_postcode());
		$customer_country_iso = $order->get_billing_country();
		if ($subscription) {
			$addChargeLine = '"charge_method": 1,';
		} else if ($this->settings['transaction_type'] != "0") {
			$addChargeLine = '"charge_method": ' . $this->settings['transaction_type'] . ',';
		}
        if(!$subscription && $this->add_product_field_transaction_type){
            if($this->payplus_check_all_product($order, "2")){
                $addChargeLine = '"charge_method": 2,';
            } elseif($this->payplus_check_all_product($order, "1")){
                $addChargeLine = '"charge_method": 1,';
            }
        }
        if($this->invocie_api->payplus_get_invoice_enable()){
            $flagInvoice ='false';
            $setInvoice  = '"initial_invoice": '.$flagInvoice.',';
        } elseif($this->initial_invoice == "1"){
            $flagInvoice ='true';
            $setInvoice  = '"initial_invoice": '.$flagInvoice.',';
        }elseif ($this->initial_invoice == "2") {
            $flagInvoice = 'false';
            $setInvoice = '"initial_invoice": ' . $flagInvoice . ',';
        }

		// Paying Vat & Invoices
		if ($this->paying_vat == "0") $payingVat = '"paying_vat": true,';
		else if ($this->paying_vat == "1") $payingVat = '"paying_vat": false,';
		else if ($this->paying_vat == "2") {
			if (trim(strtolower($customer_country_iso)) != trim(strtolower($this->paying_vat_iso_code))) {
				$payingVat = '"paying_vat": false,';
				$invoiceLanguage = '"invoice_language": "' . strtolower($this->foreign_invoices_lang) . '",';
			} else $payingVat = '"paying_vat": true,';
		}
		$this->default_charge_method = ($this->default_charge_method) ?: 'credit-card';
		$bSaveToken = (bool)($order->get_meta("save_payment_method") === '1');



	$hideOtherChargeMethods = (isset($this->hide_other_charge_methods) && $this->hide_other_charge_methods === '1') ? 'true' : 'false';

     if($this->default_charge_method==MULTIPASS ){
         $hideOtherChargeMethods='false';
     }

		$callback = get_site_url(null,'/?wc-api=callback_response');
		if ($this->api_test_mode === true && $this->callback_addr) {
			$callback = $this->callback_addr;
		}

		$customer = [
			'email'=>$order->get_billing_email()
		];
        if( $this->exist_company && !empty($order->get_billing_company())){
                $customerName = $order->get_billing_company();
         }else {
            $customerName = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            if (!$customerName) {
                $customerName = $order->get_billing_company();
            } elseif ($order->get_billing_company()) {
                $customerName .= " (" . $order->get_billing_company() . ")";
            }
        }
		$customer['customer_name'] = $customerName;

		if ($cell_phone) {
			$customer['phone'] = $cell_phone;
		}
		if ($address) {
			$customer['address'] = $address;
		}
		if ($city) {
			$customer['city'] = $city;
		}
		if ($postal_code) {
			$customer['postal_code'] = $postal_code;
		}

		if ($customer_country_iso) {
			$customer['country_iso'] = $customer_country_iso;
		}
		if ($this->vat_number_field && $order->get_meta($this->vat_number_field)) {
			$customer['vat_number'] =  $order->get_meta($this->vat_number_field);
		}
        if(intval($order->get_customer_id())){
            $customer['customer_external_number']=$order->get_customer_id();
        }
        $payplus_payment_page_link =get_post_meta($order_id,'payplus_payment_page_link',true);
        $check_payplus_generate_products_link = $this->payplus_generate_products_link($productsItems ,$order_id);


        if($payplus_payment_page_link ) {
            $payplus_generate_products_link = get_post_meta($order_id, 'payplus_generate_products_link', true);
            $dateLink = new DateTime(get_post_meta($order_id, 'payplus_time_link', true));
            $interval = $dateLink->diff($date);

            if ($interval->i < 30 && $interval->h == 0) {

                if ($payplus_generate_products_link === $check_payplus_generate_products_link) {
                    $this->get_payment_page($payplus_payment_page_link);
                    return;
                }

            }
        }

        $post =$this->payplus_get_posts_id("",array("post_parent"=>$order_id));
        $external_recurring_payment ="";
        if($post && $post[0]->post_type==="shop_subscription"){
            $external_recurring_id =$post[0]->ID;
            $external_recurring_payment ='"external_recurring_payment":'.$this->getRecurring($external_recurring_id,$order_id).",";
        }elseif ($subscription){
            $external_recurring_id = get_post_meta($order_id, '_subscription_renewal', true);
            $external_recurring_payment ='"external_recurring_payment":'.$this->getRecurring($external_recurring_id,$order_id).",";
        }


            $payload = '{
    "payment_page_uid": "' . $this->settings['payment_page_id'] . '",
	' . $addChargeLine . '
    "expiry_datetime": "30",
    "hide_other_charge_methods": ' . $hideOtherChargeMethods . ',
    "language_code": "' . trim(strtolower($langCode[0])) . '",
    "refURL_success": "' . $this->response_url . '",
    "refURL_failure": "' . $this->response_error_url . '",
    "refURL_callback": "'. $callback .'",
	"charge_default":"' . $this->default_charge_method . '",
	' . $payingVat . '
    "customer": '.json_encode($customer) . (!$this->send_products ? ',
    "items": [
        ' . implode(",", $productsItems) . '
    ]' : '') . ',
	' . ($token ? '"token" : "' . (is_object($token) ? $token->get_token() : $token) . '",' : '') . '
    "amount": ' . ($this->send_products ? $totallCart: round($totalCartAmount, $this->rounding_decimals)) . ',
    "currency_code": "' . $order->get_currency() . '",
    "sendEmailApproval": ' . ($this->sendEmailApproval == 1 ? 'true' : 'false') . ',
    "sendEmailFailure": ' . ($this->sendEmailFailure == 1 ? 'true' : 'false') . ',
    "create_token": ' . ($bSaveToken ? 'true' : 'false') . ',
    ' . $setInvoice . '
	' . $invoiceLanguage
	 .$external_recurring_payment
    . ($this->send_add_data ? '"add_data": "' . $order_id . '",' : '') . '
    ' . ($this->hide_payments_field > 0 ? '"hide_payments_field": ' . ($this->hide_payments_field == 1 ? 'true' : 'false') . ',' : '') . '
    ' . ($this->hide_identification_id > 0 ? '"hide_identification_id": ' . ($this->hide_identification_id == 1 ? 'true' : 'false') . ',' : '') . '
	"more_info": "' . ($custom_more_info ? $custom_more_info : $order_id) . '"
}';



			$this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Payload data before Sending to PayPlus');
        $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Request: ' . print_r($payload, true));


		$response = $this->post_payplus_ws($this->payment_url, $payload);
        if(is_wp_error($response)){
            $this->logging->add('payplus_process_payment_receipt_error' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WS PayPlus Response');
            $this->logging->add('payplus_process_payment_receipt_error' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Response: ' . print_r($response, true));
        }else {


            $res = json_decode(wp_remote_retrieve_body($response));
            if ($this->logging) {
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WS PayPlus Response');
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Response: ' . print_r($res, true));
            }


            if ($token || $inline){

                return $res;
            }

            if (isset($res->data->payment_page_link) && $this->validateUrl($res->data->payment_page_link)) {
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WS Redirecting to Page: ' . $res->data->payment_page_link);
                update_post_meta($order_id,'payplus_payment_page_link',$res->data->payment_page_link);
                update_post_meta($order_id,'payplus_generate_products_link',$check_payplus_generate_products_link);
                update_post_meta($order_id,'payplus_time_link',$dateNow);
                $this->get_payment_page($res->data->payment_page_link);

            } else {

                    $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                $this->logging->add('payplus_process_payment' . ($subscription ? '_subscription' : ''), 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Message: ' . print_r($response, true));

                echo __('Something went wrong with the payment page') . '<hr /><b>Error:</b> ' . print_r((is_array($response) ? $response['body'] : $response->body), true);
            }
        }
	}

	// get payment page - iframe or redirect
	public function get_payment_page($res)
	{

		if (!$this->display_mode || $this->display_mode == 'default') {
			$mainPluginOptions = get_option('woocommerce_payplus-payment-gateway_settings');
			$this->display_mode = ($mainPluginOptions['display_mode'] ?: 'redirect');
			$this->iframe_height = ($this->iframe_height ?: 700);
		}

		if ($this->display_mode == 'iframe') {

			echo "<form name='pp_form' target='payplus-iframe' method='GET' action='" . $res . "'></form>";
			echo "<iframe  allowpaymentrequest id='pp_form' name='payplus-iframe' style='width: 100%; height: " . $this->iframe_height . "px; border: 0;'></iframe>";
			if ($this->import_applepay_script) echo '<script src="https://payments' . ($this->api_test_mode ? 'dev' : '') . '.payplus.co.il/statics/applePay/script.js" type="text/javascript"></script>';
		} else {

			echo "<form name='pp_form' method='GET' action='" . $res . "'></form>";
		}
		echo '<script type="text/javascript"> document.pp_form.submit(); </script>';
	}

	public function validateUrl($url = NULL)
	{
		if (filter_var($url, FILTER_VALIDATE_URL) === FALSE) return false;
		else return true;
	}

	public function post_payplus_ws($url, $payload)
	{


		$args = array(
			'body' => $payload,
			'timeout'     => '60',
			'redirection' => '5',
			'httpversion' => '1.0',
			'blocking'    => true,
			'headers'     => [],
			'headers' => array(
				'User-Agent' => 'WordPress '.$_SERVER['HTTP_USER_AGENT'],
				'Content-Type' => 'application/json',
				'Authorization' => '{"api_key":"' . $this->api_key . '","secret_key":"' . $this->secret_key . '"}'
			)
		);
		$response = wp_remote_post($url, $args);

		return $response;
	}

	public function ipn_response()
	{
		$REQUEST = $this->arr_clean($_REQUEST);
		$data = [
			'transaction_uid' => $REQUEST['transaction_uid'] ?? null,
			'page_request_uid' => $REQUEST['page_request_uid'] ?? null,
			'voucher_id' => $REQUEST['voucher_num'] ?? null,
			'token_uid' => $REQUEST['token_uid'] ?? null,
			'type' => $REQUEST['type'] ?? null,
			'order_id' => $REQUEST['more_info'] ?? null,
			'status_code' => $REQUEST['status_code'] ?? null,
			'number' => $REQUEST['number'] ?? null,
			'expiry_year' => $REQUEST['expiry_year'] ?? null,
			'expiry_month' => $REQUEST['expiry_month'] ?? null,
			'four_digits' => $REQUEST['four_digits'] ?? null,
			'brand_id' => $REQUEST['brand_id'] ?? null,
		];

		$order = $this->validateOrder($data);
        $linkRedirect=$this->get_return_url($order);
        if(!empty($REQUEST['paymentPayPlusDashboard'])){
            $order_id =$REQUEST['more_info'];
            $paymentPayPlusDashboard =$REQUEST['paymentPayPlusDashboard'];
            if($paymentPayPlusDashboard === $this->payplus_generate_key_dashboard){
                add_post_meta($order_id,"_payment_method","payplus-payment-gateway");
                add_post_meta($order_id,"_payment_method_title","Pay with Debit or Credit Card");
                $linkRedirect=get_admin_url()."post.php?post=".$order_id."&action=edit";
            }
        }
		WC()->session->__unset('save_payment_method');
		wp_redirect($linkRedirect);
	}

    // check ipn response
	public function callback_response()
	{
		$json = file_get_contents('php://input');
		$response = json_decode($json, true);

		$inputData['transaction_uid'] 	= $response['transaction']['uid'] ?? null;
		$inputData['voucher_id'] = $response['transaction']['voucher_number'] ?? null;
		$inputData['token_uid'] = $response['data']['card_information']['token'] ?? null;
		$inputData['type'] = $response['transaction_type'] ?? null;
		$inputData['order_id'] =       $response['transaction']['more_info'] ?? null;
		$inputData['status_code'] =       $response['transaction']['status_code'] ?? null;
		$inputData['number'] =       $response['transaction']['number'] ?? null;
		$inputData['expiry_year'] =       $response['data']['card_information']['expiry_year'] ?? null;
		$inputData['expiry_month'] =       $response['data']['card_information']['expiry_month'] ?? null;
		$inputData['four_digits'] =       $response['data']['card_information']['four_digits'] ?? null;
		$inputData['brand_id'] =       $response['data']['card_information']['brand_id'] ?? null;

		$this->validateOrder($inputData);
	}

	protected function validateOrder($data){

        $order_id = trim($data['order_id']);
        $order    = wc_get_order($order_id);
        $transaction_uid 	= $data['transaction_uid'];
        $page_request_uid 	= $data['page_request_uid'];
        $token_uid      = $data['token_uid'];
        $type    		= $data['type'];
        if ($order->get_meta('order_validated') == '1' || $order->get_meta('payplus_transaction_uid')!="" ) {

            return $order;
        }
        $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'New IPN Fired');
        $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Result: ' . print_r($data, true));

		if (!isset($data['transaction_uid']) && !isset($data['page_request_uid']) && !isset($data['order_id'])) {
            $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'IPN Error: missing Order ID, missing Voucher Number / Transaction UID');
			return;
		}



		$userID = 0;

		if ($order === false) {
			return;
		}

		if ($order->get_user() != false) {
			$userID = $order->get_user_id();
		}
		$IPNCheck = false;
		$createToken = false;
		$bSaveToken = ($order->get_meta('save_payment_method') === '1');
		if ($bSaveToken === true && $userID) {
			$createToken = true;
		}



        $payload = [];
      //  $payload['payment_request_uid'] = $page_request_uid;
			if (!empty( $page_request_uid)) {
                $payload['payment_request_uid'] =$page_request_uid;
			} elseif (!empty($transaction_uid)) {
                $payload['transaction_uid'] =$transaction_uid;
			}else{
                $payload['more_info'] =$order_id;
            }
            $payload['related_transaction'] =true;

			$payload = json_encode($payload);
			if ($this->logging)  $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'IPN Request: ' . print_r($payload, true));

			$response = $this->post_payplus_ws($this->ipn_url, $payload);




            if(is_wp_error($response)){
                $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Error IPN Error: ' . print_r($response, true));
            }else {

                $res = json_decode(wp_remote_retrieve_body($response));

                if ($res->results->status == "error" || $res->results->status == "rejected" ){

                    $this->logging->add('payplus_ipn', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Error IPN Error: ' . print_r($res, true));

                    if($this->failure_order_status !=='default-woo' ){
                        $order->update_status($this->failure_order_status);
                    }
                    $order->add_order_note(sprintf(__('PayPlus IPN Failed<br/>Transaction UID: %s', 'payplus-payment-gateway'), $transaction_uid));
                } else if ($res->data->status_code === '000') {
                    if( $this->add_product_field_transaction_type){
                        if($this->payplus_check_all_product($order, "2")){
                            add_post_meta($order_id,'payplus_transaction_type',"2");
                        } elseif($this->payplus_check_all_product($order, "1")){
                            add_post_meta($order_id,'payplus_transaction_type',"1");
                        }
                    }
                    $this->logging->add('payplus_ipn', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Response IPN : ' . print_r($res, true));
                    if ($this->create_pp_token && $token_uid && $userID && $createToken === true) {
                        $this->save_token($data, $userID);
                    }
                    if ($order->get_user_id() > 0) update_user_meta($order->get_user_id(), 'cc_token', $data['token_uid']);
                    $inData = array_merge($data, (array)$res->data);

                    $this->updateMetaData($order_id, $inData);

                    if (isset($res->data->recurring_type)) {
                        if ($this->recurring_order_set_to_paid == 'yes') {

                            $order->payment_complete();
                        }
                        $order->update_status('wc-recsubc');
                    } else {
                        if ($type == "Charge") {

                            if ($this->fire_completed) $order->payment_complete();
                            if($this->successful_order_status !=='default-woo' ){
                                $order->update_status($this->successful_order_status);
                            }
                        } else {
                            $order->update_status('wc-on-hold');
                        }

                        $html = '<div style="font-weight:600;">PayPlus Related Transaction';
                        if (property_exists($res->data, 'related_transactions')) {
                            $relatedTransactions = $res->data->related_transactions;

                            add_post_meta($order_id,'payplus_related_transactions',true);
                            for ($i = 0; $i < count($relatedTransactions); $i++) {
                                $relatedTransaction = $relatedTransactions[$i];

                                if(property_exists($relatedTransaction, 'alternative_method_name')
                                    ){

                                    if($relatedTransaction->alternative_method_name==="multipass"){
                                        $method =$relatedTransaction->alternative_method_name;

                                    }else{
                                        $method ="credit-card";
                                    }
                                    $alternative_method_name = $relatedTransaction->alternative_method_name;
                                }else{
                                    $method ="credit-card";
                                    $alternative_method_name = $method;
                                }

                                $transactionUid =get_post_meta($order_id,"payplus_transaction_uid_".$method,true);
                                if(!empty($transactionUid)){
                                    $transactionUid =$transactionUid."|".$relatedTransaction->transaction_uid;
                                    update_post_meta($order_id,"payplus_transaction_uid_".$method,$transactionUid);
                                }else{
                                    $transactionUid =$relatedTransaction->transaction_uid;
                                    add_post_meta($order_id,"payplus_transaction_uid_".$method,$transactionUid);
                                }
                                if ($alternative_method_name === "credit-card") {
                                    $html .= sprintf(__('
					<div style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus ' . (($type == "Approval" || $type == "Check") ? 'Pre-Authorization' : 'Payment') . ' Successful
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Last digits</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Expiry date</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Voucher ID</td><td  style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						<tr><td style="vertical-align:top;">Token</td><td style="vertical-align:top;"><a style="font-weight: bold;color:#000" class="copytoken" href="#"> %s</a></td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						</table></div>
					',
                                        'payplus-payment-gateway'),
                                        $relatedTransaction->number,
                                        $relatedTransaction->four_digits,
                                        $relatedTransaction->expiry_month . $relatedTransaction->expiry_year,
                                        $relatedTransaction->voucher_id,
                                        $relatedTransaction->token_uid,
                                        $relatedTransaction->amount

                                    );

                                } else {
                                    $html .= sprintf(__('
                      <div class="row" style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus  Successful ' .$alternative_method_name . '
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						</table></div>
					',
                                        'payplus-payment-gateway'),
                                        $relatedTransaction->number,
                                        $relatedTransaction->amount);
                                }

                            }
                            $html .= "</div>";
                            $order->add_order_note($html);

                        } else {
                            if ($res->data->method !== "credit-card") {

                                 if(!empty($res->data ->alternative_method_name)){
                                     $alternative_method_name = $res->data->alternative_method_name;
                                     if($res->data ->alternative_method_name==="multipass"){
                                         $method =$res->data ->alternative_method_name;
                                     }else{
                                         $method ="credit-card";
                                     }
                                     $transactionUid =$res->data->transaction_uid;
                                     add_post_meta($order_id,"payplus_transaction_uid_".$method,$transactionUid);
                                 }

                                $order->add_order_note(sprintf(__('
                      <div class="row" style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus  Successful ' .$alternative_method_name . '
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						</table></div>
					',
                                    'payplus-payment-gateway'),
                                    $res->data->number,
                                    $res->data->amount));

                            } else {


                                $order->add_order_note(sprintf(__('
					<div style="font-weight:600;">PayPlus ' . (($type == "Approval" || $type == "Check") ? 'Pre-Authorization' : 'Payment') . ' Successful</div>
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Last digits</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Expiry date</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Voucher ID</td><td  style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
					<tr><td style="vertical-align:top;">Token</td><td style="vertical-align:top;"><a style="font-weight: bold;color:#000" class="copytoken" href="#"> %s</a></td></tr>
					<tr><td style="vertical-align:top;">Total</td><td style="vertical-align:top;">%s</td></tr>
						</table>
					',
                                    'payplus-payment-gateway'),
                                    $data['number'],
                                    $data['four_digits'],
                                    $data['expiry_month'] . $data['expiry_year'],
                                    $data['voucher_id'],
                                    $data['token_uid'],
                                    $order->get_total()

                                ));
                            }
                        }


                    }
                } else {

                    $payplus_transaction_uid = get_post_meta($order_id, 'payplus_transaction_uid', true);

                    if (!$payplus_transaction_uid) {
                        $this->requestPayPlusIpn($payload, $data);
                    }


                }
            }
            $order->add_meta_data('order_validated', 1);
            $order->save_meta_data();



	}

    public  function  requestPayPlusIpn($payload,$data){
        $flagPayplus =true;
        $transaction_uid 	= $data['transaction_uid'];
        $page_request_uid 	= $data['page_request_uid'];
        $token_uid      = $data['token_uid'];
        $type    		= $data['type'];
        $order_id = trim($data['order_id']);
        $userID = 0;
        $order    = wc_get_order($order_id);
        $createToken = false;
        $bSaveToken = ($order->get_meta('save_payment_method') === '1');
        if ($bSaveToken === true && $userID) {
            $createToken = true;
        }
        $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'IPN Request: ' . print_r($payload, true));


        for($i=0;$i<COUNT_PAY_PLUS;$i++) {
            $response = $this->post_payplus_ws($this->ipn_url, $payload);

            if(is_wp_error($response)){
                $this->logging->add('payplus_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Error IPN Error: ' . print_r($response, true));
            }else {

                $res = json_decode(wp_remote_retrieve_body($response));

                if ($res->results->status == "error") {

                    $this->logging->add('payplus_ipn', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Error IPN Error: ' . print_r($res, true));

                    if($this->failure_order_status !=='default-woo' ){
                        $order->update_status($this->failure_order_status);
                    }
                    $order->add_order_note(sprintf(__('PayPlus IPN Failed<br/>Transaction UID: %s', 'payplus-payment-gateway'), $transaction_uid));
                    break;
                } else if ($res->data->status_code === '000') {
                    $this->logging->add('payplus_ipn', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Success IPN Result: ' . print_r($data, true));
                    if ($this->create_pp_token && $token_uid && $userID && $createToken === true) {
                        $this->save_token($data, $userID);
                    }
                    if ($order->get_user_id() > 0) update_user_meta($order->get_user_id(), 'cc_token', $data['token_uid']);
                    $inData = array_merge($data, (array)$res->data);

                    $this->updateMetaData($order_id, $inData);

                    if (isset($res->data->recurring_type)) {
                        if ($this->recurring_order_set_to_paid == 'yes') {
                            $order->payment_complete();
                        }
                        $order->update_status('wc-recsubc');
                    } else {
                        if ($type == "Charge") {
                            if ($this->fire_completed) $order->payment_complete();
                            if($this->successful_order_status !=='default-woo' ){
                                $order->update_status($this->successful_order_status);
                            }
                        } else {
                            $order->update_status('wc-on-hold');
                        }

                        $html = '<div style="font-weight:600;">PayPlus Related Transaction';
                        if (property_exists($res->data, 'related_transactions')) {
                            $relatedTransactions = $res->data->related_transactions;
                            for ($i = 0; $i < count($relatedTransactions); $i++) {
                                $relatedTransaction = $relatedTransactions[$i];
                                if(property_exists($relatedTransaction, 'alternative_method_name')
                                ){
                                    if( $relatedTransaction->alternative_method_name==="multipass"){
                                        $method =$relatedTransaction->alternative_method_name;

                                    }else{
                                        $method ="credit-card";
                                    }
                                    $alternative_method_name = $relatedTransaction->alternative_method_name;
                                }else{
                                    $method ="credit-card";
                                    $alternative_method_name = $method;
                                }

                                $transactionUid =get_post_meta($order_id,"payplus_transaction_uid_".$method,true);
                                if(!empty($transactionUid)){
                                    $transactionUid =$transactionUid."|".$relatedTransaction->transaction_uid;
                                    update_post_meta($order_id,"payplus_transaction_uid_".$method,$transactionUid);
                                }else{
                                    $transactionUid =$relatedTransaction->transaction_uid;
                                    add_post_meta($order_id,"payplus_transaction_uid_".$method,$transactionUid);
                                }
                                if ($alternative_method_name == "credit-card") {
                                    $html .= sprintf(__('
					<div style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus ' . (($type == "Approval" || $type == "Check") ? 'Pre-Authorization' : 'Payment') . ' Successful
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Last digits</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Expiry date</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Voucher ID</td><td  style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						<tr><td style="vertical-align:top;">Token</td><td style="vertical-align:top;"><a style="font-weight: bold;color:#000" class="copytoken" href="#"> %s</a></td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						</table></div>
					',
                                        'payplus-payment-gateway'),
                                        $relatedTransaction->number,
                                        $relatedTransaction->four_digits,
                                        $relatedTransaction->expiry_month . $relatedTransaction->expiry_year,
                                        $relatedTransaction->voucher_id,
                                        $relatedTransaction->token_uid,
                                        $relatedTransaction->amount

                                    );

                                } else {
                                    $html .= sprintf(__('
                      <div class="row" style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus  Successful ' .$alternative_method_name . '
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						</table></div>
					',
                                        'payplus-payment-gateway'),
                                        $relatedTransaction->number,
                                        $relatedTransaction->amount);
                                }

                            }
                            $html .= "</div>";
                            $order->add_order_note($html);

                        } else {
                            if ($res->data->method !== "credit-card") {
                                if(!empty($res->data ->alternative_method_name)){
                                    $alternative_method_name = $res->data->alternative_method_name;
                                    if($res->data ->alternative_method_name==="multipass"){
                                        $method =$res->data ->alternative_method_name;
                                    }else{
                                        $method ="credit-card";
                                    }
                                    $transactionUid =$res->data->transaction_uid;
                                    add_post_meta($order_id,"payplus_transaction_uid_".$method,$transactionUid);
                                }
                                $order->add_order_note(sprintf(__('
                      <div class="row" style="font-weight:600;border-bottom: 1px solid #000;padding: 5px 0px">PayPlus  Successful ' . $alternative_method_name . '
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Total</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
						</table></div>
					',
                                    'payplus-payment-gateway'),
                                    $res->data->number,
                                    $res->data->amount));

                            } else {


                                $order->add_order_note(sprintf(__('
					<div style="font-weight:600;">PayPlus ' . (($type == "Approval" || $type == "Check") ? 'Pre-Authorization' : 'Payment') . ' Successful</div>
						<table style="border-collapse:collapse">
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Transaction#</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Last digits</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Expiry date</td><td style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="border-bottom:1px solid #000;vertical-align:top;">Voucher ID</td><td  style="border-bottom:1px solid #000;vertical-align:top;">%s</td></tr>
							<tr><td style="vertical-align:top;">Token</td><td style="vertical-align:top;"><a style="font-weight: bold;color:#000" class="copytoken" href="#"> %s</a></td></tr>
							<tr><td style="vertical-align:top;">Total</td><td style="vertical-align:top;">%s</td></tr>
						</table>
					',
                                    'payplus-payment-gateway'),
                                    $data['number'],
                                    $data['four_digits'],
                                    $data['expiry_month'] . $data['expiry_year'],
                                    $data['voucher_id'],
                                    $data['token_uid'],
                                    $order->get_total()

                                ));
                            }
                        }


                    }

                    $flagPayplus = false;
                    break;
                }
            }
            sleep(1);



        }
        if($flagPayplus){
            $this->logging->add('payplus_ipn', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Error IPN Error: ' . print_r($res, true));
            if($this->failure_order_status !=='default-woo' ){
                $order->update_status($this->failure_order_status);
            }
            $order->add_order_note(__('PayPlus payment failed', 'payplus-payment-gateway'));
        }

    }

    public  function arrangementRelatedTransactions($relatedTransactions){

        $tempArrrelatedTransactions=array();

        for ($i = 0; $i < count($relatedTransactions); $i++) {
            $relatedTransactionsOther = $relatedTransactions[$i];
            if (property_exists($relatedTransactionsOther, 'alternative_method_name')) {
                $alternative_method_name=$relatedTransactionsOther->alternative_method_name;
                if($alternative_method_name==="multipass" || $alternative_method_name==="bit"){

                    if (!array_key_exists($relatedTransactionsOther->alternative_method_name, $tempArrrelatedTransactions)) {
                        $tempArrrelatedTransactions[$alternative_method_name] = floatval($relatedTransactionsOther->amount);
                    } else {
                        $tempArrrelatedTransactions[$alternative_method_name] .= "|" . floatval($relatedTransactionsOther->amount);
                    }

                }else{
                    $tempArrrelatedTransactions['credit-card'] =   floatval($relatedTransactionsOther->amount);
                }

            }else{
                $tempArrrelatedTransactions['credit-card'] =   floatval($relatedTransactionsOther->amount);
            }
        }
        return $tempArrrelatedTransactions;
    }

    public function updateMetaData($order_id, $response)
	{



        $order = wc_get_order($order_id);
        $appVars = array('type', 'method', 'number', 'status', 'status_code',
            'status_description', 'currency', 'four_digits', 'expiry_month', 'expiry_year',
            'number_of_payments', 'first_payment_amount', 'rest_payments_amount','voucher_id', 'voucher_num', 'approval_num', 'transaction_uid', 'token_uid', 'more_info', 'alternative_method_id', 'add_data', 'customer_name', 'identification_number', 'brand_name','clearing_name', 'alternative_method_name', 'credit_terms', 'secure3D_tracking',
            'issuer_id','issuer_name');


        if(!empty($response['related_transactions'])){
            $relatedTransactions =$response['related_transactions'];

            $relatedTransactions= $this->arrangementRelatedTransactions($relatedTransactions);
            foreach ($relatedTransactions as $key =>$value)  {
                update_post_meta($order_id, 'payplus_' . $key, wc_clean($value));
            }
        }else{
            $flagMethod =true;
            $method =$response['method'];
            if(!empty($response['alternative_method_name'])) {
                if ($response['alternative_method_name'] == "bit"
                    || $response['alternative_method_name'] == "multipass" ||
                  $response['alternative_method_name'] == "paypal"

                ) {
                    $method =$response['alternative_method_name'];
                }else{
                    if(($response['alternative_method_name'] =="google-pay" ||$response['alternative_method_name'] =="google-pay") &&
                        $this->invocie_api ->payplus_get_invoice_enable()
                    ){
                        $flagMethod=false;
                    }
                    $method ="credit-card";
                }
                update_post_meta($order_id, 'payplus_' . $response['alternative_method_name'], wc_clean($response['amount']));
            }
             if($flagMethod) {
                 update_post_meta($order_id, 'payplus_' . $method, wc_clean($response['amount']));
             }
        }
        for ($i = 0; $i < count($appVars); $i++) {
			unset($value);
			if (is_object($response)) {
				if (isset($response->data->{$appVars[$i]})) $value = $response->data->{$appVars[$i]};
				else continue;
			} else {
				if (isset($response[$appVars[$i]])) $value = $response[$appVars[$i]];
				else continue;
			}
			update_post_meta($order_id, 'payplus_' . $appVars[$i], wc_clean($value));
		}
        add_post_meta($order_id ,'payplus_refunded',$order->get_total());
		return;
	}

	// save token to user
	public function save_token($res, $user_id = false)
	{

        $this->logging->add('payplus_save_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Starting Saving Token');

		$token_num = wc_clean($res['token_uid']);
		$card_type = trim(wc_clean($res['brand_id']));
		$last_four = wc_clean($res['four_digits']);
		$exp_month = wc_clean($res['expiry_month']);
		$exp_year  = '20' . wc_clean($res['expiry_year']);

		$token = new WC_Payment_Token_CC();
		$token->set_token($token_num);
		$token->set_gateway_id($this->id);
		$token->set_card_type($card_type);
		$token->set_last4($last_four);
		$token->set_expiry_month($exp_month);
		$token->set_expiry_year($exp_year);
		$token->set_user_id($user_id ?: get_current_user_id());
		$token->save();
        $this->logging->add('payplus_save_token', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Saved And Finished: ' . print_r($token, true));

	}

    // add credit card to my account
	public function add_payment_method()
	{
        $this->logging->add('payplus_add_payment_method', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'New Add Payment Method Fired');

        $current_user = wp_get_current_user();

		$langCode = explode("_", get_locale());
		$payload = '{
    "payment_page_uid": "' . $this->settings['payment_page_id'] . '",
	"charge_method": 5,
	"language_code": "' . $langCode[0] . '",
    "expiry_datetime": "30",
    "refURL_success": "' . $this->add_payment_res_url . '",
    "refURL_failure": "' . wc_get_endpoint_url('add-payment-method') . '",
    "refURL_callback": null,
    "customer": {
        "customer_name":"' . $current_user->display_name . '",
        "email":"' . $current_user->user_email . '"
    },
    "amount": ' . rand(1, 9) . ',
    "currency_code": "' . get_woocommerce_currency() . '",
    "sendEmailApproval": false,
    "sendEmailFailure": false,
    "create_token": true,
	"more_info": "WP Token ' . get_current_user_id() . '"
}';


        $this->logging('payplus_add_payment_method', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'All data collected before Sending to PayPlus');
        $this->logging('payplus_add_payment_method', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Request: ' . print_r($payload, true));


		$response = $this->post_payplus_ws($this->payment_url, $payload);

        if (is_wp_error($response)) {
            $this->logging->add('payplus_add_payment_method', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($response, true));
            echo __('Something went wrong with the payment page') . '<hr /><b>Error:</b> ' . print_r(($response), true);
        }else{
            $res = json_decode(wp_remote_retrieve_body($response));
            if (isset($res->data->payment_page_link) && $this->validateUrl($res->data->payment_page_link)) {
                $this->logging->add('payplus_add_payment_method', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Completed');
                $this->logging->add('payplus_add_payment_method', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Response: ' . print_r($res, true));
                $this->get_payment_page($res->data->payment_page_link);
            } else {
                $this->logging->add('payplus_add_payment_method', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                echo __('Something went wrong with the payment page') . '<hr /><b>Error:</b> ' . print_r((is_array($response) ? $response['body'] : $response->body), true);
            }
        }


	}

    // check add payment ipn response
	public function add_payment_ipn_response()
	{
        $this->logging->add('payplus_add_payment_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'New Token Has Been Generated');
        $this->logging->add('payplus_add_payment_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'Response: ' . print_r($this->arr_clean($_REQUEST), true));

		if (wc_clean($_REQUEST['type']) != "token" || wc_clean($_REQUEST['method']) != "credit-card") {
            $this->logging->add('payplus_add_payment_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WS Error, No Token Type or Credit Card Method In Response');
			return;
		}

		if (wc_clean($_REQUEST['status']) == "approved" && wc_clean($_REQUEST['status_code']) == "000" && wc_clean($_REQUEST['token_uid'])) {
			wc_add_notice(__('Your new payment method has been added', 'payplus-payment-gateway'));
            $this->logging->add('payplus_add_payment_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WS Success, Token has been generated: ' . print_r($this->arr_clean($_REQUEST), true));
			$this->save_token($_REQUEST, get_current_user_id());
		} else {
			wc_add_notice(__('There was a problem adding this card', 'payplus-payment-gateway'), 'error');
            $this->logging->add('payplus_add_payment_ipn', 'Plugin Version: '.PAYPLUS_VERSION.' - '.'IPN Error: There was a problem adding this card');
		}
		wp_redirect(wc_get_endpoint_url('payment-methods', '', wc_get_page_permalink('myaccount')));
		exit;
	}

	public function scheduled_subscription_payment($amount_to_charge, $order)
	{

        if($order) {
            $token = get_user_meta($order->user_id, 'cc_token', true);
            $this->logging->add('payplus_subscription', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Subscription Started. Order ID: ' . $order->id . ' - Token: ' . $token);

            $result = $this->receipt_page($order->id, $token, true, 'WP_SUB_' . $order->id, $amount_to_charge);
            $this->logging->add('payplus_subscription', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Subscription Response ' . $order->id . ':<br />' . print_r($result, true));

            if ($result->data->status == "approved" && $result->data->status_code == "000" && $result->data->transaction_uid) {
                $order->add_order_note(sprintf(__('PayPlus Subscription Payment Successful<br/>Transaction Number: %s', 'payplus-payment-gateway'), $result->data->number));
                $this->logging->add('payplus_subscription', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Subscription ' . $order->id . ' Successful Response: ' . print_r($result, true));
                if ($this->successful_order_status !== 'default-woo') {
                    $order->update_status($this->successful_order_status);
                }
                return ["success" => true, "msg" => ""];
            } else {
                $order->add_order_note(sprintf(__('PayPlus Subscription Payment Failure<br/>Transaction Number: %s', 'payplus-payment-gateway'), $result->data->number));
                $this->logging->add('payplus_subscription', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'Subscription ' . $order->id . ' Failure Response: ' . print_r($result, true));
                return ["success" => false, "msg" => "Authorization error: " . $result->data->status_code];
            }
        }
	}

	public function arr_clean($req = [])
	{
		$REQUEST = array_map(function ($v) {
			return wc_clean($v);
		}, $req);
		return $REQUEST;
	}

	public function msg_checkout_code()
	{
		if ($this->api_test_mode) echo '<div style="background: #d23d3d; border-right: 8px #b33434 solid; border-radius: 4px; color: #FFF; padding: 5px;">' . __('Sandbox mode is active and real transaction cannot be processed. Please make sure to move production when finishing testing', 'payplus-payment-gateway') . '</div>';
	}

}

