jQuery(function ($) {
    $("#woocommerce_payplus-payment-gateway_transaction_type").change(function (){
        let value =$(this).val();
        if(value ==2){
            $("#woocommerce_payplus-payment-gateway_check_amount_authorization").prop('disabled',false);
        }else{
            $("#woocommerce_payplus-payment-gateway_check_amount_authorization").prop('disabled',true);
        }

    });
	if($("#chargeByItems").is(':checked')) $("#totalorder").show();
		else $("#totalorder").hide();
	
    if ($('div#payplus-options').length) {
		
        toggle_iframe_height();
        toggle_foreign_invoice();
		toggle_invoice_options();
		
        $(document).on('change', 'select#woocommerce_payplus-payment-gateway_display_mode', function(){
            toggle_iframe_height();
        });
        $(document).on('change', 'select#woocommerce_payplus-payment-gateway_paying_vat', function(){
            toggle_foreign_invoice();
        });
		$(document).on('change', 'select#woocommerce_payplus-payment-gateway_initial_invoice', function(){
            toggle_invoice_options();
			toggle_foreign_invoice();
        });
		
        function toggle_iframe_height() {
            var display_mode = $('select#woocommerce_payplus-payment-gateway_display_mode').val();
            if (display_mode == 'redirect') {
                $('input#woocommerce_payplus-payment-gateway_iframe_height').closest('tr').hide();
                $('input#woocommerce_payplus-payment-gateway_import_applepay_script').closest('tr').hide();
            } else {
                $('input#woocommerce_payplus-payment-gateway_iframe_height').closest('tr').show();
                $('input#woocommerce_payplus-payment-gateway_import_applepay_script').closest('tr').show();
            }
        }
		
        function toggle_foreign_invoice() {
            var invoice_option = $('select#woocommerce_payplus-payment-gateway_paying_vat').val();
            if (invoice_option == '2') {
                $('input#woocommerce_payplus-payment-gateway_paying_vat_iso_code').closest('tr').show();
                $('input#woocommerce_payplus-payment-gateway_foreign_invoices_lang').closest('tr').show();
            } else {
				$('input#woocommerce_payplus-payment-gateway_paying_vat_iso_code').closest('tr').hide();
                $('input#woocommerce_payplus-payment-gateway_foreign_invoices_lang').closest('tr').hide();
            }
        }
		
        function toggle_invoice_options() {
            var initial_invoice = $('select#woocommerce_payplus-payment-gateway_initial_invoice').val();
            if (initial_invoice == '1') {
                $('select#woocommerce_payplus-payment-gateway_paying_vat').closest('tr').show();
                $('input#woocommerce_payplus-payment-gateway_paying_vat_iso_code').closest('tr').show();
                $('input#woocommerce_payplus-payment-gateway_foreign_invoices_lang').closest('tr').show();
            } else {
                $('select#woocommerce_payplus-payment-gateway_paying_vat').closest('tr').hide();
				$('input#woocommerce_payplus-payment-gateway_paying_vat_iso_code').closest('tr').hide();
                $('input#woocommerce_payplus-payment-gateway_foreign_invoices_lang').closest('tr').hide();
            }
        }
    }
	
});