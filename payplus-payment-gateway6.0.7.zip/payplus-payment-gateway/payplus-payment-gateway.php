<?php
/*
Plugin Name: PayPlus Payment Gateway
Description: WooCommerce integration for PayPlus Payment Gateway. Accept credit cards and more alternative methods directly to your WordPress e-commerce websites, More options to Refund, Charge, Capture, Subscriptions, Tokens and much more!
Plugin URI: https://www.payplus.co.il/wordpress
Version: 6.0.7
Last updated :2022-09-12
Author: PayPlus LTD
Author URI: https://www.payplus.co.il/
License: GPLv2 or later
Text Domain: PayPlus Payment Gateway Plugin
*/

defined('ABSPATH') or die('Hey, You can\'t access this file!'); // Exit if accessed directly

define('PAYPLUS_PLUGIN_URL', plugins_url('/', __FILE__));
define('PAYPLUS_PLUGIN_DIR', dirname(__FILE__));
define('PAYPLUS_VERSION', '6.0.7');


class WC_PayPlus
{

	protected static $instance = null;

	public static function get_instance()
	{
		if (!isset(static::$instance)) {
			static::$instance = new static;
		}

		return static::$instance;
	}

	public $notices = [];

	private function __construct()
	{
		add_action('admin_init', [$this, 'check_environment']);
		add_action('admin_notices', [$this, 'admin_notices'], 15);
		add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'plugin_action_links']);
		add_action('plugins_loaded', [$this, 'init']);
        add_shortcode('error-payplus-content' ,[$this,'payplus_text_error_page']);

	}
    public  function  payplus_text_error_page(){
        $optionlanguages =get_option('settings_payplus_page_error_option');
        $locale =get_locale();

        foreach ($optionlanguages as $key =>$optionlanguage){

            if(strpos($key,$locale)!==false){
                return  $optionlanguage;
            }
        }


    }
	public function check_environment()
	{
		if (is_admin() && current_user_can('activate_plugins') && !is_plugin_active('woocommerce/woocommerce.php')) {
			$message = __('This plugin requires <a href="https://wordpress.org/plugins/woocommerce/" target="_blank">WooCommerce</a> to be activated.', 'payplus-payment-gateway');
			$this->add_admin_notice('error', $message);
			// Deactivate the plugin
			deactivate_plugins(__FILE__);

			return;
		}

		$php_version          = phpversion();
		$required_php_version = '5.4';
		if (version_compare($required_php_version, $php_version, '>')) {
			$message = sprintf(__('Your server is running PHP version %1$s but some features requires at least %2$s.', 'payplus-payment-gateway'), $php_version, $required_php_version);
			$this->add_admin_notice('warning', $message);
		}
	}

	public function add_admin_notice($type, $message)
	{
		$this->notices[] = [
			'class'   => "notice notice-$type is-dismissible",
			'message' => $message
		];
	}

	public function admin_notices()
	{
		$output = '';
		$title  = __('PayPlus Payment Gateway', 'payplus-payment-gateway');
		foreach ($this->notices as $notice) {
			$output .= "<div class='$notice[class]'><p><b>$title:</b> $notice[message]</p></div>";
		}
		echo $output;
	}

	public static function plugin_action_links($links)
	{
		$action_links = [
			'settings' => '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway') . '" aria-label="' . __('View PayPlus Settings', 'payplus-payment-gateway') . '">' . __('Settings') . '</a>'
		];
		$links        = array_merge($action_links, $links);

		return $links;
	}

	public function init()
	{
		load_plugin_textdomain('payplus-payment-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');

		if (class_exists("WooCommerce")) {
			include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_gateway.php');
			include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_subgateways.php');
			include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_admin_payments.php');
		}

		add_filter('woocommerce_payment_gateways', [$this, 'add_payplus_gateway']);
	}

	public function add_payplus_gateway($methods)
	{
		$methods[] = 'WC_PayPlus_Gateway';
		$methods[] = 'WC_PayPlus_Gateway_Bit';
		$methods[] = 'WC_PayPlus_Gateway_GooglePay';
		$methods[] = 'WC_PayPlus_Gateway_ApplePay';
		$methods[] = 'WC_PayPlus_Gateway_Multipass';

		return $methods;
	}

	public function __clone()
	{
		_doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'payplus-payment-gateway'), '2.0');
	}

	public function __wakeup()
	{
		_doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'payplus-payment-gateway'), '2.0');
	}
}

WC_PayPlus::get_instance();

// New order status AFTER woo 2.2
add_action( 'init', 'register_my_new_order_statuses' );

function register_my_new_order_statuses() {
    register_post_status( 'wc-recsubc', array(
        'label'                     => _x( 'Recurring subscription created', 'Order status', 'woocommerce' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Recurring subscription created <span class="count">(%s)</span>', 'Recurring subscription created<span class="count">(%s)</span>', 'woocommerce' )
    ) );
}

add_filter( 'wc_order_statuses', 'my_new_wc_order_statuses' );

// Register in wc_order_statuses.
function my_new_wc_order_statuses( $order_statuses ) {
    $order_statuses['wc-recsubc'] = _x( 'Recurring subscription created', 'Order status', 'woocommerce' );

    return $order_statuses;
}