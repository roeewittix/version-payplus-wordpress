<?php
defined('ABSPATH') || exit; // Exit if accessed directly
define('CREDIT_INVOICE','Credit Invoice');
define('CREDIT_RECEIPT','Credit Receipt');
define("COUNT_BALANCE_NAME",1);


class PayplusInvoice
{
    private  $payplus_invoice_option ;
    private  $payplus_gateway_option;
    private  $payplus_invoice_api_key;
    private  $payplus_invoice_secret_key;
    private $payplus_invoice_brand_uid;
    private $payplus_invoice_type_document;
    private $payplus_invoice_type_document_refund;
    private  $payplus_invoice_status_order;
    private $payplus_api_url;
    private $url_payplus_create_invoice;
    private  $logging ;

    public function __construct()
    {
        // option  gateway/invoice
        $this->payplus_gateway_option=get_option('woocommerce_payplus-payment-gateway_settings');
        $this->payplus_invoice_option =get_option('payplus_invoice_option');

        // api key/secret/brand_uid
        $this-> payplus_invoice_api_key = (isset($this->payplus_invoice_option['payplus_invoice_api_key']))?
            $this->payplus_invoice_option['payplus_invoice_api_key']:EMPTY_STRING_PAYPLUS;

        $this-> payplus_invoice_secret_key = (isset($this->payplus_invoice_option['payplus_invoice_secret_key']))?
            $this->payplus_invoice_option['payplus_invoice_secret_key'] :EMPTY_STRING_PAYPLUS;

        $this-> payplus_invoice_brand_uid = (isset($this->payplus_invoice_option['payplus_invoice_brand_uid']))?
            $this->payplus_invoice_option['payplus_invoice_brand_uid'] :EMPTY_STRING_PAYPLUS;

        if(empty($this-> payplus_invoice_api_key )){
            $this-> payplus_invoice_api_key =( !empty($this->payplus_gateway_option['api_key']))?$this->payplus_gateway_option['api_key']:EMPTY_STRING_PAYPLUS;
        }
        if(empty($this-> payplus_invoice_secret_key )){
            $this-> payplus_invoice_secret_key =( !empty($this->payplus_gateway_option['secret_key']))?$this->payplus_gateway_option['secret_key']:EMPTY_STRING_PAYPLUS;
        }
        $this->payplus_invoice_status_order ="processing";

        if(!empty($this->payplus_invoice_option['payplus_invoice_status_order'])){
            $this->payplus_invoice_status_order =$this->payplus_invoice_option['payplus_invoice_status_order'];
        }

        $this-> payplus_api_url=(isset($this->payplus_invoice_option['payplus_enable_sandbox']) )?PAYPLUS_PAYMNET_URL_DEV:PAYPLUS_PAYMNET_URL_PRODUCTION;
        $this->logging = true ;

        $this-> url_payplus_create_invoice.= $this-> payplus_api_url."books/docs/new/";
        $this->payplus_invoice_type_document=(isset($this->payplus_invoice_option['payplus_invoice_type_document']))?
            $this->payplus_invoice_option['payplus_invoice_type_document']:"";
        $this->payplus_invoice_type_document_refund =(isset($this->payplus_invoice_option['payplus_invoice_type_document_refund']))
            ?$this->payplus_invoice_option['payplus_invoice_type_document_refund']
            :"";

        //actions
        add_action('admin_init', [$this, 'payplus_invoice_set_fields_option_page']);

        if(empty($_GET['action'])) {
            add_action('woocommerce_order_status_'.  $this->payplus_invoice_status_order, [$this, 'payplus_invoice_create_order']);
        }

        add_action('admin_enqueue_scripts',  [$this, 'payplus_invoice_css_admin']);
        add_action( 'wp_ajax_payplus-api-payment-refund',  [$this,'ajax_payplus_api_payment_refund' ]);
        add_action('admin_head',  [$this,'payplus_menu_css']);

        //filters
        add_filter( 'manage_edit-shop_order_columns', [$this,'payplus_invoice_add_order_columns'], 20);
    }

    public  function payplus_get_type_document(){
        return  $this->payplus_invoice_option['payplus_invoice_type_document'];
    }

    public function payplus_get_invoice_enable(){

        return  ( isset($this->payplus_invoice_option['payplus_invoice_enable']) )?
            $this->payplus_invoice_option['payplus_invoice_enable']:false;

    }

    public  function payplus_get_invoice_type_document_refund(){
        return $this->payplus_invoice_type_document_refund;
    }

    public  function payplus_get_setting_invoice(){
        return    $this->payplus_invoice_option;
    }

    function payplus_menu_css() {
        echo '<style>
        #adminmenu .wp-submenu li.sub-payplus{
            margin: 0px  10px;
            position: relative;
        }
        .sub-payplus.menu-multipass:before{
            content:"... BuyMe,Mifal Hapais  etc";
            position: absolute;
            top:25px;
            left:0px;
            background: #fff;
            color: #000;
            display: none;
            max-width: 160px;
            width: 100%;
            text-align: center;
            border-radius: 15px;
            padding: 5px 5px;
            font-size: 12px;
         }
         .sub-payplus.menu-multipass:hover:before{
             display: block;
         }
         .toplevel_page_payplus,
         #adminmenu li.menu-top.toplevel_page_payplus:hover,
         #adminmenu li>a.menu-top.toplevel_page_payplus:focus ,
         #adminmenu li.opensub.toplevel_page_payplus>a.menu-top,
         #adminmenu li.opensub.toplevel_page_payplus div.wp-menu-image:before,
         #adminmenu li.toplevel_page_payplus  div.wp-menu-image:before,
         #adminmenu  li.toplevel_page_payplus a:hover
         {
             background: #34aa54;
             color:#fff
         }
          </style>';
    }

    public  function  payplus_order_item_add_action_buttons_callback($order){

        global  $post;
        ob_start();
         $orderId =$post->ID;
        $payplusInvoiceOption =get_option('payplus_invoice_option');
        $payplusInvoiceOriginalDocAddressRefund =get_post_meta($orderId,"payplus_refund",true);
        $payplusType =get_post_meta($orderId,"payplus_type",true) ;
        $optionPaypluspaymentgGteway =(object)get_option('woocommerce_payplus-payment-gateway_settings');


        if($this->payplus_get_invoice_enable() &&$optionPaypluspaymentgGteway->enabled=="no" && !$payplusInvoiceOriginalDocAddressRefund && $payplusType!=="Approval"  &&  $payplusType!=="Check"):
            ?>
            <button type="button" id="order-payment-payplus-refund" data-id="<?php echo  $orderId ?>" class="button item-refund"><?php echo __("create invoice refund","payplus-payment-gateway") ?></button>
                <div class='payplus_loader_refund'></div>

            <?php
        endif;
        $output = ob_get_clean();
        echo  $output;
    }

    public function payplus_create_dcoment($order_id,$typeDocument,$typePayment="",$nameRefund=""){
            global $wp_version , $wpdb;
            $WC_PayPlus_Gateway =new WC_PayPlus_Gateway();
            $order=wc_get_order($order_id);
           $payplus_invoice_option =get_option('payplus_invoice_option');
            $payplus_invoice_rounding_decimals =$WC_PayPlus_Gateway->rounding_decimals;
            $payplus_invoice_send_document_sms =(isset($payplus_invoice_option['payplus_invoice_send_document_sms']))?true :false;
            $payplus_invoice_send_document_email =(isset($payplus_invoice_option['payplus_invoice_send_document_email']))?true :false;
            $dual =1;
             $resultApps = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}postmeta WHERE post_id = ".$order_id .
        " AND  (meta_key LIKE   '%payplus_credit-card%'  OR meta_key LIKE '%payplus_multipass%' 
         OR meta_key LIKE '%payplus_bit%'  OR  meta_key LIKE '%payplus_max%' 
         OR meta_key LIKE '%payplus_apple-pay%' OR meta_key LIKE '%payplus_google-pay%'
         OR meta_key LIKE '%payplus_paypal%'
         )", OBJECT);

        if($typeDocument==="inv_refund_receipt"){
            $dual=-1;
            $typeDocument ="inv_receipt";
        }

        $payload =array();
        if ($this->logging) $logger = wc_get_logger();


        $address = trim(str_replace(["'", '"', "\\"], '', $order->get_billing_address_1() . ' ' . $order->get_billing_address_2()));
        $city = str_replace(["'", '"', "\\"], '', $order->get_billing_city());
        $postal_code = str_replace(["'", '"', "\\"], '', $order->get_billing_postcode());
        $payload ['customer'] =array();
        $customerName ="";
        $company=$order->get_billing_company();
        if( $WC_PayPlus_Gateway->exist_company && !empty($company)){
            $customerName = $company;
        }else {
            if( !empty($order->get_billing_first_name() )|| !empty($order->get_billing_last_name())){
                $customerName = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            }
            if (!$customerName) {
                $customerName = $company;
            } elseif ($company) {
                $customerName .= " (" . $company . ")";
            }
        }
        if(empty($customerName)){
            $payload ['customer']['name'] = __("General Customer - לקוח כללי", 'payplus-payment-gateway');
        }else{
            $payload ['customer']['name'] =$customerName;
        }
        $payload['customer']['phone'] =$order->get_billing_phone();
        $payload ['customer']['email'] =$order->get_billing_email();
        $payload ['customer']['street_name'] =$address;
        $payload ['customer']['create_customer'] =true;
        $customer_country_iso = $order->get_billing_country();
        if ($city) {
            $payload ['customer']['city'] = $city;
        }
        if ($postal_code) {
            $payload ['customer']['postal_code'] = $postal_code;
        }
        if ($customer_country_iso) {
            $payload ['customer']['country_iso'] = $customer_country_iso;
        }
        $totalCartAmount = 0;
        $totallCart =floatval($order->get_total()) ;
            foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data) {
                $dataArr =$item_data->get_data();
                $item_name = $item_data['name'];
                $item_meta_name = '';
                $couponPrice = 0;
                $quantity = ($item_data['quantity'] ? $item_data['quantity'] : '1');
                // Only for product variation
                $item_meta = @new WC_Order_Item_Meta($item_data);
                if ($meta = $item_meta->display(true, true)) $item_meta_name = $meta;

                if ($item_data['type'] == "coupon") {
                    if ($item_data['discount']) $couponPrice =( $item_data['discount'] + $item_data['discount_tax']);
                    else $couponPrice = ($item_data['line_total'] + $item_data['line_total_tax']);
                    $productPrice = '-' . round($couponPrice, $payplus_invoice_rounding_decimals);
                    $totalCartAmount += ($productPrice);
                } else if ($item_data['type'] == "fee") {
                    $productPrice = round(($item_data['line_total'] + $item_data['line_total_tax'])*$dual*$quantity, $payplus_invoice_rounding_decimals);
                    $totalCartAmount += $productPrice;
                } else {

                        $productPrice = round((($item_data['line_subtotal'] + $item_data['line_subtotal_tax']) / $item_data['quantity'])*$dual *$quantity , $payplus_invoice_rounding_decimals);

                        $totalCartAmount += ($productPrice * $quantity);


                }

                $product = new WC_Product($item_data['product_id']);
                $productSKU = ($product->get_sku()) ? $product->get_sku():$item_data['product_id'];
                if(!empty($dataArr['variation_id'])) {
                    $product = new WC_Product_Variable($dataArr['product_id']);
                    $variationsProduct =$product->get_available_variations();
                    if(count($variationsProduct)){
                        $productSKU = ($variationsProduct[0]['sku']) ? $variationsProduct[0]['sku'] :
                            $variationsProduct[0]['variation_id'];
                    }


                }

                $itemDetails = [
                    'name' => str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_name)),
                    'barcode' => (string)$productSKU,
                    'quantity' => 1,
                    'price' => $productPrice
                ];
                if ($item_data->get_tax_status() == 'none') {
                    $itemDetails['vat_type'] = 2;
                } else {
                    $itemDetails['vat_type'] = 0;
                }
                if($WC_PayPlus_Gateway->paying_vat_all_order==="yes"){
                    $itemDetails['vat_type'] = 0;
                }
                $productsItems[] = $itemDetails;
            }
        // order shipping
        //  if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())) {
        foreach ($order->get_shipping_methods() as $shipping_method) {
            $shipping_method_data = $shipping_method->get_data();

            if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())
                || $shipping_method_data['method_id'] === "free_shipping") {
                $totalLine = round((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() + $order->get_shipping_tax() : $order->get_shipping_total() + $order->get_shipping_tax()), $payplus_invoice_rounding_decimals);

                $productsItems[] = array(
                    "name" => __('Shipping', 'payplus-payment-gateway') . ' - ' . str_replace(["'", '"', "\\"], '', $shipping_method_data['name']),
                    "quantity" => 1,
                    "price" => $totalLine * $dual
                );
                $totalCartAmount += $totalLine;
            }
        }
            $payload['currency_code']=get_woocommerce_currency();
            $payload['autocalculate_rate']=true;
            $payload['items'] =$productsItems;
            $payload['totalAmount']=$dual*$totallCart;
            $payload['language'] =$this->payplus_invoice_option['payplus_langrage_invoice'];
            $payload['more_info'] =$order_id;
            $payload['send_document_email']=$payplus_invoice_send_document_email;
            $payload['send_document_sms']=$payplus_invoice_send_document_sms;

            if($this->payplus_gateway_option['enabled']==="no" && !count($resultApps))   {
                $objectInvociePaymentNoPayplus=array('meta_key'=>'payplus_other','meta_value'=>$dual *$payload['totalAmount']);
                $objectInvociePaymentNoPayplus = (object)$objectInvociePaymentNoPayplus;

                $resultApps [] =$objectInvociePaymentNoPayplus;
            }
          if(count($resultApps)){
              $arrTypeNotApp =array('credit-card','paypal','other');
              $payload ['payments'] =array();
              for($i=0;$i<count($resultApps);$i++){
                  $resultApp =$resultApps[$i];

                  $paymentType ='payment-app';
                  if($resultApp->meta_key == "payplus_credit-card") {
                      $paymentType = 'credit-card';
                  }elseif($resultApp->meta_key == "payplus_paypal"){
                      $paymentType='paypal';
                  }elseif($resultApp->meta_key == "payplus_other"){
                             $paymentType='other';
                    }
                  $type =explode("_",$resultApp->meta_key);
                  $typePaymentType['payment_type']= $paymentType;
                  $typePaymentType['amount']= $dual *floatval($resultApp->meta_value);
                 if(!in_array($type[1],$arrTypeNotApp)){
                     $typePaymentType['payment_app']= $type[1];
                 }
                 $payload ['payments'][] =$typePaymentType;
             }
        }

        $titleLog =($typePayment=="charge")?"":"_refund";
        if ($this->logging) $logger->add('payplus_invoice_payload'.$titleLog, 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($payload, true));

        $payload =json_encode($payload);

        $response=  $this->post_payplus_ws( $this-> url_payplus_create_invoice.$typeDocument,$payload);


        if(is_wp_error($response)) {
            if ($this->logging) $logger->add('payplus_invoice_response_error'.$titleLog, 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($response, true));
                return false;
        }else{
            $res = json_decode(wp_remote_retrieve_body($response));
            if($res->status==="success"){
                $responeType=($typePayment=="charge")?"":"_refund_".$type[1];


                if ($this->logging) $logger->add('payplus_invoice_response'.$titleLog, 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($res, true));
                    add_post_meta($order_id,"payplus_invoice_docUID_refund_".$responeType ,$res->details->docUID);
                    add_post_meta($order_id,"payplus_invoice_numberD_refund_" .$responeType,$res->details->number);
                    add_post_meta($order_id,"payplus_invoice_originalDocAddress_refund_".$responeType ,$res->details->originalDocAddress);
                    add_post_meta($order_id,"payplus_invoice_copyDocAddress".$responeType ,$res->details->copyDocAddress);
                    add_post_meta($order_id,"payplus_invoice_customer_uuid".$responeType ,$res->details->customer_uuid);
                    $titleNote =($typePayment=="charge")?"PayPlus Document":"PayPlus Document Refund ".$nameRefund;
                    $link =($typePayment=="charge")?__('Link Document','payplus-payment-gateway'):__('Link Document Refund','payplus-payment-gateway');
              $order ->add_order_note('<div style="font-weight:600">'.$titleNote.'</div>
                 <a class="link-invoice" target="_blank" href="'.$res->details->originalDocAddress.'">'.$link.'</a>');
                 return true;

            }else{
                if ($this->logging) $logger->add('payplus_invoice_response_error'.$titleLog, 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($res, true));
                 return false;

            }
        }
    }

    public function generatePayloadInvocie($order_id,$payplus_invoice_type_document_refund,$payments,$sum,$unique_identifier){
        global  $wp_version;
        $WC_PayPlus_Gateway =new WC_PayPlus_Gateway();
        $payplusBalanceNames=[];
        $payplus_invoice_option =get_option('payplus_invoice_option');
        $payplus_invoice_send_document_sms =(isset($payplus_invoice_option['payplus_invoice_send_document_sms']))?true :false;
        $payplus_invoice_send_document_email =(isset($payplus_invoice_option['payplus_invoice_send_document_email']))?true :false;
        $dual =1;
        if($payplus_invoice_type_document_refund==="inv_refund_receipt"){
            $dual=-1;
        }
        $order=wc_get_order($order_id);
        $payload =array();
        $logger = wc_get_logger();
        $address = trim(str_replace(["'", '"', "\\"], '', $order->get_billing_address_1() . ' ' . $order->get_billing_address_2()));
        $city = str_replace(["'", '"', "\\"], '', $order->get_billing_city());
        $postal_code = str_replace(["'", '"', "\\"], '', $order->get_billing_postcode());
        $payload ['customer'] =array();

        if(!empty($this->payplus_invoice_brand_uid)){
            $payload['brand_uuid'] =$this->payplus_invoice_brand_uid;
        }
        $customerName ="";
        $company=$order->get_billing_company();
        if( $WC_PayPlus_Gateway->exist_company && !empty($company)){
            $customerName = $company;
        }else {
            if( !empty($order->get_billing_first_name() )|| !empty($order->get_billing_last_name())){
                $customerName = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            }
            if (!$customerName) {
                $customerName = $company;
            } elseif ($company) {
                $customerName .= " (" . $company . ")";
            }
        }
        if(empty($customerName)){
            $payload ['customer']['name'] = __("General Customer - לקוח כללי", 'payplus-payment-gateway');
        }else{
            $payload ['customer']['name'] =$customerName;
        }
        $payload ['customer']['email'] =$order->get_billing_email();
        $payload['customer']['phone'] =$order->get_billing_phone();
        $payload ['customer']['street_name'] =$address;
        $payload ['customer']['create_customer'] =true;
        $customer_country_iso = $order->get_billing_country();
        if ($city) {
            $payload ['customer']['city'] = $city;
        }
        if ($postal_code) {
            $payload ['customer']['postal_code'] = $postal_code;
        }
        if ($customer_country_iso) {
            $payload ['customer']['country_iso'] = $customer_country_iso;
        }
        $productsItems =[];
            foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data) {
                $dataArr =$item_data->get_data();
                $item_name = $item_data['name'];
                $item_meta_name = '';
                $couponPrice = 0;
                $quantity = ($item_data['quantity'] ? $item_data['quantity'] : '1');
                // Only for product variation
                $item_meta = @new WC_Order_Item_Meta($item_data);
                if ($meta = $item_meta->display(true, true)) $item_meta_name = $meta;

                if ($item_data['type'] == "coupon") {
                    if ($item_data['discount']) $couponPrice = $item_data['discount'] + $item_data['discount_tax'];
                    else $couponPrice = $item_data['line_total'] + $item_data['line_total_tax'];
                    $productPrice = '-' . round($couponPrice, $WC_PayPlus_Gateway->rounding_decimals);
                    $totalCartAmount += ($productPrice);
                } else if ($item_data['type'] == "fee") {
                    $productPrice = round(($item_data['line_total'] + $item_data['line_total_tax']), $WC_PayPlus_Gateway->rounding_decimals);
                    $totalCartAmount += $productPrice;
                } else {
                    if ($WC_PayPlus_Gateway->single_quantity_per_line == 'yes') {
                        $productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']), $WC_PayPlus_Gateway->rounding_decimals);
                        $totalCartAmount += ($productPrice);
                        $item_name .= ' ×  '.$quantity;
                        $quantity = 1;
                    } else {
                        $productPrice = round(($item_data['line_subtotal'] + $item_data['line_subtotal_tax']) / $item_data['quantity'], $WC_PayPlus_Gateway->rounding_decimals);
                        $totalCartAmount += ($productPrice * $quantity);
                    }
                }
                //LearnPress
                if(get_class($item_data)==="WC_Order_Item_LP_Course"){
                    $product = new WC_Product_LP_Course($item_data['product_id']);
                }else{
                    $product = new WC_Product($item_data['product_id']);
                }

                $payplusBalanceName =$product->get_meta('payplus_balance_name');

                if(!empty($payplusBalanceName)){
                    $payplusBalanceNames[] =$payplusBalanceName;
                }
                $productSKU = ($product->get_sku()) ? $product->get_sku():$item_data['product_id'];
                if(!empty($dataArr['variation_id'])) {
                    $product = new WC_Product_Variable($dataArr['product_id']);
                    $variationsProduct =$product->get_available_variations();
                    if(count($variationsProduct)){
                        $productSKU = ($variationsProduct[0]['sku']) ? $variationsProduct[0]['sku'] :
                            $variationsProduct[0]['variation_id'];
                    }
                    $product_attributes = $product->get_attributes();
                    $itemNameAttributes  ="";
                    foreach ($product_attributes as $key =>$value){

                        $manufacturer_id = $product_attributes[$key]['options']['0']; // returns the ID of the term
                        $manufacturer_name = get_term( $manufacturer_id ); // gets the term name of the term from the ID

                        $nameTaxonomy =str_replace("pa_",'',$manufacturer_name->taxonomy);
                        $nameTaxonomy =str_replace("-",' ',$nameTaxonomy);
                        $valueTaxonomy =$manufacturer_name->name;

                        $itemNameAttributes.=(empty($itemNameAttributes)) ?$nameTaxonomy." : ".$valueTaxonomy :" , ". $nameTaxonomy." : ".$valueTaxonomy;

                    }
                    $item_name =$item_name." ( ".$itemNameAttributes." ) ";
                }
                $itemDetails = [
                    'name' => str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_name)),
                    'barcode' => (string)($productSKU ? $productSKU : $item_data['product_id']),
                    'quantity' => ($quantity ? $quantity : '1'),
                    'price' => $productPrice*$dual
                ];



                if ($item_data->get_tax_status() == 'none'){
                    $itemDetails['vat_type'] = 2;
                } else {
                    $itemDetails['vat_type'] = 0;
                }

                if($WC_PayPlus_Gateway->paying_vat_all_order==="yes"){
                    $itemDetails['vat_type'] = 0;
                }

                $productsItems[] = $itemDetails;
            }


        // order shipping
        //  if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())) {
        foreach ($order->get_shipping_methods() as $shipping_method) {
            $shipping_method_data = $shipping_method->get_data();

            if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())
                || $shipping_method_data['method_id'] === "free_shipping") {
                $totalLine = round((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() + $order->get_shipping_tax() : $order->get_shipping_total() + $order->get_shipping_tax()), $payplus_invoice_rounding_decimals);

                $productsItems[] = array(
                    "name" => __('Shipping', 'payplus-payment-gateway') . ' - ' . str_replace(["'", '"', "\\"], '', $shipping_method_data['name']),
                    "quantity" => 1,
                    "price" => $totalLine * $dual
                );
                $totalCartAmount += $totalLine;
            }
        }

        // discount payment
        if(floatval($totalCartAmount)!=$sum){
            $discount =-1 *round( ($totalCartAmount -$sum),2) *$dual;
            $totalCartAmount =$sum;
            $productsItems[] = 	array( "barcode" =>"discount",
					"name" => "discount",
					"quantity"=> 1,
					"price" =>  $discount);
        }
        $payload['currency_code']=get_woocommerce_currency();
        $payload['autocalculate_rate']=true;
        $payload['items']  = $productsItems;
        $payload['totalAmount'] = $dual * $sum;
        $payload['language'] =$payplus_invoice_option['payplus_langrage_invoice'];
        $payload['more_info'] = $order_id;


        $payload['send_document_email'] = $payplus_invoice_send_document_email;
        $payload['send_document_sms'] = $payplus_invoice_send_document_sms;

        if(!empty($unique_identifier)){
            $payload['unique_identifier'] =$unique_identifier;
        }
        if(count($payments)) {
            $payload ['payments'] = array();
            foreach ($payments as $key =>$value) {

                if (strpos($value->meta_key,'payplus_multipass')===false){

                    $payplus_alternative_method_name = get_post_meta($order_id, 'payplus_alternative_method_name', true);
                    if ($payplus_alternative_method_name !="paypal") {
                        $typePaymentType['payment_type'] = 'payment-app';
                        $typePaymentType['amount'] = $sum * $dual;
                        $typePaymentType['payment_app'] = $payplus_alternative_method_name;
                        $payload ['payments'][] = $typePaymentType;

                    } else {
                        $paymentType =($payplus_alternative_method_name=="paypal")?'paypal' :'credit-card';
                        $typePaymentType['payment_type'] = $paymentType;
                        $typePaymentType['amount'] = $sum * $dual;
                        $typePaymentType['payment_app'] = $payplus_alternative_method_name;
                        $payload ['payments'][] = $typePaymentType;
                    }
                }
                else{
                        $typePaymentType['payment_type'] = 'payment-app';
                        $typePaymentType['amount'] = $sum * $dual;
                        $typePaymentType['payment_app'] = 'multipass';
                        $payload ['payments'][] = $typePaymentType;
                }


            }
        }else{
            $otherMethod = strtolower(get_post_meta($order_id,'_payment_method_title',true));
            if($otherMethod ==="paypal"){
                $typePaymentType['payment_type'] =$otherMethod;
            }else{
                $typePaymentType['payment_type'] ="other";
            }
            $typePaymentType['amount'] = $sum * $dual;
            $payload ['payments'][] = $typePaymentType;
        }
        if(count($payplusBalanceNames)){
            if(count($payplusBalanceNames)==COUNT_BALANCE_NAME){
                $payload ['customer']['balance_name'] =$payplusBalanceNames[COUNT_BALANCE_NAME-1];
            }
        }

        return $payload;
    }

    public function  createRefundInvoice($order_id,$documentType,$payload,$nameDocment){

        $logger = wc_get_logger();
        $order = wc_get_order($order_id);
        $payload = json_encode($payload);
        $titleLog ="_refund";
        $response=  $this->post_payplus_ws( $this-> url_payplus_create_invoice.$documentType,$payload);
        if(is_wp_error($response)) {
            if ($this->logging) $logger->add('payplus_invoice_response_error'.$titleLog, 'Plugin Version: '.PAYPLUS_VERSION.' - '.'WP Remote Post Error: ' . print_r($response, true));
            return false;
        }else {
            $res = json_decode(wp_remote_retrieve_body($response));
            if ($res->status === "success") {
                $responeType = "_refund" . $documentType;

                if ($this->logging) $logger->add('payplus_invoice_response' . $titleLog, 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                add_post_meta($order_id, "payplus_invoice_docUID_refund_" . $responeType, $res->details->docUID);
                add_post_meta($order_id, "payplus_invoice_numberD_refund_" . $responeType, $res->details->number);
                add_post_meta($order_id, "payplus_invoice_originalDocAddress_refund_" . $responeType, $res->details->originalDocAddress);
                add_post_meta($order_id, "payplus_invoice_copyDocAddress" . $responeType, $res->details->copyDocAddress);
                add_post_meta($order_id, "payplus_invoice_customer_uuid" . $responeType, $res->details->customer_uuid);
                $titleNote = "PayPlus Document Refund " .$nameDocment;
                $link = __('Link Document Refund', 'payplus-payment-gateway');
                $order->add_order_note('<div style="font-weight:600">' . $titleNote . '</div>
                 <a class="link-invoice" target="_blank" href="' . $res->details->originalDocAddress . '">' . $link . '</a>');
                return true;

            } else {
                if ($this->logging) $logger->add('payplus_invoice_response_error' . $titleLog, 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                return false;

            }

        }

    }

    public  function payplus_create_dcoment_dasbord($order_id,$payplus_invoice_type_document_refund ,$payments,$sum,$unique_identifier=null){

        if ($payplus_invoice_type_document_refund === "inv_refund_receipt") {
            $payplus_document_type = "inv_receipt";
            $payload =$this->generatePayloadInvocie($order_id,$payplus_document_type,$payments,$sum,$unique_identifier);
            $this->createRefundInvoice($order_id,$payplus_document_type,$payload,CREDIT_RECEIPT);
        }
        if($payplus_invoice_type_document_refund=="inv_refund_receipt_invoice") {
            $payload =$this->generatePayloadInvocie($order_id,'inv_refund',$payments,$sum,$unique_identifier);
            $this->createRefundInvoice($order_id,'inv_refund',$payload,CREDIT_INVOICE);

            $payplus_document_type = "inv_receipt";
            $payload =$this->generatePayloadInvocie($order_id,'inv_refund_receipt',$payments,$sum,$unique_identifier."_other");
            $this->createRefundInvoice($order_id,$payplus_document_type,$payload,CREDIT_RECEIPT);
        }else{
            $payload =$this->generatePayloadInvocie($order_id,$payplus_invoice_type_document_refund,$payments,$sum,$unique_identifier);
            $this->createRefundInvoice($order_id,$payplus_invoice_type_document_refund,$payload,CREDIT_INVOICE);
        }


    }

    public  function ajax_payplus_api_payment_refund(){

        global $wp_version , $wpdb;
         if(!empty($_POST)){

              $order_id=$_POST['order_id'];
              $urlEdit= get_admin_url()."post.php?post=".$order_id."&action=edit";
             $payplus_document_type=$this->payplus_invoice_option['payplus_invoice_type_document_refund'];
             if($payplus_document_type=="inv_refund_receipt_invoice"){
                 $resultinvoice=$this->payplus_create_dcoment($order_id,'inv_refund','',CREDIT_INVOICE);
                 $resultReceipt=$this->payplus_create_dcoment($order_id,"inv_refund_receipt",'',CREDIT_RECEIPT);
                if($resultinvoice &&$resultReceipt ){
                     echo json_encode(array("urlredirect"=>$urlEdit,"status"=>true));
                       add_post_meta($order_id,'payplus_refund',true);
                        wp_die();
                }else{
                    echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                    wp_die();
                }
             }else{
                 $nameRefund =($payplus_document_type=="inv_refund")?CREDIT_INVOICE:CREDIT_RECEIPT;
                 $resultinvoice=$this->payplus_create_dcoment($order_id,$payplus_document_type,'',$nameRefund);

                  if($resultinvoice ){
                        echo json_encode(array("urlredirect"=>$urlEdit,"status"=>true));
                        add_post_meta($order_id,'payplus_refund',true);
                        wp_die();
                  }else{
                      echo json_encode(array("urlredirect"=>$urlEdit,"status"=>false));
                      wp_die();
                  }
             }
         }
        wp_die();
    }

    public    function payplus_add_order_column_order_invoice($column){
        global $post;
        $order = wc_get_order($post->ID);
        $payplus_invoice_option =get_option('payplus_invoice_option');
        if ('order_invoice' === $column && $payplus_invoice_option['payplus_invoice_enable']) {

              $payplus_invoice_originalDocAddress=   get_post_meta($post->ID,"payplus_invoice_originalDocAddress", true);
              if($payplus_invoice_originalDocAddress){
                echo "<a  class='link-invoice' target='_blank' href='".$payplus_invoice_originalDocAddress."'>" .__('Link document','payplus-payment-gateway')."</a>";
              }
        }
    }

    public function payplus_invoice_add_order_columns($columns){

        $new_columns = array();
        $payplus_invoice_option =get_option('payplus_invoice_option');
        foreach ( $columns as $column_name => $column_info ) {
            $new_columns[$column_name] = $column_info;
            if ('shipping_address' === $column_name && isset($payplus_invoice_option['payplus_invoice_enable'])) {
                $new_columns['order_invoice'] = "<span class='text-center'>" . __('Link Document  ', 'payplus-payment-gateway') . "</span>";

             }
        }
        return $new_columns;
    }

    function payplus_invoice_css_admin($hook)
    {
        $current_screen = get_current_screen();


        if ( strpos($current_screen->base, 'page_invoice-payplus') !== false
         ||$current_screen->id==="edit-shop_order" ||
         $current_screen->id==="shop_order") {
            wp_enqueue_style('payplus_invoice-admin-css', PAYPLUS_PLUGIN_URL.'assets/css/invoice_admin.min.css',__FILE__ );
        }
    }

    public  function payplus_invoice_create_order($order_id){


            global $wp_version, $wpdb;
            $WC_PayPlus_Gateway = new WC_PayPlus_Gateway();
            $checkInvocieSend = get_post_meta($order_id, 'payplus_check_invoice_send', true);
            $payplusBalanceNames = [];
            if (empty($checkInvocieSend) && $this->payplus_get_invoice_enable()) {

                $payplus_invoice_option = get_option('payplus_invoice_option');

                $payplusType = get_post_meta($order_id, 'payplus_type', true);
                $j5 = ($this->payplus_get_invoice_enable() === "on" && $payplusType === "Charge");
                if ($j5 || ($this->payplus_gateway_option['enabled'] === "no" || ($this->payplus_gateway_option['transaction_type'] !== "2"
                            && $payplusType !== "Check" && $payplusType !== "Approval"))) {

                    $payplus_invoice_rounding_decimals = $WC_PayPlus_Gateway->rounding_decimals;

                    $payplus_invoice_send_document_sms = (isset($payplus_invoice_option['payplus_invoice_send_document_sms'])) ? true : false;
                    $payplus_invoice_send_document_email = (isset($payplus_invoice_option['payplus_invoice_send_document_email'])) ? true : false;
                    $payplus_document_type = $this->payplus_invoice_option['payplus_invoice_type_document'];
                    $dual = 1;
                    $resultApps = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}postmeta WHERE post_id = " . $order_id .
                        " AND  (meta_key LIKE   '%payplus_credit-card%'  OR meta_key LIKE '%payplus_multipass%' 
         OR meta_key LIKE '%payplus_bit%'  OR  meta_key LIKE '%payplus_max%' OR meta_key LIKE '%payplus_apple-pay%'
          OR meta_key LIKE '%payplus_google-pay%'  OR meta_key LIKE '%payplus_paypal%'
         )", OBJECT);


                    if ($payplus_document_type === "inv_refund_receipt") {
                        $dual = -1;
                        $payplus_document_type = "inv_receipt";
                    }
                    $payload = array();
                    if ($this->logging) $logger = wc_get_logger();
                    $date = new DateTime();
                    $date = $date->format('m-d-Y H:i');

                    $order = wc_get_order($order_id);
                    $address = trim(str_replace(["'", '"', "\\"], '', $order->get_billing_address_1() . ' ' . $order->get_billing_address_2()));
                    $city = str_replace(["'", '"', "\\"], '', $order->get_billing_city());
                    $postal_code = str_replace(["'", '"', "\\"], '', $order->get_billing_postcode());
                    $payload ['customer'] = array();
                    $customerName = "";
                    $company = $order->get_billing_company();
                    if (!empty($this->payplus_invoice_brand_uid)) {
                        $payload['brand_uuid'] = $this->payplus_invoice_brand_uid;
                    }


                    if ($WC_PayPlus_Gateway->exist_company && !empty($company)) {
                        $customerName = $company;
                    } else {
                        if (!empty($order->get_billing_first_name()) || !empty($order->get_billing_last_name())) {
                            $customerName = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                        }
                        if (!$customerName) {
                            $customerName = $company;
                        } elseif ($company) {
                            $customerName .= " (" . $company . ")";
                        }
                    }
                    if (empty($customerName)) {
                        $payload ['customer']['name'] = __("General Customer - לקוח כללי", 'payplus-payment-gateway');
                    } else {
                        $payload ['customer']['name'] = $customerName;
                    }
                    $payload ['customer']['email'] = $order->get_billing_email();
                    $payload['customer']['phone'] = $order->get_billing_phone();
                    $payload ['customer']['street_name'] = $address;
                    $payload ['customer']['create_customer'] = true;
                    $customer_country_iso = $order->get_billing_country();
                    if ($city) {
                        $payload ['customer']['city'] = $city;
                    }
                    if ($postal_code) {
                        $payload ['customer']['postal_code'] = $postal_code;
                    }
                    if ($customer_country_iso) {
                        $payload ['customer']['country_iso'] = $customer_country_iso;
                    }
                    $totalCartAmount = 0;
                    $totallCart = floatval($order->get_total());
                    foreach ($order->get_items(['line_item', 'fee', 'coupon']) as $item => $item_data) {
                        $dataArr = $item_data->get_data();
                        $item_name = $item_data['name'];
                        $item_meta_name = '';
                        $couponPrice = 0;
                        $quantity = ($item_data['quantity'] ? $item_data['quantity'] : '1');
                        // Only for product variation
                        $item_meta = @new WC_Order_Item_Meta($item_data);
                        if ($meta = $item_meta->display(true, true)) $item_meta_name = $meta;

                        if ($item_data['type'] == "coupon") {
                            if ($item_data['discount']) $couponPrice = ($item_data['discount'] + $item_data['discount_tax']);
                            else $couponPrice = ($item_data['line_total'] + $item_data['line_total_tax']);
                            $productPrice = '-' . round($couponPrice, $payplus_invoice_rounding_decimals);
                            $totalCartAmount += ($productPrice);
                        } else if ($item_data['type'] == "fee") {
                            $productPrice = round(($item_data['line_total'] + $item_data['line_total_tax']) * $dual, $payplus_invoice_rounding_decimals);
                            $totalCartAmount += $productPrice;
                        } else {
                            $productPrice = round((($item_data['line_subtotal'] + $item_data['line_subtotal_tax']) / $item_data['quantity']) * $dual, $payplus_invoice_rounding_decimals);
                            $totalCartAmount += ($productPrice * $quantity);

                        }
                        //LearnPress
                        if (get_class($item_data) === "WC_Order_Item_LP_Course") {
                            $product = new WC_Product_LP_Course($item_data['product_id']);
                        } else {
                            $product = new WC_Product($item_data['product_id']);

                        }
                        $payplusBalanceName = $product->get_meta('payplus_balance_name');

                        if (!empty($payplusBalanceName)) {
                            $payplusBalanceNames[] = $payplusBalanceName;
                        }

                        $productSKU = ($product->get_sku()) ? $product->get_sku() : $item_data['product_id'];
                        if (!empty($dataArr['variation_id'])) {
                            $product = new WC_Product_Variable($dataArr['product_id']);
                            $variationsProduct = $product->get_available_variations();
                            $itemNameAttributes = "";
                            $product_attributes = $product->get_attributes();
                            foreach ($product_attributes as $key => $value) {

                                $manufacturer_id = $product_attributes[$key]['options']['0']; // returns the ID of the term
                                $manufacturer_name = get_term($manufacturer_id); // gets the term name of the term from the ID

                                $nameTaxonomy = str_replace("pa_", '', $manufacturer_name->taxonomy);
                                $nameTaxonomy = str_replace("-", ' ', $nameTaxonomy);
                                $valueTaxonomy = $manufacturer_name->name;

                                $itemNameAttributes .= (empty($itemNameAttributes)) ? $nameTaxonomy . " : " . $valueTaxonomy : " , " . $nameTaxonomy . " : " . $valueTaxonomy;

                            }
                            if (count($variationsProduct)) {
                                $productSKU = ($variationsProduct[0]['sku']) ? $variationsProduct[0]['sku'] :
                                    $variationsProduct[0]['variation_id'];
                            }
                            $item_name = $item_name . " ( " . $itemNameAttributes . " ) ";
                        }
                        $itemDetails = [
                            'name' => str_replace(["'", '"', "\n", "\\"], '', strip_tags($item_name)),
                            'barcode' => (string)$productSKU,
                            'quantity' => ($quantity ? $quantity : '1'),
                            'price' => $productPrice * $dual
                        ];


                        if ($item_data->get_tax_status() == 'none') {
                            $itemDetails['vat_type'] = 2;
                        } else {
                            $itemDetails['vat_type'] = 0;
                        }
                        if ($WC_PayPlus_Gateway->paying_vat_all_order === "yes") {
                            $itemDetails['vat_type'] = 0;
                        }

                        $productsItems[] = $itemDetails;
                    }
                    // order shipping
                    //  if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())) {
                    foreach ($order->get_shipping_methods() as $shipping_method) {
                        $shipping_method_data = $shipping_method->get_data();

                        if ((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() : $order->get_shipping_total())
                            || $shipping_method_data['method_id'] === "free_shipping") {
                            $totalLine = round((version_compare($wp_version, '3.0', '<') ? $order->get_total_shipping() + $order->get_shipping_tax() : $order->get_shipping_total() + $order->get_shipping_tax()), $payplus_invoice_rounding_decimals);

                            $productsItems[] = array(
                                "name" => __('Shipping', 'payplus-payment-gateway') . ' - ' . str_replace(["'", '"', "\\"], '', $shipping_method_data['name']),
                                "quantity" => 1,
                                "price" => $totalLine * $dual
                            );
                            $totalCartAmount += $totalLine;
                        }
                    }

                    // discount payment
                    if ($totalCartAmount !== $totallCart) {
                        $discount = (-1 * round(($totalCartAmount - $totallCart), 2));
                        $totalCartAmount = $totallCart;
                        $productsItems[] = array(
                            "name" => "discount",
                            "quantity" => 1,
                            "price" => $discount
                        );
                    }
                    $payload['currency_code'] = get_woocommerce_currency();
                    $payload['autocalculate_rate'] = true;

                    $payload['items'] = $productsItems;
                    $payload['totalAmount'] = $dual * $totallCart;
                    $payload['language'] = $this->payplus_invoice_option['payplus_langrage_invoice'];
                    $payload['more_info'] = $order_id;
                    $payload['unique_identifier'] = "payplus_order_" . $order_id;
                    $payload['send_document_email'] = $payplus_invoice_send_document_email;
                    $payload['send_document_sms'] = $payplus_invoice_send_document_sms;

                    if ($this->payplus_gateway_option['enabled'] === "no" && !count($resultApps)) {
                        $objectInvociePaymentNoPayplus = array('meta_key' => 'payplus_other', 'meta_value' => $dual * $payload['totalAmount']);
                        $objectInvociePaymentNoPayplus = (object)$objectInvociePaymentNoPayplus;

                        $resultApps [] = $objectInvociePaymentNoPayplus;
                    }
                    $payload ['payments'] = array();
                    if (count($resultApps)) {


                        for ($i = 0; $i < count($resultApps); $i++) {
                            $resultApp = $resultApps[$i];
                            $paymentType = 'payment-app';
                            if ($resultApp->meta_key == "payplus_credit-card") {
                                $paymentType = 'credit-card';
                            } elseif ($resultApp->meta_key == "payplus_paypal") {
                                $paymentType = 'paypal';

                            } elseif ($resultApp->meta_key == "payplus_other") {
                                $paymentType = 'other';
                            }
                            $type = explode("_", $resultApp->meta_key);
                            if ($resultApp->meta_key == 'payplus_multipass') {
                                $values = explode("|", $resultApp->meta_value);
                                for ($j = 0; $j < count($values); $j++) {
                                    $typePayment['payment_type'] = $paymentType;
                                    $typePayment['amount'] = $dual * floatval($values[$j]);
                                    $typePayment['payment_app'] = $type[1];
                                    $payplusApprovalNum = get_post_meta($order_id, "payplus_approval_num", true);
                                    $typePayment['description'] = __("transaction id", "payplus-payment-gateway") . " : " . $payplusApprovalNum;
                                    $payload ['payments'][] = $typePayment;

                                }

                            } else {
                                $arrTypeNotApp = array('credit-card', 'paypal', 'other');
                                $typePayment['payment_type'] = $paymentType;
                                $typePayment['amount'] = $dual * floatval($resultApp->meta_value);
                                if (!in_array($type[1], $arrTypeNotApp)) {
                                    $typePayment['payment_app'] = $type[1];
                                }
                                if ($type[1] == "credit-card" || $type[1] == "google-pay" || $type[1] == "apple-pay") {
                                    $payplusFourDigits = get_post_meta($order_id, "payplus_four_digits", true);
                                    $payplusIsssuerName = get_post_meta($order_id, "payplus_issuer_name", true);
                                    $payplusNumberOfPayments = get_post_meta($order_id, "payplus_number_of_payments", true);

                                    if ($payplusNumberOfPayments == "1") {
                                        $payplusNumberOfPayments = __("Normal", "payplus-payment-gateway");
                                    }

                                    $typePayment['description'] = __("Four last digits", "payplus-payment-gateway") . " : " . $payplusFourDigits .
                                        " , " . __("credit card type", "payplus-payment-gateway") . " : " . $payplusIsssuerName
                                        . " , " . __("Number of payments", "payplus-payment-gateway") . " : " . $payplusNumberOfPayments;
                                } else {
                                    $payplusApprovalNum = get_post_meta($order_id, "payplus_approval_num", true);
                                    $typePayment['description'] = __("transaction id", "payplus-payment-gateway") . " : " . $payplusApprovalNum;
                                }
                                $payload ['payments'][] = $typePayment;
                            }
                        }
                    } else {
                        $otherMethod = strtolower(get_post_meta($order_id, '_payment_method_title', true));
                        if ($otherMethod === "paypal") {
                            $typePayment['payment_type'] = $otherMethod;
                        } else {
                            $typePayment['payment_type'] = "other";
                        }
                        $typePayment['amount'] = $dual * $order->get_total();
                        $payload ['payments'][] = $typePayment;

                    }

                    if ($this->logging) $logger->add('payplus_invoice_payload', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($payload, true));

                    if (count($payplusBalanceNames)) {
                        if (count($payplusBalanceNames) == COUNT_BALANCE_NAME) {
                            $payload ['customer']['balance_name'] = $payplusBalanceNames[COUNT_BALANCE_NAME - 1];
                        } else {
                            $order->add_order_note(__("We will not send a balance number to create an invoice because you have more than one product with a balance number", 'payplus-payment-gateway'));
                        }
                    }

                    $payload = json_encode($payload);
                    $response = $this->post_payplus_ws($this->url_payplus_create_invoice . $payplus_document_type, $payload);

                    if (is_wp_error($response)) {
                        if ($this->logging) $logger->add('payplus_invoice_response_error', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($response, true));
                    } else {
                        $res = json_decode(wp_remote_retrieve_body($response));

                        if ($res->status === "success") {
                            if ($this->logging) $logger->add('payplus_invoice_response', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Success: ' . print_r($res, true));
                            add_post_meta($order_id, "payplus_invoice_docUID", $res->details->docUID);
                            add_post_meta($order_id, "payplus_invoice_number", $res->details->number);
                            add_post_meta($order_id, "payplus_invoice_originalDocAddress", $res->details->originalDocAddress);
                            add_post_meta($order_id, "payplus_invoice_copyDocAddress", $res->details->copyDocAddress);
                            add_post_meta($order_id, "payplus_invoice_customer_uuid", $res->details->customer_uuid);
                            $order->add_order_note('<div style="font-weight:600">PayPlus Document</div>
                 <a class="link-invoice" target="_blank" href="' . $res->details->originalDocAddress . '">' . __('Link Document  ', 'payplus-payment-gateway') . '</a>');
                        } else {
                            if ($this->logging) $logger->add('payplus_invoice_response_error', 'Plugin Version: ' . PAYPLUS_VERSION . ' - ' . 'WP Remote Post Error: ' . print_r($res, true));
                        }
                    }
                }

                add_post_meta($order_id, 'payplus_check_invoice_send', true);


            }

    }

    public function post_payplus_ws($url, $payload)
    {
        $args = array(
            'body' => $payload,
            'timeout'     => '60',
            'redirection' => '5',
            'httpversion' => '1.0',
            'blocking'    => true,
            'headers'     => [],
            'headers' => array(
                'User-Agent' => 'WordPress '.$_SERVER['HTTP_USER_AGENT'],
                'Content-Type' => 'application/json',
                'Authorization' => '{"api_key":"' . $this-> payplus_invoice_api_key . '","secret_key":"' . $this->payplus_invoice_secret_key . '"}'
            )
        );
        $response = wp_remote_post($url, $args);
        return $response;
    }

    public  function payplus_invoice_set_fields_option_page(){
        ob_start();
      /*  register_setting(
            'payplus_invoice_option', // Option group
            'payplus_invoice_option', // Option name
            array( $this, 'payplus_invoice_sanitize' ) // Sanitize
        );*/
        ?>
        <?php  echo $this->payplus_invoice_header_option() ?>
            <table class="form-table">
                <tbody>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_enable">
                        <?php echo  __('Enable/Disable','payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_enable_payplus_invoice() ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_enable_sandbox">
                            <?php echo __('Enable Sandbox Mode','payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_enable_sandbox() ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_api_key">
                            <?php echo __('API Key','payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_api_key(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_secret_key">
                            <?php echo __('SECRET KEY','payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_secret_key(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_secret_key">
                            <?php echo __("Brand Uid (Keep empty if you don't have any active brands)",'payplus-payment-gateway') ?>

                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_brand_uid(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_langrage_invoice">
                            <?php echo __("Invoice's Language",'payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_language(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_type_document">
                            <?php echo __("Document type for charge transaction",'payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_type_documents(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_type_document_refund">
                            <?php echo __("Document type for refund transaction",'payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_type_documents_refund(); ?>
                        </fieldset>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_status_order">
                            <?php echo __("Order status for issuing an invoice",'payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_set_field_status_order(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_send_document_email">
                            <?php echo __("Send invoice to the customer via e-mail",'payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_send_document_email(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_send_document_sms">
                            <?php echo __('Send invoice to the customer via Sms (Only If you purchased an SMS package from PayPlus)','payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_send_document_sms(); ?>
                        </fieldset>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="payplus_invoice_enable_logging_mode">
                            <?php echo __('Logging','payplus-payment-gateway') ?>
                        </label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <?php $this->payplus_invoice_enable_logging_mode(); ?>
                        </fieldset>
                    </td>
                </tr>
                </tbody>
            </table>


            <?php

        $output = ob_get_clean();
        return $output;
    }

    public function payplus_add_page_option(){
        wp_redirect( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway' ) );
        exit;
    }

    public  function payplus_invoice_sanitize($input){

        $keyCheckbox =array('payplus_invoice_enable' ,'payplus_invoice_enable_logging_mode' ,'payplus_enable_sandbox');
        $new_input = array();
        foreach ($input as $key =>$value){
            if(in_array($key,$keyCheckbox)){
                $new_input[$key] =1;
            }else{
                $new_input[$key] =sanitize_text_field($input[$key]);
            }
        }
        return $new_input;
    }


    public  function payplus_invoice_header_option(){
            print "<h1>".__('Invoice+ (PayPlus)','payplus-payment-gateway')."</h1>";
    }

    public  function payplus_enable_payplus_invoice(){
        $checked = (isset($this->payplus_invoice_option['payplus_invoice_enable'] )) ? "checked" : '';
        printf('<input '.$checked.'     type="checkbox" id="payplus_invoice_enable" name="payplus_invoice_option[payplus_invoice_enable]" />' );
    }

    public  function payplus_enable_sandbox(){
        $checked = (isset($this->payplus_invoice_option['payplus_enable_sandbox'] )) ? "checked" : '';
        printf('<input '.$checked.' type="checkbox" id="payplus_enable_sandbox" name="payplus_invoice_option[payplus_enable_sandbox]" />');
    }

    public  function payplus_invoice_set_field_api_key(){
        printf('<input class="width-100"    placeholder="'.__('Api Key','payplus-payment-gateway').'" type="text" id="payplus_invoice_api_key" name="payplus_invoice_option[payplus_invoice_api_key]" value="%s" />',
            isset(   $this-> payplus_invoice_api_key  ) ? esc_attr(  $this-> payplus_invoice_api_key ) : '');
    }

    public  function payplus_invoice_set_field_secret_key(){
        printf('<input class="width-100"   placeholder="'.__('Secret key','payplus-payment-gateway').'" type="text" id="payplus_invoice_secret_key" name="payplus_invoice_option[payplus_invoice_secret_key]" value="%s" />',
            isset(  $this-> payplus_invoice_secret_key ) ? esc_attr(  $this-> payplus_invoice_secret_key) : '' );
    }
    public  function payplus_invoice_set_field_brand_uid(){

        printf('<input class="width-100"   placeholder="'.__('Brand Uid','payplus-payment-gateway').'" type="text" id="payplus_invoice_brand_uid" name="payplus_invoice_option[payplus_invoice_brand_uid]" value="%s" />',
            isset(  $this-> payplus_invoice_brand_uid ) ? esc_attr(  $this-> payplus_invoice_brand_uid) : '' );
    }

    public  function  payplus_invoice_set_field_type_documents(){
        $payplus_invoice_type_document =array(
            '' =>__('Type Documents','payplus-payment-gateway'),
            'inv_tax' =>__('Tax Invoice','payplus-payment-gateway'),
            'inv_tax_receipt' =>__('Tax Invoice Receipt ','payplus-payment-gateway'),
            'inv_receipt' =>__('Receipt','payplus-payment-gateway'),
            'inv_don_receipt' =>__('Donation Reciept','payplus-payment-gateway'));
        ?>
        <select id="payplus_invoice_type_document"   name="payplus_invoice_option[payplus_invoice_type_document]" id="">
            <?php
            foreach($payplus_invoice_type_document as $key =>$value):?>
                <option <?php selected( $this->payplus_invoice_type_document,$key) ?> value="<?php echo $key?>" ><?php echo $value ?></option>
            <?php
            endforeach;
            ?>
        </select>
        <?php
    }

    public  function  payplus_invoice_set_field_type_documents_refund(){
        $payplus_invoice_type_document =array(
            '' =>__('Type Documents Refund','payplus-payment-gateway'),
            'inv_refund' =>__('Credit Invoice','payplus-payment-gateway'),
             'inv_refund_receipt'=>__('Credit Receipt','payplus-payment-gateway'),
             'inv_refund_receipt_invoice'=>__('Credit Invoice + Credit Receipt','payplus-payment-gateway') );
        ?>
        <select id="payplus_invoice_type_document_refund"   name="payplus_invoice_option[payplus_invoice_type_document_refund]" id="">
            <?php
            foreach($payplus_invoice_type_document as $key =>$value):?>
                <option <?php selected( $this->payplus_invoice_type_document_refund,$key) ?> value="<?php echo $key?>" ><?php echo $value ?></option>
            <?php
            endforeach;
            ?>
        </select>
        <?php
    }

    public function  payplus_invoice_set_field_language(){
        $payplus_langrage_invoice =(isset($this->payplus_invoice_option['payplus_langrage_invoice']))?$this->payplus_invoice_option['payplus_langrage_invoice']:get_locale();
        $langrage =array("he","en");
        ?>
             <select id="payplus_langrage_invoice" required name="payplus_invoice_option[payplus_langrage_invoice]" id="">
                  <?php
                foreach($langrage as $key =>$value):?>
                    <option <?php selected( $payplus_langrage_invoice,$value) ?> value="<?php echo $value?>" ><?php echo $value ?></option>
                <?php
            endforeach;
            ?>
             </select>
        <?php
    }

    public  function  payplus_invoice_set_field_status_order(){
        $payplus_invoice_status_order = wc_get_order_statuses();
        ?>
        <select id="payplus_invoice_status_order" required name="payplus_invoice_option[payplus_invoice_status_order]" id="">
            <?php
            foreach($payplus_invoice_status_order as $key =>$value):
                $keyValue=str_replace('wc-','',$key);
                ?>
                <option <?php selected(  $this->payplus_invoice_status_order,$keyValue) ?> value="<?php echo $keyValue?>" ><?php echo $value ?></option>
            <?php
            endforeach;
            ?>
        </select>
        <?php
    }

    public  function payplus_invoice_send_document_email(){
        $checked = (isset($this->payplus_invoice_option['payplus_invoice_send_document_email']) ) ? "checked" : '';
        printf('<input '.$checked.' type="checkbox" id="payplus_invoice_send_document_email" name="payplus_invoice_option[payplus_invoice_send_document_email]"  />');
    }

    public  function payplus_invoice_send_document_sms(){
        $checked = (isset($this->payplus_invoice_option['payplus_invoice_send_document_sms']) ) ? "checked" : '';
        printf('<input '.$checked.' type="checkbox" id="payplus_invoice_send_document_sms" name="payplus_invoice_option[payplus_invoice_send_document_sms]"  />');
    }

    public function  payplus_invoice_enable_logging_mode(){
        $checked = "checked";
        printf('<input disable  '.$checked.'  disabled  type="checkbox" id="payplus_invoice_enable_logging_mode" name="payplus_invoice_option[payplus_invoice_enable_logging_mode]"/>',);
    }
}
new PayplusInvoice();