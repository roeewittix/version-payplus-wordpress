<?php
/*
Plugin Name: PayPlus Payment Gateway
Description: WooCommerce integration for PayPlus Payment Gateway. Accept credit cards and more alternative methods directly to your WordPress e-commerce websites, More options to Refund, Charge, Capture, Subscriptions, Tokens and much more!
Plugin URI: https://www.payplus.co.il/wordpress
Version:6.2.3
Author: PayPlus LTD
Author URI: https://www.payplus.co.il/
License: GPLv2 or later
Text Domain: PayPlus Payment Gateway Plugin
*/

defined('ABSPATH') or die('Hey, You can\'t access this file!'); // Exit if accessed directly
define('PAYPLUS_PLUGIN_URL', plugins_url('/', __FILE__));
define('PAYPLUS_PLUGIN_URL_ASSETS_IMAGES', PAYPLUS_PLUGIN_URL."assets/images/");
define('PAYPLUS_PLUGIN_DIR', dirname(__FILE__));
define('PAYPLUS_VERSION', '6.2.3');
define('PAYPLUS_SEND_EMAIL', 'service@payplus.co.il');


class WC_PayPlus
{

	protected static $instance = null;
    public $notices = [];

    private function __construct()
    {

        add_action('admin_init', [$this, 'check_environment']);
        add_action('admin_notices', [$this, 'admin_notices'], 15);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'plugin_action_links']);
        add_action('plugins_loaded', [$this, 'init']);
        add_shortcode('error-payplus-content' ,[$this,'payplus_text_error_page']);
        add_action( 'manage_product_posts_custom_column' ,[$this,  'payplus_custom_column_product'], 10, 2);
        add_action( 'woocommerce_email_before_order_table', [$this,'payplus_add_content_specific_email'], 20, 4 );
        add_action('wp_head',[$this,'payplus_no_index_page_error']);

    }


    public  function  payplus_no_index_page_error(){
        global $wp;
        $error_page_payplus =get_option('error_page_payplus');
        $postIdcurrenttUrl =url_to_postid( home_url( $wp->request ));
        if(intval($postIdcurrenttUrl)===intval($error_page_payplus)){
            ?>
            <meta name="robots" content="noindex,nofollow">
            <?php
        }
    }


    public  function payplus_after_refund($order_id, $refund_id ){
        $invocie_api =  new   PayplusInvoice();
        $payment_method =get_post_meta($order_id,'_payment_method',true);

        if(strpos($payment_method,'payplus')===false){
            $amount =get_post_meta($refund_id,'_refund_amount',true);
            $invocie_api->payplus_create_dcoment_dasbord($order_id,
                $invocie_api->payplus_get_invoice_type_document_refund(),array(),$amount ,'payplus_order_refund'.$order_id);
        }
    }

    public  function payplus_add_toolbar_items($admin_bar){

        $admin_bar->add_menu( array(
            'id'    => 'PayPlus-toolbar',
            'title' => __('PayPlus  Gateway', 'payplus-payment-gateway'),
            'href'  => get_admin_url()."/admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway",
            'meta'  => array(
                'title' => __('PayPlus  Gateway', 'payplus-payment-gateway'),
                'target' => '_blank'
            ),
        ));
        $admin_bar->add_menu( array(
                'id'    => 'payPlus-toolbar-sub',
                'parent' => 'PayPlus-toolbar',
                'title' =>  __('Invoice+ (PayPlus)', 'payplus-payment-gateway'),
                'href'  => get_admin_url()."/admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway&invoicepayplus=1",
                'meta'  => array(
                    'title' => __('Invoice+ (PayPlus)', 'payplus-payment-gateway'),
                    'target' => '_blank',
                    'class' => 'my_menu_item_class'
                ),
        ));
    }

    public function payplus_add_content_specific_email( $order, $sent_to_admin, $plain_text, $email ) {

        if ( $email->id == 'new_order' ) {
            $payplusFourDigits = get_post_meta($order->id,"payplus_four_digits",true);
            if($payplusFourDigits){
                $payplusFourDigits =  __("Four last digits","payplus-payment-gateway") ." : ".$payplusFourDigits;
                echo '<p class="email-upsell-p">'.$payplusFourDigits.'</p>';
            }
        }
    }

    public static function get_instance()
	{
		if (!isset(static::$instance)) {
			static::$instance = new static;
		}

		return static::$instance;
	}

    public  function  payplus_custom_column_product($column, $post_id){

        if($column=="payplus_transaction_type"){
            $transactionTypes = array('1' => __('Charge', 'payplus-payment-gateway'),
                '2' => __('Authorization', 'payplus-payment-gateway'));
            $payplusTransactionType= get_post_meta( $post_id, 'payplus_transaction_type', true );
            if(!empty($payplusTransactionType)){
                echo  '<p>'.  $transactionTypes[$payplusTransactionType]."</p>";
            }
        }

    }

    public function  payplus_get_gateway(){
        wp_redirect( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway' ) );
        exit;
    }

    public  function  payplus_add_admin_page_menu(){
        global $submenu;
        $parent_slug ='payplus-payment-gateway';

        add_menu_page( __('PayPlus  Gateway','payplus-payment-gateway'),  __('PayPlus  Gateway','payplus-payment-gateway'),"administrator",
            'payplus-payment-gateway',[$this,'payplus_get_gateway'],PAYPLUS_PLUGIN_URL_ASSETS_IMAGES."payplus-icon.svg"
        );

        add_submenu_page(
            'payplus-payment-gateway',
            __('bit','payplus-payment-gateway'),
            __('bit','payplus-payment-gateway'),
            'administrator', //Capability
            'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway-bit'

        );
        add_submenu_page(
            'payplus-payment-gateway', //Page Title
            __('Google Pay','payplus-payment-gateway'),
            __('Google Pay','payplus-payment-gateway'),
            'administrator', //Capability
            'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway-googlepay' //Page slug

        );
        add_submenu_page(
            'payplus-payment-gateway', //Page Title
            __('Apple Pay','payplus-payment-gateway'),
            __('Apple Pay','payplus-payment-gateway'),
            'administrator', //Capability
            'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway-applepay' //Page slug

        );

        add_submenu_page(
            'payplus-payment-gateway', //Page Title
            __('MULTIPASS','payplus-payment-gateway'),
            __('MULTIPASS','payplus-payment-gateway'),
            'administrator', //Capability
            'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway-multipass' //Page slug

        );
        add_submenu_page(
            'payplus-payment-gateway', //Page Title
            __('PayPal','payplus-payment-gateway'),
            __('PayPal','payplus-payment-gateway'),
            'administrator', //Capability
            'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway-paypal' //Page slug

        );
        add_submenu_page(
                 'payplus-payment-gateway', //Page Title
                 __('Invoice+ (PayPlus)', 'payplus-payment-gateway'),
                  __('Invoice+ (PayPlus)', 'payplus-payment-gateway'),
                 'administrator', //Capability
                 'admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway&invoicepayplus=1' //Page slug

             );
    }

    public  function  payplus_text_error_page(){
        $optionlanguages =get_option('settings_payplus_page_error_option');
        $locale =get_locale();
        foreach ($optionlanguages as $key =>$optionlanguage){
            if(strpos($key,$locale)!==false){
                return    "<p style='text-align: center' class='payplus-error-text'>".$optionlanguage."</p>"; ;
            }
        }
        return  "<p  style='text-align: center' class='payplus-error-text'>".$optionlanguages['en_US_-English'] ."</p>";

    }

    public function check_environment()
	{

		if (is_admin() && current_user_can('activate_plugins') && !is_plugin_active('woocommerce/woocommerce.php')) {
			$message = __('This plugin requires <a href="https://wordpress.org/plugins/woocommerce/" target="_blank">WooCommerce</a> to be activated.', 'payplus-payment-gateway');
			$this->add_admin_notice('error', $message);
			// Deactivate the plugin
			deactivate_plugins(__FILE__);

			return;
		}

		$php_version          = phpversion();
		$required_php_version = '5.4';
		if (version_compare($required_php_version, $php_version, '>')) {
			$message = sprintf(__('Your server is running PHP version %1$s but some features requires at least %2$s.', 'payplus-payment-gateway'), $php_version, $required_php_version);
			$this->add_admin_notice('warning', $message);
		}

	}

	public function add_admin_notice($type, $message)
	{
		$this->notices[] = [
			'class'   => "notice notice-$type is-dismissible",
			'message' => $message
		];
	}

	public function admin_notices()
	{
		$output = '';
		$title  = __('PayPlus Payment Gateway', 'payplus-payment-gateway');
		foreach ($this->notices as $notice) {
			$output .= "<div class='$notice[class]'><p><b>$title:</b> $notice[message]</p></div>";
		}
		echo $output;
	}

	public static function plugin_action_links($links)
	{
		$action_links = [
			'settings' => '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=payplus-payment-gateway') . '" aria-label="' . __('View PayPlus Settings', 'payplus-payment-gateway') . '">' . __('Settings') . '</a>'
		];
		$links        = array_merge($action_links, $links);

		return $links;
	}

	public function init()
	{

        load_plugin_textdomain('payplus-payment-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');

		if (class_exists("WooCommerce")) {

			include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_gateway.php');
			include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_subgateways.php');
			include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_admin_payments.php');
            include_once(PAYPLUS_PLUGIN_DIR . '/includes/wc_payplus_invoice.php');
            $invocie_api =  new   PayplusInvoice();
            add_action( 'manage_shop_order_posts_custom_column', [$invocie_api ,'payplus_add_order_column_order_invoice'],100 );
            add_action( 'woocommerce_order_item_add_action_buttons', [$invocie_api,'payplus_order_item_add_action_buttons_callback'], 10, 1 );
            add_action('admin_bar_menu', [$this,'payplus_add_toolbar_items'], 100);

            if($invocie_api->payplus_get_invoice_enable()){
                add_action( 'woocommerce_order_refunded', [$this,'payplus_after_refund'], 10, 2 );
            }

		}

        add_filter('woocommerce_payment_gateways', [$this, 'add_payplus_gateway'],20);

	}

    public function  payplus_add_order_column_order_transaction_type($column){
        $WC_PayPlus_Gateway = new WC_PayPlus_Gateway();
        if($column=="payplus_transaction_type" && $WC_PayPlus_Gateway->add_product_field_transaction_type){
            global $post;
            $payplusTransactionType =get_post_meta($post->ID,'payplus_transaction_type',true);
            if(!empty($payplusTransactionType)){
                $transactionTypes = array('1' => __('Charge', 'payplus-payment-gateway'),
                    '2' => __('Authorization', 'payplus-payment-gateway'));
                echo  $transactionTypes[$payplusTransactionType];
            }
        }
    }

    public function add_payplus_gateway($methods)
	{
		$methods[] = 'WC_PayPlus_Gateway';
		$methods[] = 'WC_PayPlus_Gateway_Bit';
		$methods[] = 'WC_PayPlus_Gateway_GooglePay';
		$methods[] = 'WC_PayPlus_Gateway_ApplePay';
		$methods[] = 'WC_PayPlus_Gateway_Multipass';
        $methods[] = 'WC_PayPlus_Gateway_Paypal';
        add_action( 'manage_shop_order_posts_custom_column', [$this ,'payplus_add_order_column_order_transaction_type'],100 );
        add_action( 'admin_menu',[$this, 'payplus_add_admin_page_menu'],99);


		return $methods;
	}

	public function __clone()
	{
		_doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'payplus-payment-gateway'), '2.0');
	}

	public function __wakeup()
	{
		_doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'payplus-payment-gateway'), '2.0');
	}
}

WC_PayPlus::get_instance();

// New order status AFTER woo 2.2
add_action( 'init', 'register_my_new_order_statuses' );

function register_my_new_order_statuses() {
    register_post_status( 'wc-recsubc', array(
        'label'                     => _x( 'Recurring subscription created', 'Order status', 'woocommerce' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Recurring subscription created <span class="count">(%s)</span>', 'Recurring subscription created<span class="count">(%s)</span>', 'woocommerce' )
    ) );
}

add_filter( 'wc_order_statuses', 'my_new_wc_order_statuses' );

// Register in wc_order_statuses.
function my_new_wc_order_statuses( $order_statuses ) {
    $order_statuses['wc-recsubc'] = _x( 'Recurring subscription created', 'Order status', 'woocommerce' );

    return $order_statuses;
}
/*
function payplus_create_table_payment_session()
{
    global $wpdb;

    $tblname = 'payplus_payment_session';
    $payplus_table = $wpdb->prefix . $tblname;
    $charset_collate = $wpdb->get_charset_collate();
    if($wpdb->get_var( "show tables like '$payplus_table'" ) != $payplus_table)
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $payplus_table (
		  id int(11) NOT NULL AUTO_INCREMENT,
		  payplus_created timestamp NOT NULL default CURRENT_TIMESTAMP,
		  payplus_update datetime NOT NULL,
		  payplus_ip text NOT NULL,
		  payplus_order int(11) NULL,
		  UNIQUE KEY id (id)
		) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
        $is_error = empty( $wpdb->last_error );



    }

}
function payplus_delete_table_payment_session(){
    global $wpdb;
    $table_name = $wpdb->prefix . 'payplus_payment_session';
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql);
}
register_activation_hook( __FILE__, 'payplus_create_table_payment_session' );
register_deactivation_hook( __FILE__, 'payplus_delete_table_payment_session' );
*/


